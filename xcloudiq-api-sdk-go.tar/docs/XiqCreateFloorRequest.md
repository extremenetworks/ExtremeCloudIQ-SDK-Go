# XiqCreateFloorRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ParentId** | **int64** | The parent building ID | 
**Name** | **string** | The floor name | 
**Environment** | [**XiqRfEnvironmentType**](XiqRfEnvironmentType.md) |  | [optional] 
**DbAttenuation** | **float64** | The floor attenuation in dBs | 
**MeasurementUnit** | [**XiqMeasurementUnit**](XiqMeasurementUnit.md) |  | 
**InstallationHeight** | **float64** | The installation height | 
**MapSizeWidth** | **float64** | The floor map width | 
**MapSizeHeight** | **float64** | The floor map height | 
**MapName** | **string** | The floor map name | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


