# XiqOperationObject

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | The unique identifier of the operation | 
**Metadata** | [**XiqOperationMetadata**](XiqOperationMetadata.md) |  | 
**Done** | **bool** | Whether the operation is done | 
**Response** | [**map[string]interface{}**](.md) | The API response of the operation if the status is SUCCEEDED | [optional] 
**Error** | [**XiqError**](XiqError.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


