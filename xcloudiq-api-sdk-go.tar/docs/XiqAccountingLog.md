# XiqAccountingLog

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The Accounting log id | 
**Username** | **string** | The username | [optional] 
**OrgId** | **int64** | The org id | [optional] 
**Timestamp** | **int64** | The email log timestamp | [optional] 
**VhmId** | **string** | The vhm id | [optional] 
**DeviceSerialNumber** | **string** | The device serial number | [optional] 
**AcctSessionId** | **string** | The acct session id | [optional] 
**AcctMultiId** | **string** | The acct multi id | [optional] 
**GroupName** | **string** | The group name | [optional] 
**NasIpAddress** | **string** | The nas ip address | [optional] 
**NasPort** | **string** | The nas port | [optional] 
**NasPortType** | **string** | The nas port type | [optional] 
**AcctStartTime** | **int64** | The acct start time | [optional] 
**AcctStopTime** | **int64** | The acct stop time | [optional] 
**AcctSessionTime** | **int64** | The acct session time | [optional] 
**AcctAuthentic** | **string** | The acct authentic | [optional] 
**ConnectInfo** | **string** | The connect info | [optional] 
**AcctInputOctets** | **int64** | The acct input octets | [optional] 
**AcctOutputOctets** | **int64** | The acct output octets | [optional] 
**CalledStationId** | **string** | The called station id | [optional] 
**CallingStationId** | **string** | The calling station id | [optional] 
**AcctTerminateCause** | **string** | The acct terminate cause | [optional] 
**ServiceType** | **string** | The service type | [optional] 
**FramedIpAddress** | **string** | The framed ip address | [optional] 
**AcctStartDelay** | **int64** | The acct start delay | [optional] 
**AcctStopDelay** | **int64** | The acct stop delay | [optional] 
**Ssid** | **string** | The ssid | [optional] 
**Identity** | **string** | The identity | [optional] 
**NasIdentifier** | **string** | The nas identifier | [optional] 
**MgmtMacAddress** | **string** | The management mac address | [optional] 
**AttributeNum** | **int32** | The attribute num | [optional] 
**EventTime** | **int64** | The event time | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


