# XiqSmsLog

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The SMS log id | 
**UserId** | **int64** | The user id | [optional] 
**CustomerId** | **string** | The customer id | [optional] 
**Tel** | **string** | The phone number | [optional] 
**ProfileName** | **string** | The profile name | [optional] 
**Status** | [**XiqSmsLogStatus**](XiqSmsLogStatus.md) |  | [optional] 
**MessageId** | **string** | The message id from 3rd provider | [optional] 
**StatusFromProvider** | **string** | The status from provider | [optional] 
**ProviderType** | **string** | The provider type | [optional] 
**OrgId** | **int64** | The org id | [optional] 
**Timestamp** | **int64** | The audit log timestamp | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


