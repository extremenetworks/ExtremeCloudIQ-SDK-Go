# \AccountApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**BackupViq**](AccountApi.md#BackupViq) | **Post** /account/viq/:backup | Backup VIQ
[**GetDefaultDevicePassword**](AccountApi.md#GetDefaultDevicePassword) | **Get** /account/viq/default-device-password | Get the default device password in the account
[**GetHomeAccount**](AccountApi.md#GetHomeAccount) | **Get** /account/home | Get home ExtremeCloud IQ account info
[**GetViqInfo**](AccountApi.md#GetViqInfo) | **Get** /account/viq | Get VIQ Info
[**ListExternalAccounts**](AccountApi.md#ListExternalAccounts) | **Get** /account/external | List accessible external guest accounts
[**SwitchAccount**](AccountApi.md#SwitchAccount) | **Post** /account/:switch | Switch to another ExtremeCloud IQ account
[**UpdateDefaultDevicePassword**](AccountApi.md#UpdateDefaultDevicePassword) | **Put** /account/viq/default-device-password | Update the default device password in the account



## BackupViq

> BackupViq(ctx, )

Backup VIQ

Backup VIQ in ExtremeCloud IQ.

### Required Parameters

This endpoint does not need any parameter.

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDefaultDevicePassword

> XiqDefaultDevicePassword GetDefaultDevicePassword(ctx, )

Get the default device password in the account

Get the default device password in the account.

### Required Parameters

This endpoint does not need any parameter.

### Return type

[**XiqDefaultDevicePassword**](XiqDefaultDevicePassword.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHomeAccount

> XiqAccount GetHomeAccount(ctx, )

Get home ExtremeCloud IQ account info

Get home ExtremeCloud IQ account info.

### Required Parameters

This endpoint does not need any parameter.

### Return type

[**XiqAccount**](XiqAccount.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetViqInfo

> XiqViq GetViqInfo(ctx, )

Get VIQ Info

Get account VIQ and license info.

### Required Parameters

This endpoint does not need any parameter.

### Return type

[**XiqViq**](XiqViq.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListExternalAccounts

> []XiqExternalAccount ListExternalAccounts(ctx, )

List accessible external guest accounts

List accessible external ExtremeCloud IQ accounts.

### Required Parameters

This endpoint does not need any parameter.

### Return type

[**[]XiqExternalAccount**](XiqExternalAccount.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SwitchAccount

> XiqLoginResponse SwitchAccount(ctx, optional)

Switch to another ExtremeCloud IQ account

Switch to external ExtremeCloud IQ account or switch back to home ExtremeCloud IQ account.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***SwitchAccountOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a SwitchAccountOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **optional.Int64**| The account ID to switch, switch back to home ExtremeCloud IQ account if not provide | 

### Return type

[**XiqLoginResponse**](XiqLoginResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateDefaultDevicePassword

> UpdateDefaultDevicePassword(ctx, body)

Update the default device password in the account

Update the default device password in the global setting for accessing the console/shell of the devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**body** | **string**| The new default device password | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

