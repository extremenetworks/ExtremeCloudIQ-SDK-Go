# XiqAtpDeviceStatsEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **int64** | The timestamp | 
**AvgCpu** | **float32** | Avg Cpu | [optional] 
**AvgMemory** | **float32** | Avg Memory | [optional] 
**AvgClientCount** | **int32** | Avg Client Count | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


