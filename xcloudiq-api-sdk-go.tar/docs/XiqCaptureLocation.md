# XiqCaptureLocation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Direction** | [**XiqCaptureDirectionSelection**](XiqCaptureDirectionSelection.md) |  | [optional] 
**Radio** | [**XiqCaptureRadioSelection**](XiqCaptureRadioSelection.md) |  | [optional] 
**WiredInterface** | [**XiqCaptureWiredSelection**](XiqCaptureWiredSelection.md) |  | [optional] 
**WirelessBand** | [**XiqCaptureBandSelection**](XiqCaptureBandSelection.md) |  | [optional] 
**WiredFilters** | [**[]XiqWiredFilterType**](XiqWiredFilterType.md) | The list of pre-defined wired filters for packet capture | [optional] 
**WirelessFilters** | [**[]XiqWirelessFilterType**](XiqWirelessFilterType.md) | The list of pre-defined wireless filters for packet capture | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


