# \AuthorizationApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CheckPermissions**](AuthorizationApi.md#CheckPermissions) | **Post** /auth/permissions/:check | Check permissions
[**GenerateApiToken**](AuthorizationApi.md#GenerateApiToken) | **Post** /auth/apitoken | Generate new API token
[**GetCurrentApiTokenInfo**](AuthorizationApi.md#GetCurrentApiTokenInfo) | **Get** /auth/apitoken/info | Get current API token details
[**ListPermissions**](AuthorizationApi.md#ListPermissions) | **Get** /auth/permissions | Get permissions for current login user
[**ValidateApiToken**](AuthorizationApi.md#ValidateApiToken) | **Post** /auth/apitoken/:validate | Validate API token



## CheckPermissions

> XiqCheckPermissionResponse CheckPermissions(ctx, xiqCheckPermissionRequest)

Check permissions

Get required permissions for given HTTP request.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCheckPermissionRequest** | [**XiqCheckPermissionRequest**](XiqCheckPermissionRequest.md)|  | 

### Return type

[**XiqCheckPermissionResponse**](XiqCheckPermissionResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GenerateApiToken

> XiqGenerateApiTokenResponse GenerateApiToken(ctx, xiqGenerateApiTokenRequest)

Generate new API token

Generate a new API token with given permissions and expiration time.  The available permission list can be found via 'GET /auth/permissions' endpoint.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqGenerateApiTokenRequest** | [**XiqGenerateApiTokenRequest**](XiqGenerateApiTokenRequest.md)| Generate API token request body | 

### Return type

[**XiqGenerateApiTokenResponse**](XiqGenerateApiTokenResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCurrentApiTokenInfo

> XiqApiTokenInfo GetCurrentApiTokenInfo(ctx, )

Get current API token details

Introspect current API token and get detail information.

### Required Parameters

This endpoint does not need any parameter.

### Return type

[**XiqApiTokenInfo**](XiqApiTokenInfo.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPermissions

> string ListPermissions(ctx, )

Get permissions for current login user

Get permissions for current login user, which are allowed for generating new API tokens.

### Required Parameters

This endpoint does not need any parameter.

### Return type

**string**

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ValidateApiToken

> ValidateApiToken(ctx, body)

Validate API token

Validate JWT format API token

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**body** | **string**|  | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: text/plain
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

