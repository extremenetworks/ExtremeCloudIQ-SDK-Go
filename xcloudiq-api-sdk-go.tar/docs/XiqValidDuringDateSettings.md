# XiqValidDuringDateSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDateTime** | [**XiqDateTimeType**](XiqDateTimeType.md) |  | 
**EndDateTime** | [**XiqDateTimeType**](XiqDateTimeType.md) |  | 
**TimeZone** | **string** | The date/time timezone | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


