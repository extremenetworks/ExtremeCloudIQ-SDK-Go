# XiqDeviceAlarm

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EntityId** | **int64** | The device ID | [optional] 
**Timestamp** | **int64** | The timestamp for alarm created | [optional] 
**Severity** | **string** | The severity of the alarm | [optional] 
**Category** | **string** | The category of the alarm | [optional] 
**DeviceMac** | **string** | The device MAC of the alarm | [optional] 
**ClientMac** | **string** | The client MAC of the alarm | [optional] 
**Description** | **string** | The alarm description | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


