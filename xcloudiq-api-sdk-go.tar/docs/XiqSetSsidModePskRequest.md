# XiqSetSsidModePskRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**KeyManagement** | [**XiqSsidPskKeyManagement**](XiqSsidPskKeyManagement.md) |  | 
**EncryptionMethod** | [**XiqSsidPskEncryptionMethod**](XiqSsidPskEncryptionMethod.md) |  | 
**AntiLoggingThreshold** | **int32** | The anti logging threshold | [optional] 
**KeyType** | [**XiqSsidKeyType**](XiqSsidKeyType.md) |  | 
**KeyValue** | **string** | The PSK key value, minimum 8 characters long | 
**SaeGroup** | [**XiqSsidSaeGroup**](XiqSsidSaeGroup.md) |  | [optional] 
**TransitionMode** | **bool** | Indicates the transition mode if key management is WPA3 | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


