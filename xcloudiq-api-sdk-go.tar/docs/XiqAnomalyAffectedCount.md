# XiqAnomalyAffectedCount

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TotalAnomalyCount** | **int32** | The total anomaly count | 
**AffectedLocationCount** | **int32** | The affected location count | 
**AffectedDevicesCount** | **int32** | The affected devices count | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


