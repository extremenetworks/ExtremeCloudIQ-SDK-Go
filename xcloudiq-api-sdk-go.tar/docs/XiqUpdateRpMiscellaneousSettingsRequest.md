# XiqUpdateRpMiscellaneousSettingsRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SlaThroughputLevel** | **string** | The Client SLA options -- \&quot;NORMAL_DENSITY\&quot;, \&quot;HIGH_DENSITY\&quot; (performance-oriented), or \&quot;LOW_DENSITY\&quot; (coverage-oriented) | [optional] 
**RadioRange** | **int32** | The Outdoor Deployment for signal distance from 300 to 10000 meters | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


