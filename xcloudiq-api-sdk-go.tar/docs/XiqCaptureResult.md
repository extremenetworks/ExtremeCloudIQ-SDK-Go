# XiqCaptureResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | [optional] 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**StartTime** | [**time.Time**](time.Time.md) | The packet capture start time | [optional] 
**EndTime** | [**time.Time**](time.Time.md) | The packet capture end time | [optional] 
**DeviceId** | **int64** | The device identifier | [optional] 
**Hostname** | **string** | The device host name | [optional] 
**MacAddress** | **string** | The device MAC address | [optional] 
**InterfaceName** | **string** | The interface name such as \&quot;WIFI0\&quot;, \&quot;WIFI1\&quot;, \&quot;ETH0\&quot;, etc. | [optional] 
**LocationId** | **int64** | The location ID | [optional] 
**Locations** | [**[]XiqLocationLegend**](XiqLocationLegend.md) | The detailed location | [optional] 
**Status** | [**XiqPacketCaptureStatus**](XiqPacketCaptureStatus.md) |  | [optional] 
**ErrorMessage** | **string** | The error message (may be empty). | [optional] 
**Storage** | [**XiqStorage**](XiqStorage.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


