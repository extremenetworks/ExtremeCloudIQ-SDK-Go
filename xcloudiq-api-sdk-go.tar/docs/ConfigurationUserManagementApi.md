# \ConfigurationUserManagementApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddKeyBasedPcgUsers**](ConfigurationUserManagementApi.md#AddKeyBasedPcgUsers) | **Post** /pcgs/key-based/network-policy-{policyId}/users | Add users to a PCG-enabled network policy
[**AssignPorts**](ConfigurationUserManagementApi.md#AssignPorts) | **Post** /pcgs/key-based/network-policy-{policyId}/port-assignments | Assign ports for devices (only support AP150W now) in a network policy
[**CreateEndUser**](ConfigurationUserManagementApi.md#CreateEndUser) | **Post** /endusers | Create an end user
[**CreateUserGroup**](ConfigurationUserManagementApi.md#CreateUserGroup) | **Post** /usergroups | Create user group
[**DeleteKeyBasedPcgUsers**](ConfigurationUserManagementApi.md#DeleteKeyBasedPcgUsers) | **Delete** /pcgs/key-based/network-policy-{policyId}/users | Delete users from a PCG-enabled network policy
[**DeletePcg**](ConfigurationUserManagementApi.md#DeletePcg) | **Delete** /pcgs/key-based/network-policy-{policyId} | Delete Private Client Group from a network policy
[**DeleteSsidUser**](ConfigurationUserManagementApi.md#DeleteSsidUser) | **Delete** /endusers/{id} | Delete end user by ID
[**DeleteUserGroup**](ConfigurationUserManagementApi.md#DeleteUserGroup) | **Delete** /usergroups/{id} | Delete user group by ID
[**EmailKeys**](ConfigurationUserManagementApi.md#EmailKeys) | **Post** /pcgs/key-based/network-policy-{policyId}/keys/:email | Send keys to specified users in PCG-enabled network policy via Email
[**GenerateKeys**](ConfigurationUserManagementApi.md#GenerateKeys) | **Post** /pcgs/key-based/network-policy-{policyId}/keys/:generate | Generate/regenerate shared keys for specified users in a PCG-enable network policy
[**GetKeyBasedPcgUsers**](ConfigurationUserManagementApi.md#GetKeyBasedPcgUsers) | **Get** /pcgs/key-based/network-policy-{policyId}/users | Get users for a PCG-enabled network policy
[**GetPortAssignments**](ConfigurationUserManagementApi.md#GetPortAssignments) | **Get** /pcgs/key-based/network-policy-{policyId}/port-assignments | Get port assignments for devices (only support AP150W now) in a network policy
[**ListEmailTemplates**](ConfigurationUserManagementApi.md#ListEmailTemplates) | **Get** /email-templates | List Email templates
[**ListEndUsers**](ConfigurationUserManagementApi.md#ListEndUsers) | **Get** /endusers | List end users
[**ListKeyBasedPrivateClientGroups**](ConfigurationUserManagementApi.md#ListKeyBasedPrivateClientGroups) | **Get** /pcgs/key-based | List Key-based Private Client Groups
[**ListSmsTemplates**](ConfigurationUserManagementApi.md#ListSmsTemplates) | **Get** /sms-templates | List SMS templates
[**ListUserGroups**](ConfigurationUserManagementApi.md#ListUserGroups) | **Get** /usergroups | List user groups
[**OnboardKeyBasedPrivateClientGroup**](ConfigurationUserManagementApi.md#OnboardKeyBasedPrivateClientGroup) | **Post** /pcgs/key-based/network-policy-{policyId}/:onboard | Create a Key-based Private Client Group for a network policy
[**SetupKeyBasedPrivateClientGroupNetworkPolicy**](ConfigurationUserManagementApi.md#SetupKeyBasedPrivateClientGroupNetworkPolicy) | **Post** /pcgs/key-based | Setup a Key-based Private Client Group
[**UpdateEndUser**](ConfigurationUserManagementApi.md#UpdateEndUser) | **Put** /endusers/{id} | Update an end user
[**UpdateKeyBasedPcgUsers**](ConfigurationUserManagementApi.md#UpdateKeyBasedPcgUsers) | **Put** /pcgs/key-based/network-policy-{policyId}/users | Replace all users in a PCG-enabled network policy
[**UpdateUserGroup**](ConfigurationUserManagementApi.md#UpdateUserGroup) | **Put** /usergroups/{id} | Update user group



## AddKeyBasedPcgUsers

> AddKeyBasedPcgUsers(ctx, policyId, xiqCreateKeyBasedPcgUsersRequest)

Add users to a PCG-enabled network policy

Add users to a PCG-enabled network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policyId** | **int64**| The network policy ID | 
**xiqCreateKeyBasedPcgUsersRequest** | [**XiqCreateKeyBasedPcgUsersRequest**](XiqCreateKeyBasedPcgUsersRequest.md)| The payload of add users to PCG-enabled network policy | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AssignPorts

> XiqPcgAssignPortsResponse AssignPorts(ctx, policyId, xiqPcgAssignPortsRequest)

Assign ports for devices (only support AP150W now) in a network policy

Assign ports for devices (only support AP150W now) in a network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policyId** | **int64**| The network policy ID | 
**xiqPcgAssignPortsRequest** | [**XiqPcgAssignPortsRequest**](XiqPcgAssignPortsRequest.md)| The payload of assign ports for devices | 

### Return type

[**XiqPcgAssignPortsResponse**](XiqPcgAssignPortsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateEndUser

> XiqEndUser CreateEndUser(ctx, xiqCreateEndUserRequest)

Create an end user

Create a new user.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateEndUserRequest** | [**XiqCreateEndUserRequest**](XiqCreateEndUserRequest.md)| Create end user request body | 

### Return type

[**XiqEndUser**](XiqEndUser.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUserGroup

> XiqUserGroup CreateUserGroup(ctx, xiqCreateUserGroupRequest)

Create user group

Create a new user group.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateUserGroupRequest** | [**XiqCreateUserGroupRequest**](XiqCreateUserGroupRequest.md)| Create user group request body | 

### Return type

[**XiqUserGroup**](XiqUserGroup.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteKeyBasedPcgUsers

> DeleteKeyBasedPcgUsers(ctx, policyId, xiqDeleteKeyBasedPcgUsersRequest)

Delete users from a PCG-enabled network policy

Delete users from a PCG-enabled network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policyId** | **int64**| The network policy ID | 
**xiqDeleteKeyBasedPcgUsersRequest** | [**XiqDeleteKeyBasedPcgUsersRequest**](XiqDeleteKeyBasedPcgUsersRequest.md)| The payload of delete Key-based PCG users request | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePcg

> DeletePcg(ctx, policyId, ids)

Delete Private Client Group from a network policy

Delete Private Client Group settings from a network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policyId** | **int64**| The network policy ID | 
**ids** | [**[]int64**](int64.md)| The IDs of the Key-based PCG entity to be deleted from network policy | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSsidUser

> DeleteSsidUser(ctx, id)

Delete end user by ID

Delete a specific end user.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The end user ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteUserGroup

> DeleteUserGroup(ctx, id)

Delete user group by ID

Delete the user-group for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The user group ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## EmailKeys

> EmailKeys(ctx, policyId, userIds)

Send keys to specified users in PCG-enabled network policy via Email

Send keys to specified users in PCG-enabled network policy via Email.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policyId** | **int64**| The network policy ID | 
**userIds** | [**[]int64**](int64.md)| The user IDs | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GenerateKeys

> GenerateKeys(ctx, policyId, userIds)

Generate/regenerate shared keys for specified users in a PCG-enable network policy

Generate/regenerate shared keys for specified users in a specific PCG-enable network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policyId** | **int64**| The network policy ID | 
**userIds** | [**[]int64**](int64.md)| The user IDs | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeyBasedPcgUsers

> []XiqKeyBasedPcgUser GetKeyBasedPcgUsers(ctx, policyId)

Get users for a PCG-enabled network policy

Get users for a specific PCG-enabled network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policyId** | **int64**| The network policy ID | 

### Return type

[**[]XiqKeyBasedPcgUser**](XiqKeyBasedPcgUser.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPortAssignments

> XiqGetPortAssignmentDetailsResponse GetPortAssignments(ctx, policyId)

Get port assignments for devices (only support AP150W now) in a network policy

Get port assignments for devices (only support AP150W now) in a network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policyId** | **int64**| The network policy ID | 

### Return type

[**XiqGetPortAssignmentDetailsResponse**](XiqGetPortAssignmentDetailsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListEmailTemplates

> []XiqEmailTemplate ListEmailTemplates(ctx, optional)

List Email templates

List all Email notification templates.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListEmailTemplatesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListEmailTemplatesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **passwordType** | [**optional.Interface of XiqPasswordType**](.md)| The password type | 

### Return type

[**[]XiqEmailTemplate**](XiqEmailTemplate.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListEndUsers

> PagedXiqEndUser ListEndUsers(ctx, optional)

List end users

List a page of end users.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListEndUsersOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListEndUsersOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number | [default to 1]
 **limit** | **optional.Int32**| Page Size | [default to 10]
 **userGroupIds** | [**optional.Interface of []int64**](int64.md)| The user group IDs | 

### Return type

[**PagedXiqEndUser**](PagedXiqEndUser.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListKeyBasedPrivateClientGroups

> []XiqKeyBasedPcg ListKeyBasedPrivateClientGroups(ctx, )

List Key-based Private Client Groups

List all Key-based Private Client Groups.

### Required Parameters

This endpoint does not need any parameter.

### Return type

[**[]XiqKeyBasedPcg**](XiqKeyBasedPcg.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSmsTemplates

> []XiqSmsTemplate ListSmsTemplates(ctx, optional)

List SMS templates

List all SMS notification templates.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListSmsTemplatesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListSmsTemplatesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **passwordType** | [**optional.Interface of XiqPasswordType**](.md)| The password type | 

### Return type

[**[]XiqSmsTemplate**](XiqSmsTemplate.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListUserGroups

> PagedXiqUserGroup ListUserGroups(ctx, optional)

List user groups

List a page of user groups.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListUserGroupsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListUserGroupsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number | [default to 1]
 **limit** | **optional.Int32**| Page Size | [default to 10]
 **passwordDbLocation** | [**optional.Interface of XiqPasswordDbLocation**](.md)| The password DB location | 
 **passwordType** | [**optional.Interface of XiqPasswordType**](.md)| The password type | 

### Return type

[**PagedXiqUserGroup**](PagedXiqUserGroup.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## OnboardKeyBasedPrivateClientGroup

> OnboardKeyBasedPrivateClientGroup(ctx, policyId, xiqOnboardKeyBasedPcgRequest)

Create a Key-based Private Client Group for a network policy

Create a Key-based Private Client Group for a specific network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policyId** | **int64**| The network policy ID | 
**xiqOnboardKeyBasedPcgRequest** | [**XiqOnboardKeyBasedPcgRequest**](XiqOnboardKeyBasedPcgRequest.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetupKeyBasedPrivateClientGroupNetworkPolicy

> SetupKeyBasedPrivateClientGroupNetworkPolicy(ctx, xiqInitKeyBasedPcgNetworkPolicyRequest)

Setup a Key-based Private Client Group

Setup a Key-based Private Client Group, including network policy, user, user group, SSID, etc.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqInitKeyBasedPcgNetworkPolicyRequest** | [**XiqInitKeyBasedPcgNetworkPolicyRequest**](XiqInitKeyBasedPcgNetworkPolicyRequest.md)| The request to setup Key-based PCG network policy | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEndUser

> XiqEndUser UpdateEndUser(ctx, id, xiqUpdateEndUserRequest)

Update an end user

Update a specific end user.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The end user ID | 
**xiqUpdateEndUserRequest** | [**XiqUpdateEndUserRequest**](XiqUpdateEndUserRequest.md)| Update end user request body | 

### Return type

[**XiqEndUser**](XiqEndUser.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateKeyBasedPcgUsers

> UpdateKeyBasedPcgUsers(ctx, policyId, xiqUpdateKeyBasedPcgUsersRequest)

Replace all users in a PCG-enabled network policy

Replace all users in a specific PCG-enabled network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policyId** | **int64**| The network policy ID | 
**xiqUpdateKeyBasedPcgUsersRequest** | [**XiqUpdateKeyBasedPcgUsersRequest**](XiqUpdateKeyBasedPcgUsersRequest.md)| The payload of update Key-based PCG users request | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateUserGroup

> XiqUserGroup UpdateUserGroup(ctx, id, xiqUpdateUserGroupRequest)

Update user group

Update existing user group information.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The user group ID. | 
**xiqUpdateUserGroupRequest** | [**XiqUpdateUserGroupRequest**](XiqUpdateUserGroupRequest.md)| Update user-group request body | 

### Return type

[**XiqUserGroup**](XiqUserGroup.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

