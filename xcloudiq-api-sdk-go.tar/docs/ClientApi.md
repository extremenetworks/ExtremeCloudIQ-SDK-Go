# \ClientApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetClient**](ClientApi.md#GetClient) | **Get** /clients/{id} | Get client info
[**GetClientSummary**](ClientApi.md#GetClientSummary) | **Get** /clients/summary | Get client summary metrics
[**GetClientUsage**](ClientApi.md#GetClientUsage) | **Get** /clients/usage | Get usage per client
[**ListActiveClients**](ClientApi.md#ListActiveClients) | **Get** /clients/active | List active clients



## GetClient

> XiqClient GetClient(ctx, id, optional)

Get client info

Get client detailed information.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The client ID | 
 **optional** | ***GetClientOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetClientOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **views** | [**optional.Interface of []XiqClientView**](XiqClientView.md)| The views to return client fields (Check fields for each view at XiqClientView schema) | 
 **fields** | [**optional.Interface of []XiqClientField**](XiqClientField.md)| The client fields to return | 

### Return type

[**XiqClient**](XiqClient.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClientSummary

> XiqClientSummary GetClientSummary(ctx, optional)

Get client summary metrics

Get number of connected wireless clients and number of detected wired clients.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***GetClientSummaryOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetClientSummaryOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **locationIds** | [**optional.Interface of []int64**](int64.md)| The location IDs | 
 **deviceIds** | [**optional.Interface of []int64**](int64.md)| The device IDs | 
 **vlans** | [**optional.Interface of []int32**](int32.md)| The associate VLAN IDs | 
 **userProfileNames** | [**optional.Interface of []string**](string.md)| The user profile names | 
 **ssids** | [**optional.Interface of []string**](string.md)| The SSIDs | 

### Return type

[**XiqClientSummary**](XiqClientSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClientUsage

> []XiqClientUsage GetClientUsage(ctx, clientIds, startTime, endTime)

Get usage per client

Get the client usage.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**clientIds** | [**[]int64**](int64.md)| The client IDs | 
**startTime** | **int64**| The start time to query, epoch time in milliseconds since 1/1/1970 | 
**endTime** | **int64**| The end time to query, epoch time in milliseconds since 1/1/1970 | 

### Return type

[**[]XiqClientUsage**](XiqClientUsage.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListActiveClients

> PagedXiqClient ListActiveClients(ctx, optional)

List active clients

List active clients with filters and pagination.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListActiveClientsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListActiveClientsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **locationIds** | [**optional.Interface of []int64**](int64.md)| The location IDs | 
 **deviceIds** | [**optional.Interface of []int64**](int64.md)| The device IDs | 
 **vlans** | [**optional.Interface of []int32**](int32.md)| The associate vlan IDs | 
 **userProfileNames** | [**optional.Interface of []string**](string.md)| The user profile names | 
 **ssids** | [**optional.Interface of []string**](string.md)| The SSIDs | 
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **views** | [**optional.Interface of []XiqClientView**](XiqClientView.md)| The views to return client fields (Check fields for each view at XiqClientView schema) | 
 **fields** | [**optional.Interface of []XiqClientField**](XiqClientField.md)| The client fields to return | 

### Return type

[**PagedXiqClient**](PagedXiqClient.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

