# XiqUpdateRadioProfileRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The radio profile name | [optional] 
**Description** | **string** | The radio profile description. | [optional] 
**TransmissionPower** | **int32** | The transmission power floor in the range of 1-20 dBm or null for Auto. | [optional] 
**MaxTransmitPower** | **int32** | The maximum transmit power in the range of 10-20 dBm. | [optional] 
**TransmissionPowerFloor** | **int32** | The transmission power floor in the range of 2-20 dBm. | [optional] 
**TransmissionPowerMaxDrop** | **int32** | The transmission power max drop in the range of 0-18 dB. | [optional] 
**MaxClients** | **int32** | The maximum number of clients in the range of 1-255. | [optional] 
**EnableClientTransmissionPower** | **bool** | Whether or not client transmission power control (802.11h) is enabled. | [optional] 
**ClientTransmissionPower** | **int32** | The client transmission power (in the range of 1-20 dBm) if it is enabled. | [optional] 
**RadioMode** | [**XiqRadioMode**](XiqRadioMode.md) |  | [optional] 
**EnableOfdma** | **bool** | Whether to enable Orthogonal Frequency Division Multiple Access (802.11ax) for multiple-user access by subdividing a channel. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


