# XiqCopilotWirelessEvent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AverageValue** | **float64** | the average duration to associate/authenticate | [optional] 
**MaximumValue** | **float64** | the maximum duration to associate/authenticate | [optional] 
**Mac** | **string** | mac address | 
**OsType** | **string** | os type | [optional] 
**Threshold** | **float64** | the threshold for association/authentication | [optional] 
**Hostname** | **string** | the hostname | [optional] 
**Ssid** | **string** | the threshold for association/authentication | [optional] 
**ClientId** | **string** | the threshold for association/authentication | 
**RetriesData** | [**XiqWirelessEventRetriesEntity**](XiqWirelessEventRetriesEntity.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


