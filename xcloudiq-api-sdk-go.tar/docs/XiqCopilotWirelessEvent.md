# XiqCopilotWirelessEvent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AverageValue** | **float64** | The average duration to associate/authenticate | [optional] 
**MaximumValue** | **float64** | The maximum duration to associate/authenticate | [optional] 
**Mac** | **string** | The mac address | 
**OsType** | **string** | The os type | [optional] 
**Threshold** | **float64** | The threshold for association/authentication | [optional] 
**Hostname** | **string** | The hostname | [optional] 
**Ssid** | **string** | The SSID | [optional] 
**ClientId** | **string** | The unique identifier for clients | 
**RetriesData** | [**XiqWirelessEventRetriesEntity**](XiqWirelessEventRetriesEntity.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


