# XiqAnomalyLocationEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LocationType** | [**XiqLocationType**](XiqLocationType.md) |  | [optional] 
**LocationId** | **int64** | the location id | [optional] 
**LocationName** | **string** | the location name | [optional] 
**Pinned** | **bool** | is location pinned | [optional] 
**Muted** | **bool** | the location muted | [optional] 
**Severity** | [**XiqAnomalySeverity**](XiqAnomalySeverity.md) |  | [optional] 
**SeverityId** | **int32** | the severity id | [optional] 
**Summary** | **string** | the anomaly summary | [optional] 
**AffectedDeviceCount** | **int32** | the affected number of devices | [optional] 
**LastDetectedTime** | **int64** | the last detected time | [optional] 
**AnomalyType** | [**XiqAnomalyType**](XiqAnomalyType.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


