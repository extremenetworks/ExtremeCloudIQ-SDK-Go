# XiqWifiEfficiencyStatsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TotalClientSessions** | **int64** | The total client sessions | [optional] 
**ShowTxData** | **bool** | The show tx data | [optional] 
**SessionsData** | [**[]XiqSessionsDataEntity**](XiqSessionsDataEntity.md) | The sessions data | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


