# XiqUpdateRadiusClientObjectRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The RADIUS client object name. | 
**Description** | **string** | The RADIUS client object description. | [optional] 
**EnableInjectOperatorNameAttribute** | **bool** | The flag for enable Inject Operator Name Attribute | 
**EnableMessageAuthenticatorAttribute** | **bool** | The flag for enable message authenticator attribute | 
**EnablePermitDynamicAuthorizationMessageChange** | **bool** | The flag for enable permit dynamic authorization message change | 
**RetryInterval** | **int32** | The retry interval, 60 - 100000000 seconds | 
**AccountingInterimUpdateInterval** | **int32** | The accounting interim update interval, 60 - 100000000 seconds | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


