# XiqAdvancedOnboardDeviceResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SuccessDevices** | [**[]XiqSuccessOnboardDevice**](XiqSuccessOnboardDevice.md) | The success devices | [optional] 
**FailureDevices** | [**[]XiqFailureOnboardDevice**](XiqFailureOnboardDevice.md) | The failure devices | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


