# XiqLocationTreeDevice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeviceName** | **string** | The name of the device. | 
**SerialNumber** | **string** | The device serial number. | [optional] 
**MacAddress** | **string** | The device MAC address. | 
**DeviceFunction** | **string** | The device function, such as AP, Router, Switch, etc. | [optional] 
**ProductType** | **string** | The product type, such as: AP_230, BR_100, NX9600, etc. | [optional] 
**IpAddress** | **string** | The device IPv4 address. | [optional] 
**LocationId** | **int64** | The location ID of the device on the location hierarchy. | [optional] 
**MapName** | **string** | The associated background map for the device. | [optional] 
**X** | **float64** | The x-position of the device relative to the horizontal scale in meter. | [optional] 
**Y** | **float64** | The y-position of the device relative to the vertical scale in meter. | [optional] 
**ScaleX** | **float64** | The horizontal scale for the background map in meter. | [optional] 
**ScaleY** | **float64** | The vertical scale for the background map in meter. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


