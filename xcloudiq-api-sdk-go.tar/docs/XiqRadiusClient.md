# XiqRadiusClient

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The RADIUS client ID | [optional] 
**SharedSecret** | **string** | The shared secret of RADIUS client | [optional] 
**Description** | **string** | The RADIUS client description | [optional] 
**L3AddressProfileId** | **int64** | The associate L3 address profile ID | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


