# XiqUpdateAnomaliesAndDevicesRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AnomalyDetails** | [**[]XiqUpdateActionAnomalyDetails**](XiqUpdateActionAnomalyDetails.md) | The anomaly details | 
**ActionType** | [**XiqActionType**](XiqActionType.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


