# XiqViq

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Devices** | **int32** | Total # of all licensed devices | [optional] 
**Standalone** | **bool** | Returns true if HIQ is not enabled, otherwise returns false | [optional] 
**Expired** | **bool** | Whether VIQ is expired | [optional] 
**CustomerId** | **string** | The customer ID, also known as Salesforce customer ID | [optional] 
**VhmId** | **string** | The VIQ ID | [optional] 
**OwnerId** | **int64** | The owner account ID | [optional] 
**Licenses** | [**[]XiqViqLicense**](XiqViqLicense.md) | The license list | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


