# XiqSetSsidModePpskRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**KeyManagement** | [**XiqSsidPpskKeyManagement**](XiqSsidPpskKeyManagement.md) |  | 
**EncryptionMethod** | [**XiqSsidPskEncryptionMethod**](XiqSsidPskEncryptionMethod.md) |  | 
**UserGroupIds** | **[]int64** | The user group IDs to be attached to the SSID, cannot be empty | 
**EnableMaxClientsPerPpsk** | **bool** | Flag for enabling the max clients per PPSK | 
**MaxClientsPerPpsk** | **int32** | The max clients (0-15) per PPSK if enabled enable_max_clients_per_ppsk flag, 0 means unlimited | [optional] 
**EnableMacBind** | **bool** | Flag for enabling mac binding or not. This setting is only supported with local PPSK. | 
**MaxMacsPerPpsk** | **int32** | Set the max MAC binding numbers per private PSK, Min:1, Max:5 | [optional] 
**PpskServerId** | **int64** | The PPSK server device ID | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


