# XiqUpdateRadiusProxyRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The RADIUS proxy name | [optional] 
**Description** | **string** | The RADIUS proxy description | [optional] 
**FormatType** | [**XiqRadiusProxyFormatType**](XiqRadiusProxyFormatType.md) |  | [optional] 
**RetryCount** | **int32** | The retry count of RADIUS proxy | [optional] 
**RetryDelay** | **int32** | The retry delay of RADIUS proxy | [optional] 
**DeadTime** | **int32** | The dead time of RADIUS proxy | [optional] 
**EnableInjectOperatorNameAttribute** | **bool** | The flag for enable inject operator name attribute | [optional] 
**Clients** | [**[]XiqUpdateRadiusClient**](XiqUpdateRadiusClient.md) | The RADIUS clients of RADIUS proxy | [optional] 
**Realms** | [**[]XiqUpdateRadiusProxyRealm**](XiqUpdateRadiusProxyRealm.md) | The RADIUS realms of RADIUS proxy, provide at least two default RADIUS realms with name &#39;DEFAULT&#39; and &#39;NULL&#39; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


