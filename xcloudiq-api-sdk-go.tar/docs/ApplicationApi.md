# \ApplicationApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ListApplicationTopNClientsUsage**](ApplicationApi.md#ListApplicationTopNClientsUsage) | **Get** /applications/{id}/clients/top{n} | List the TopN clients for a application
[**ListApplications**](ApplicationApi.md#ListApplications) | **Get** /applications | List the applications
[**ListTopNApplicationsUsage**](ApplicationApi.md#ListTopNApplicationsUsage) | **Get** /applications/top{n} | List the TopN applications



## ListApplicationTopNClientsUsage

> []XiqApplicationTopNClientsUsage ListApplicationTopNClientsUsage(ctx, id, n, startTime, endTime)

List the TopN clients for a application

List the TopN clients by usage for a specific application.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The application ID | 
**n** | **int32**| The TopN number | 
**startTime** | **int64**| The start time for querying top client usage of application | 
**endTime** | **int64**| The end time for querying top application usage of application | 

### Return type

[**[]XiqApplicationTopNClientsUsage**](XiqApplicationTopNClientsUsage.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListApplications

> PagedXiqApplication ListApplications(ctx, optional)

List the applications

List a page of applications by filter.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListApplicationsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListApplicationsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **name** | **optional.String**| Application Name | 
 **detectionProtocol** | [**optional.Interface of XiqApplicationDetectionProtocol**](.md)| Application Detection Protocol, only for custom Application | 
 **detectionType** | [**optional.Interface of XiqApplicationDetectionType**](.md)| Application Detection Type, only for custom Application | 
 **predefined** | **optional.Bool**| Flag to filter predefined or custom Application | 
 **sortField** | [**optional.Interface of XiqApplicationSortField**](.md)| The sort field | 
 **order** | [**optional.Interface of XiqSortOrder**](.md)| The sort order (ascending by default) | 

### Return type

[**PagedXiqApplication**](PagedXiqApplication.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListTopNApplicationsUsage

> []XiqTopNApplicationsUsage ListTopNApplicationsUsage(ctx, n, startTime, endTime)

List the TopN applications

List the TopN applications by usage.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**n** | **int32**| The TopN number | 
**startTime** | **int64**| The start time for querying top application usage | 
**endTime** | **int64**| The end time for querying top application usage | 

### Return type

[**[]XiqTopNApplicationsUsage**](XiqTopNApplicationsUsage.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

