# XiqDeviceLocationAssignment

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LocationId** | **int64** | The assigned location ID, it must be FLOOR type | 
**X** | **float64** | The horizontal value in the floor map | [optional] 
**Y** | **float64** | The vertical value in the floor map | [optional] 
**Latitude** | **float64** | The latitude in the geography | [optional] 
**Longitude** | **float64** | The longitude in the geography | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


