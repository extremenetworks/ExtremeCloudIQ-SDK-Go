# XiqConnectivityExperienceData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | the unique identifier | [optional] 
**Info** | **string** | the info related to connectivity experience view type | [optional] 
**Name** | **string** | the location/ssid/os-name based on view type | 
**QualityIndex** | **int32** | the quality index | 
**TrendIndicator** | [**XiqTrendIndicator**](XiqTrendIndicator.md) |  | 
**QualityIndexGraph** | [**[]XiqDataPoint**](XiqDataPoint.md) | the quality index graph | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


