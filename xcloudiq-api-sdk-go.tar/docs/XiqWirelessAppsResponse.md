# XiqWirelessAppsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TotalClients** | **int32** | the total clients | [optional] 
**MostActiveApp** | **string** | the most active app | [optional] 
**MostActiveUser** | **string** | the most active user | [optional] 
**TotalApps** | **int32** | the total apps | [optional] 
**TotalUsers** | **int32** | the total users | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


