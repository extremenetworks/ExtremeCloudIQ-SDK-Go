# XiqDeviceCpuMemoryUsage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AverageCpu** | **int32** | The device average cpu usage | [optional] 
**AverageMemory** | **int32** | The device average memory usage | [optional] 
**Timestamp** | **int64** | The timestamp for data aggregate | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


