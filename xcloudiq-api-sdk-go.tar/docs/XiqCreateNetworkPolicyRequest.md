# XiqCreateNetworkPolicyRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The network policy name | 
**Description** | **string** | The network policy description | [optional] 
**Type** | [**XiqNetworkPolicyType**](XiqNetworkPolicyType.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


