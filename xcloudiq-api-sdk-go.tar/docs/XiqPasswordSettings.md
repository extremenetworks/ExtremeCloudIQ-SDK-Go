# XiqPasswordSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnableLetters** | **bool** | Enable use of letters | [optional] 
**EnableNumbers** | **bool** | Enable use of numbers | [optional] 
**EnableSpecialCharacters** | **bool** | Enable use of special characters | [optional] 
**PasswordConcatString** | **string** | The password concatenated string | [optional] 
**PskGenerationMethod** | [**XiqPskGenerationMethod**](XiqPskGenerationMethod.md) |  | 
**PasswordCharacterTypes** | [**XiqPasswordCharacterType**](XiqPasswordCharacterType.md) |  | 
**PasswordLength** | **int32** | The maximun password string length | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


