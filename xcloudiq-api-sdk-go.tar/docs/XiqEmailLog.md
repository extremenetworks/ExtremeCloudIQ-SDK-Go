# XiqEmailLog

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The Email log id | 
**Username** | **string** | The username | [optional] 
**OrgId** | **int64** | The org id | [optional] 
**Timestamp** | **int64** | The email log timestamp | [optional] 
**UserId** | **int64** | The user id | [optional] 
**CustomerId** | **string** | The customer id | [optional] 
**ApproverEmail** | **string** | The approver Email | [optional] 
**Status** | **string** | The email log status | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


