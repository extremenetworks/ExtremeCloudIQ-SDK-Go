# \ConfigurationPolicyApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AttachCwpToSsid**](ConfigurationPolicyApi.md#AttachCwpToSsid) | **Post** /ssids/{id}/cwp/:attach | Attach CWP to an SSID
[**AttachRadiusServerGroupToSsid**](ConfigurationPolicyApi.md#AttachRadiusServerGroupToSsid) | **Post** /ssids/{id}/radius-server-group/:attach | Attach radius server group to an SSID
[**AttachUserProfileToSsid**](ConfigurationPolicyApi.md#AttachUserProfileToSsid) | **Post** /ssids/{id}/user-profile/:attach | Attach user profile to an SSID
[**ChangePskPassword**](ConfigurationPolicyApi.md#ChangePskPassword) | **Put** /ssids/{id}/psk/password | Change the SSID PSK password
[**CreateClassificationRule**](ConfigurationPolicyApi.md#CreateClassificationRule) | **Post** /classification-rules | Create classification rule
[**CreateCloudConfigGroup**](ConfigurationPolicyApi.md#CreateCloudConfigGroup) | **Post** /ccgs | Create new cloud config group
[**CreateUserProfile**](ConfigurationPolicyApi.md#CreateUserProfile) | **Post** /user-profiles | Create a user profile
[**DeleteClassificationRule**](ConfigurationPolicyApi.md#DeleteClassificationRule) | **Delete** /classification-rules/{id} | Delete classification rule by ID
[**DeleteCloudConfigGroup**](ConfigurationPolicyApi.md#DeleteCloudConfigGroup) | **Delete** /ccgs/{id} | Delete a cloud config group
[**DeleteCoUserProfile**](ConfigurationPolicyApi.md#DeleteCoUserProfile) | **Delete** /user-profiles/{id} | Delete an user profile by ID
[**DisableSsidCwp**](ConfigurationPolicyApi.md#DisableSsidCwp) | **Post** /ssids/{id}/cwp/:disable | Disable the CWP on the SSID
[**EnableSsidCwp**](ConfigurationPolicyApi.md#EnableSsidCwp) | **Post** /ssids/{id}/cwp/:enable | Enable and attach the CWP on the SSID
[**GetClassificationRule**](ConfigurationPolicyApi.md#GetClassificationRule) | **Get** /classification-rules/{id} | Get a classification rule by ID
[**GetCloudConfigGroup**](ConfigurationPolicyApi.md#GetCloudConfigGroup) | **Get** /ccgs/{id} | Get a cloud config group
[**GetUserProfile**](ConfigurationPolicyApi.md#GetUserProfile) | **Get** /user-profiles/{id} | Get user profile by ID
[**ListClassificationRules**](ConfigurationPolicyApi.md#ListClassificationRules) | **Get** /classification-rules | List classification rules
[**ListCloudConfigGroups**](ConfigurationPolicyApi.md#ListCloudConfigGroups) | **Get** /ccgs | List clould config groups
[**ListL3AddressProfiles**](ConfigurationPolicyApi.md#ListL3AddressProfiles) | **Get** /l3-address-profiles | List L3 address profiles
[**ListSsids**](ConfigurationPolicyApi.md#ListSsids) | **Get** /ssids | List SSIDs
[**ListUserProfiles**](ConfigurationPolicyApi.md#ListUserProfiles) | **Get** /user-profiles | List user profiles
[**RenameSsid**](ConfigurationPolicyApi.md#RenameSsid) | **Post** /ssids/{id}/:rename | Rename SSID (Wireless name)
[**SetSsidModeDot1x**](ConfigurationPolicyApi.md#SetSsidModeDot1x) | **Put** /ssids/{id}/mode/dot1x | Change the SSID mode to 802.1x
[**SetSsidModeOpen**](ConfigurationPolicyApi.md#SetSsidModeOpen) | **Put** /ssids/{id}/mode/open | Change the SSID mode to open access
[**SetSsidModePpsk**](ConfigurationPolicyApi.md#SetSsidModePpsk) | **Put** /ssids/{id}/mode/ppsk | Change the SSID mode to PPSK
[**SetSsidModePsk**](ConfigurationPolicyApi.md#SetSsidModePsk) | **Put** /ssids/{id}/mode/psk | Change the SSID mode to PSK
[**SetSsidModeWep**](ConfigurationPolicyApi.md#SetSsidModeWep) | **Put** /ssids/{id}/mode/wep | Change the SSID mode to WEP
[**UpdateClassificationRule**](ConfigurationPolicyApi.md#UpdateClassificationRule) | **Put** /classification-rules/{id} | Update classification rule
[**UpdateCloudConfigGroup**](ConfigurationPolicyApi.md#UpdateCloudConfigGroup) | **Put** /ccgs/{id} | Update cloud config group information
[**UpdateCoUserProfile**](ConfigurationPolicyApi.md#UpdateCoUserProfile) | **Put** /user-profiles/{id} | Update user profile



## AttachCwpToSsid

> AttachCwpToSsid(ctx, id, body)

Attach CWP to an SSID

Attach CWP to an SSID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**body** | **int64**| The CWP ID to be attached to the SSID. For CWP with only User Auth on Captive Web Portal enabled, please also attach a RADIUS server group or enable ExtremeCloud IQ Authentication Service. | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AttachRadiusServerGroupToSsid

> AttachRadiusServerGroupToSsid(ctx, id, body)

Attach radius server group to an SSID

Attach radius server group to an SSID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**body** | **int64**| The radius server group ID to be attached to the SSID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AttachUserProfileToSsid

> AttachUserProfileToSsid(ctx, id, body)

Attach user profile to an SSID

Attach user profile to an SSID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**body** | **int64**| The user profile ID to be attached to the SSID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ChangePskPassword

> ChangePskPassword(ctx, id, body)

Change the SSID PSK password

Change the SSID PSK password.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**body** | **string**| The new SSID PSK password | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClassificationRule

> XiqClassificationRule CreateClassificationRule(ctx, xiqCreateClassificationRuleRequest)

Create classification rule

Create a new classification rule.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateClassificationRuleRequest** | [**XiqCreateClassificationRuleRequest**](XiqCreateClassificationRuleRequest.md)| The payload to create a new classification rule | 

### Return type

[**XiqClassificationRule**](XiqClassificationRule.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateCloudConfigGroup

> XiqCloudConfigGroup CreateCloudConfigGroup(ctx, xiqCreateCloudConfigGroupRequest)

Create new cloud config group

Create a new cloud config group.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateCloudConfigGroupRequest** | [**XiqCreateCloudConfigGroupRequest**](XiqCreateCloudConfigGroupRequest.md)| Create new cloud config group request body | 

### Return type

[**XiqCloudConfigGroup**](XiqCloudConfigGroup.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUserProfile

> XiqUserProfile CreateUserProfile(ctx, xiqCreateUserProfileRequest)

Create a user profile

Create a new user profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateUserProfileRequest** | [**XiqCreateUserProfileRequest**](XiqCreateUserProfileRequest.md)| The request body to create new user profile. | 

### Return type

[**XiqUserProfile**](XiqUserProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteClassificationRule

> DeleteClassificationRule(ctx, id)

Delete classification rule by ID

Delete an existing classification rule by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The classification rule ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteCloudConfigGroup

> DeleteCloudConfigGroup(ctx, id)

Delete a cloud config group

Delete a specific cloud config group by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The cloud config group ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteCoUserProfile

> DeleteCoUserProfile(ctx, id)

Delete an user profile by ID

Delete an existing user profile by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The user profile ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DisableSsidCwp

> DisableSsidCwp(ctx, id)

Disable the CWP on the SSID

Disable the CWP on the SSID

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## EnableSsidCwp

> EnableSsidCwp(ctx, id, body)

Enable and attach the CWP on the SSID

Enable and attach the CWP on the SSID

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**body** | **int64**| The new CWP ID.  For CWP with only User Auth on Captive Web Portal enabled, please also attach a RADIUS server group or enable ExtremeCloud IQ Authentication Service. | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClassificationRule

> XiqClassificationRule GetClassificationRule(ctx, id)

Get a classification rule by ID

Get a specific classification rule.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The classification Rule ID | 

### Return type

[**XiqClassificationRule**](XiqClassificationRule.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCloudConfigGroup

> XiqCloudConfigGroup GetCloudConfigGroup(ctx, id)

Get a cloud config group

Get cloud config group info for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The cloud config group ID | 

### Return type

[**XiqCloudConfigGroup**](XiqCloudConfigGroup.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUserProfile

> XiqUserProfile GetUserProfile(ctx, id)

Get user profile by ID

Get user profile details for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The user profile ID | 

### Return type

[**XiqUserProfile**](XiqUserProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListClassificationRules

> PagedXiqClassificationRule ListClassificationRules(ctx, optional)

List classification rules

List a page of classification rules.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListClassificationRulesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListClassificationRulesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqClassificationRule**](PagedXiqClassificationRule.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCloudConfigGroups

> PagedXiqCloudConfigGroup ListCloudConfigGroups(ctx, optional)

List clould config groups

List a papge of cloud config groups.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListCloudConfigGroupsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListCloudConfigGroupsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqCloudConfigGroup**](PagedXiqCloudConfigGroup.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListL3AddressProfiles

> []XiqL3AddressProfile ListL3AddressProfiles(ctx, addressType)

List L3 address profiles

List all L3 Address Profiles.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**addressType** | **string**| The address type | 

### Return type

[**[]XiqL3AddressProfile**](XiqL3AddressProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSsids

> PagedXiqSsid ListSsids(ctx, optional)

List SSIDs

List SSIDs with filter and pagination.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListSsidsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListSsidsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqSsid**](PagedXiqSsid.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListUserProfiles

> PagedXiqUserProfile ListUserProfiles(ctx, optional)

List user profiles

List a page of user profiles.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListUserProfilesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListUserProfilesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqUserProfile**](PagedXiqUserProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RenameSsid

> RenameSsid(ctx, id, body)

Rename SSID (Wireless name)

Change SSID broadcast name (Wireless name).

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**body** | **string**| The new SSID name | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetSsidModeDot1x

> SetSsidModeDot1x(ctx, id, xiqSetSsidModeDot1xRequest)

Change the SSID mode to 802.1x

Change the SSID mode to 802.1x.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**xiqSetSsidModeDot1xRequest** | [**XiqSetSsidModeDot1xRequest**](XiqSetSsidModeDot1xRequest.md)| The payload to change the SSID mode to 802.1x | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetSsidModeOpen

> SetSsidModeOpen(ctx, id)

Change the SSID mode to open access

Change the SSID mode to open access.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetSsidModePpsk

> SetSsidModePpsk(ctx, id, xiqSetSsidModePpskRequest)

Change the SSID mode to PPSK

Change the SSID mode to PPSK.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**xiqSetSsidModePpskRequest** | [**XiqSetSsidModePpskRequest**](XiqSetSsidModePpskRequest.md)| The payload to change the SSID mode to PPSK | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetSsidModePsk

> SetSsidModePsk(ctx, id, xiqSetSsidModePskRequest)

Change the SSID mode to PSK

Change the SSID mode to PSK.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**xiqSetSsidModePskRequest** | [**XiqSetSsidModePskRequest**](XiqSetSsidModePskRequest.md)| The payload to change the SSID mode to PSK | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetSsidModeWep

> SetSsidModeWep(ctx, id, xiqSetSsidModeWepRequest)

Change the SSID mode to WEP

Change the SSID mode to WEP.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**xiqSetSsidModeWepRequest** | [**XiqSetSsidModeWepRequest**](XiqSetSsidModeWepRequest.md)| The payload to change the SSID mode to WEP | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClassificationRule

> XiqClassificationRule UpdateClassificationRule(ctx, id, xiqUpdateClassificationRuleRequest)

Update classification rule

Update the exist classification rule.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The classification rule ID | 
**xiqUpdateClassificationRuleRequest** | [**XiqUpdateClassificationRuleRequest**](XiqUpdateClassificationRuleRequest.md)| The payload to update exist classification rule | 

### Return type

[**XiqClassificationRule**](XiqClassificationRule.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCloudConfigGroup

> XiqCloudConfigGroup UpdateCloudConfigGroup(ctx, id, xiqUpdateCloudConfigGroupRequest)

Update cloud config group information

Update the cloud config group details having the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The cloud config group ID | 
**xiqUpdateCloudConfigGroupRequest** | [**XiqUpdateCloudConfigGroupRequest**](XiqUpdateCloudConfigGroupRequest.md)| Update cloud config group request body | 

### Return type

[**XiqCloudConfigGroup**](XiqCloudConfigGroup.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCoUserProfile

> XiqUserProfile UpdateCoUserProfile(ctx, id, xiqUpdateUserProfileRequest)

Update user profile

Update an existing user profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The user profile ID. | 
**xiqUpdateUserProfileRequest** | [**XiqUpdateUserProfileRequest**](XiqUpdateUserProfileRequest.md)| The payload of user profile. | 

### Return type

[**XiqUserProfile**](XiqUserProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

