# \ConfigurationPolicyApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AttachCwpToSsid**](ConfigurationPolicyApi.md#AttachCwpToSsid) | **Post** /ssids/{id}/cwp/:attach | Attach CWP to an SSID
[**AttachRadiusServerGroupToSsid**](ConfigurationPolicyApi.md#AttachRadiusServerGroupToSsid) | **Post** /ssids/{id}/radius-server-group/:attach | Attach radius server group to an SSID
[**AttachUserProfileToSsid**](ConfigurationPolicyApi.md#AttachUserProfileToSsid) | **Post** /ssids/{id}/user-profile/:attach | Attach user profile to an SSID
[**ChangePskPassword**](ConfigurationPolicyApi.md#ChangePskPassword) | **Put** /ssids/{id}/psk/password | Change the SSID PSK password
[**CreateClassificationRule**](ConfigurationPolicyApi.md#CreateClassificationRule) | **Post** /classification-rules | Create classification rule
[**CreateCloudConfigGroup**](ConfigurationPolicyApi.md#CreateCloudConfigGroup) | **Post** /ccgs | Create new cloud config group
[**CreateIotProfile**](ConfigurationPolicyApi.md#CreateIotProfile) | **Post** /iot-profiles | Create a IoT profile
[**CreateMacOuiProfile**](ConfigurationPolicyApi.md#CreateMacOuiProfile) | **Post** /radio-profiles/mac-ouis | Create a MAC OUI profile
[**CreateRadioProfile**](ConfigurationPolicyApi.md#CreateRadioProfile) | **Post** /radio-profiles | Create a radio profile
[**CreateUserProfile**](ConfigurationPolicyApi.md#CreateUserProfile) | **Post** /user-profiles | Create a user profile
[**DeleteClassificationRule**](ConfigurationPolicyApi.md#DeleteClassificationRule) | **Delete** /classification-rules/{id} | Delete classification rule by ID
[**DeleteCloudConfigGroup**](ConfigurationPolicyApi.md#DeleteCloudConfigGroup) | **Delete** /ccgs/{id} | Delete a cloud config group
[**DeleteCoUserProfile**](ConfigurationPolicyApi.md#DeleteCoUserProfile) | **Delete** /user-profiles/{id} | Delete an user profile by ID
[**DeleteIotProfile**](ConfigurationPolicyApi.md#DeleteIotProfile) | **Delete** /iot-profiles/{id} | Delete Iot profile by ID
[**DeleteRadioProfile**](ConfigurationPolicyApi.md#DeleteRadioProfile) | **Delete** /radio-profiles/{id} | Delete radio profile by ID
[**DeleteRpMacOuiProfile**](ConfigurationPolicyApi.md#DeleteRpMacOuiProfile) | **Delete** /radio-profiles/mac-ouis/{id} | Delete MAC OUI profile
[**DisableSsidCwp**](ConfigurationPolicyApi.md#DisableSsidCwp) | **Post** /ssids/{id}/cwp/:disable | Disable the CWP on the SSID
[**EnableSsidCwp**](ConfigurationPolicyApi.md#EnableSsidCwp) | **Post** /ssids/{id}/cwp/:enable | Enable and attach the CWP on the SSID
[**GetClassificationRule**](ConfigurationPolicyApi.md#GetClassificationRule) | **Get** /classification-rules/{id} | Get a classification rule by ID
[**GetCloudConfigGroup**](ConfigurationPolicyApi.md#GetCloudConfigGroup) | **Get** /ccgs/{id} | Get a cloud config group
[**GetIotProfile**](ConfigurationPolicyApi.md#GetIotProfile) | **Get** /iot-profiles/{id} | Get IoT profile by ID
[**GetNeighborhoodAnalysis**](ConfigurationPolicyApi.md#GetNeighborhoodAnalysis) | **Get** /radio-profiles/neighborhood-analysis/{id} | Get neighborhood analysis settings
[**GetRadioProfile**](ConfigurationPolicyApi.md#GetRadioProfile) | **Get** /radio-profiles/{id} | Get radio profile by ID
[**GetRpChannelSelection**](ConfigurationPolicyApi.md#GetRpChannelSelection) | **Get** /radio-profiles/channel-selection/{id} | Get channel selection settings
[**GetRpMacOuiProfile**](ConfigurationPolicyApi.md#GetRpMacOuiProfile) | **Get** /radio-profiles/mac-ouis/{id} | Get MAC OUI profile
[**GetRpMiscellaneousSettings**](ConfigurationPolicyApi.md#GetRpMiscellaneousSettings) | **Get** /radio-profiles/miscellaneous/{id} | Get radio miscellaneous settings
[**GetRpRadioUsageOptimization**](ConfigurationPolicyApi.md#GetRpRadioUsageOptimization) | **Get** /radio-profiles/radio-usage-opt/{id} | Get radio usage optimization settings
[**GetRpSensorScanSettings**](ConfigurationPolicyApi.md#GetRpSensorScanSettings) | **Get** /radio-profiles/sensor-scan/{id} | Get sensor scan settings
[**GetRpWmmQosSettings**](ConfigurationPolicyApi.md#GetRpWmmQosSettings) | **Get** /radio-profiles/wmm-qos/{id} | Get Wmm QoS settings
[**GetUserProfile**](ConfigurationPolicyApi.md#GetUserProfile) | **Get** /user-profiles/{id} | Get user profile by ID
[**ListClassificationRules**](ConfigurationPolicyApi.md#ListClassificationRules) | **Get** /classification-rules | List classification rules
[**ListCloudConfigGroups**](ConfigurationPolicyApi.md#ListCloudConfigGroups) | **Get** /ccgs | List clould config groups
[**ListIotProfiles**](ConfigurationPolicyApi.md#ListIotProfiles) | **Get** /iot-profiles | List IoT profiles
[**ListL3AddressProfiles**](ConfigurationPolicyApi.md#ListL3AddressProfiles) | **Get** /l3-address-profiles | List L3 address profiles
[**ListRadioProfiles**](ConfigurationPolicyApi.md#ListRadioProfiles) | **Get** /radio-profiles | List radio profiles
[**ListRpMacOuiProfiles**](ConfigurationPolicyApi.md#ListRpMacOuiProfiles) | **Get** /radio-profiles/mac-ouis | List MAC OUI profiles
[**ListSsids**](ConfigurationPolicyApi.md#ListSsids) | **Get** /ssids | List SSIDs
[**ListUserProfiles**](ConfigurationPolicyApi.md#ListUserProfiles) | **Get** /user-profiles | List user profiles
[**RenameSsid**](ConfigurationPolicyApi.md#RenameSsid) | **Post** /ssids/{id}/:rename | Rename SSID (Wireless name)
[**SetSsidModeDot1x**](ConfigurationPolicyApi.md#SetSsidModeDot1x) | **Put** /ssids/{id}/mode/dot1x | Change the SSID mode to 802.1x
[**SetSsidModeOpen**](ConfigurationPolicyApi.md#SetSsidModeOpen) | **Put** /ssids/{id}/mode/open | Change the SSID mode to open access
[**SetSsidModePpsk**](ConfigurationPolicyApi.md#SetSsidModePpsk) | **Put** /ssids/{id}/mode/ppsk | Change the SSID mode to PPSK
[**SetSsidModePsk**](ConfigurationPolicyApi.md#SetSsidModePsk) | **Put** /ssids/{id}/mode/psk | Change the SSID mode to PSK
[**SetSsidModeWep**](ConfigurationPolicyApi.md#SetSsidModeWep) | **Put** /ssids/{id}/mode/wep | Change the SSID mode to WEP
[**UpdateClassificationRule**](ConfigurationPolicyApi.md#UpdateClassificationRule) | **Put** /classification-rules/{id} | Update classification rule
[**UpdateCloudConfigGroup**](ConfigurationPolicyApi.md#UpdateCloudConfigGroup) | **Put** /ccgs/{id} | Update cloud config group information
[**UpdateCoUserProfile**](ConfigurationPolicyApi.md#UpdateCoUserProfile) | **Put** /user-profiles/{id} | Update user profile
[**UpdateIotProfile**](ConfigurationPolicyApi.md#UpdateIotProfile) | **Put** /iot-profiles/{id} | Update radio profile by ID
[**UpdateNeighborhoodAnalysis**](ConfigurationPolicyApi.md#UpdateNeighborhoodAnalysis) | **Put** /radio-profiles/neighborhood-analysis/{id} | Update neighborhood analysis settings
[**UpdateRadioProfile**](ConfigurationPolicyApi.md#UpdateRadioProfile) | **Put** /radio-profiles/{id} | Update radio profile by ID
[**UpdateRpChannelSelection**](ConfigurationPolicyApi.md#UpdateRpChannelSelection) | **Put** /radio-profiles/channel-selection/{id} | Update channel selection settings
[**UpdateRpMacOuiProfile**](ConfigurationPolicyApi.md#UpdateRpMacOuiProfile) | **Put** /radio-profiles/mac-ouis/{id} | Update MAC OUI profile
[**UpdateRpMiscellaneousSettings**](ConfigurationPolicyApi.md#UpdateRpMiscellaneousSettings) | **Put** /radio-profiles/miscellaneous/{id} | Update radio miscellaneous settings
[**UpdateRpRadioUsageOptimization**](ConfigurationPolicyApi.md#UpdateRpRadioUsageOptimization) | **Put** /radio-profiles/radio-usage-opt/{id} | Update radio usage optimization settings
[**UpdateRpSensorScanSettings**](ConfigurationPolicyApi.md#UpdateRpSensorScanSettings) | **Put** /radio-profiles/sensor-scan/{id} | Update sensor scan settings
[**UpdateRpWmmQosSettings**](ConfigurationPolicyApi.md#UpdateRpWmmQosSettings) | **Put** /radio-profiles/wmm-qos/{id} | Update Wmm QoS settings



## AttachCwpToSsid

> AttachCwpToSsid(ctx, id, body)

Attach CWP to an SSID

Attach CWP to an SSID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**body** | **int64**| The CWP ID to be attached to the SSID. For CWP with only User Auth on Captive Web Portal enabled, please also attach a RADIUS server group or enable ExtremeCloud IQ Authentication Service. | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AttachRadiusServerGroupToSsid

> AttachRadiusServerGroupToSsid(ctx, id, body)

Attach radius server group to an SSID

Attach radius server group to an SSID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**body** | **int64**| The radius server group ID to be attached to the SSID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AttachUserProfileToSsid

> AttachUserProfileToSsid(ctx, id, body)

Attach user profile to an SSID

Attach user profile to an SSID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**body** | **int64**| The user profile ID to be attached to the SSID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ChangePskPassword

> ChangePskPassword(ctx, id, body)

Change the SSID PSK password

Change the SSID PSK password.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**body** | **string**| The new SSID PSK password | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClassificationRule

> XiqClassificationRule CreateClassificationRule(ctx, xiqCreateClassificationRuleRequest)

Create classification rule

Create a new classification rule.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateClassificationRuleRequest** | [**XiqCreateClassificationRuleRequest**](XiqCreateClassificationRuleRequest.md)| The payload to create a new classification rule | 

### Return type

[**XiqClassificationRule**](XiqClassificationRule.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateCloudConfigGroup

> XiqCloudConfigGroup CreateCloudConfigGroup(ctx, xiqCreateCloudConfigGroupRequest)

Create new cloud config group

Create a new cloud config group.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateCloudConfigGroupRequest** | [**XiqCreateCloudConfigGroupRequest**](XiqCreateCloudConfigGroupRequest.md)| Create new cloud config group request body | 

### Return type

[**XiqCloudConfigGroup**](XiqCloudConfigGroup.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateIotProfile

> XiqIotProfile CreateIotProfile(ctx, xiqIotProfileRequest)

Create a IoT profile

Create a new IoT profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqIotProfileRequest** | [**XiqIotProfileRequest**](XiqIotProfileRequest.md)| The request body to create new IoT profile. | 

### Return type

[**XiqIotProfile**](XiqIotProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateMacOuiProfile

> XiqRpMacOuiProfile CreateMacOuiProfile(ctx, xiqCreateRpMacOuiProfileRequest)

Create a MAC OUI profile

Create a new MAC OUI profile for radio usage optimization.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateRpMacOuiProfileRequest** | [**XiqCreateRpMacOuiProfileRequest**](XiqCreateRpMacOuiProfileRequest.md)| The request body to create new user profile. | 

### Return type

[**XiqRpMacOuiProfile**](XiqRpMacOuiProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateRadioProfile

> XiqRadioProfile CreateRadioProfile(ctx, xiqCreateRadioProfileRequest)

Create a radio profile

Create a new radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateRadioProfileRequest** | [**XiqCreateRadioProfileRequest**](XiqCreateRadioProfileRequest.md)| The request body to create new user profile. | 

### Return type

[**XiqRadioProfile**](XiqRadioProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUserProfile

> XiqUserProfile CreateUserProfile(ctx, xiqCreateUserProfileRequest)

Create a user profile

Create a new user profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateUserProfileRequest** | [**XiqCreateUserProfileRequest**](XiqCreateUserProfileRequest.md)| The request body to create new user profile. | 

### Return type

[**XiqUserProfile**](XiqUserProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteClassificationRule

> DeleteClassificationRule(ctx, id)

Delete classification rule by ID

Delete an existing classification rule by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The classification rule ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteCloudConfigGroup

> DeleteCloudConfigGroup(ctx, id)

Delete a cloud config group

Delete a specific cloud config group by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The cloud config group ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteCoUserProfile

> DeleteCoUserProfile(ctx, id)

Delete an user profile by ID

Delete an existing user profile by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The user profile ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteIotProfile

> DeleteIotProfile(ctx, id)

Delete Iot profile by ID

Delete the existing IoT profile by the profile ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The IoT profile ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteRadioProfile

> DeleteRadioProfile(ctx, id)

Delete radio profile by ID

Delete the existing radio profile by the profile ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The radio profile ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteRpMacOuiProfile

> DeleteRpMacOuiProfile(ctx, id)

Delete MAC OUI profile

Delete the existing MAC OUI profile for radio usage optimization.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The MAC OUI profile ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DisableSsidCwp

> DisableSsidCwp(ctx, id)

Disable the CWP on the SSID

Disable the CWP on the SSID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## EnableSsidCwp

> EnableSsidCwp(ctx, id, body)

Enable and attach the CWP on the SSID

Enable and attach the CWP on the SSID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**body** | **int64**| The new CWP ID.  For CWP with only User Auth on Captive Web Portal enabled, please also attach a RADIUS server group or enable ExtremeCloud IQ Authentication Service. | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClassificationRule

> XiqClassificationRule GetClassificationRule(ctx, id)

Get a classification rule by ID

Get a specific classification rule.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The classification Rule ID | 

### Return type

[**XiqClassificationRule**](XiqClassificationRule.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCloudConfigGroup

> XiqCloudConfigGroup GetCloudConfigGroup(ctx, id)

Get a cloud config group

Get cloud config group info for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The cloud config group ID | 

### Return type

[**XiqCloudConfigGroup**](XiqCloudConfigGroup.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIotProfile

> XiqIotProfile GetIotProfile(ctx, id)

Get IoT profile by ID

Get IoT profile details for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The IoT profile ID | 

### Return type

[**XiqIotProfile**](XiqIotProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNeighborhoodAnalysis

> XiqRpNeighborhoodAnalysis GetNeighborhoodAnalysis(ctx, id)

Get neighborhood analysis settings

Get the neighborhood analysis settings belonging to a radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The neighborhood analysis settings ID | 

### Return type

[**XiqRpNeighborhoodAnalysis**](XiqRpNeighborhoodAnalysis.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRadioProfile

> XiqRadioProfile GetRadioProfile(ctx, id)

Get radio profile by ID

Get radio profile details for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The radio profile ID | 

### Return type

[**XiqRadioProfile**](XiqRadioProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRpChannelSelection

> XiqRpChannelSelection GetRpChannelSelection(ctx, id)

Get channel selection settings

Get the channel selection settings belonging to a radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The channel selection settings ID | 

### Return type

[**XiqRpChannelSelection**](XiqRpChannelSelection.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRpMacOuiProfile

> XiqRpMacOuiProfile GetRpMacOuiProfile(ctx, id)

Get MAC OUI profile

Get the MAC OUI profile belonging the radio optimization settings.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The MAC OUI profile ID | 

### Return type

[**XiqRpMacOuiProfile**](XiqRpMacOuiProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRpMiscellaneousSettings

> XiqRpMiscellaneousSettings GetRpMiscellaneousSettings(ctx, id)

Get radio miscellaneous settings

Get the radio miscellaneous settings belonging to a radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The radio miscellaneous settings ID | 

### Return type

[**XiqRpMiscellaneousSettings**](XiqRpMiscellaneousSettings.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRpRadioUsageOptimization

> XiqRpRadioUsageOptimization GetRpRadioUsageOptimization(ctx, id)

Get radio usage optimization settings

Get the radio usage optimization settings belonging to a radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The radio usage optimization settings ID | 

### Return type

[**XiqRpRadioUsageOptimization**](XiqRpRadioUsageOptimization.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRpSensorScanSettings

> XiqRpSensorScanSettings GetRpSensorScanSettings(ctx, id)

Get sensor scan settings

Get the sensor scan settings belonging to a radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The sensor scan settings ID | 

### Return type

[**XiqRpSensorScanSettings**](XiqRpSensorScanSettings.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRpWmmQosSettings

> XiqRpWmmQosSettings GetRpWmmQosSettings(ctx, id)

Get Wmm QoS settings

Get the Wi-Fi Multimedia (WMM) QoS settings belonging to a radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The radio QoS settings ID | 

### Return type

[**XiqRpWmmQosSettings**](XiqRpWmmQosSettings.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUserProfile

> XiqUserProfile GetUserProfile(ctx, id)

Get user profile by ID

Get user profile details for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The user profile ID | 

### Return type

[**XiqUserProfile**](XiqUserProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListClassificationRules

> PagedXiqClassificationRule ListClassificationRules(ctx, optional)

List classification rules

List a page of classification rules.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListClassificationRulesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListClassificationRulesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqClassificationRule**](PagedXiqClassificationRule.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCloudConfigGroups

> PagedXiqCloudConfigGroup ListCloudConfigGroups(ctx, optional)

List clould config groups

List a papge of cloud config groups.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListCloudConfigGroupsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListCloudConfigGroupsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqCloudConfigGroup**](PagedXiqCloudConfigGroup.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListIotProfiles

> PagedXiqIotProfile ListIotProfiles(ctx, optional)

List IoT profiles

List a page of IoT profiles.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListIotProfilesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListIotProfilesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqIotProfile**](PagedXiqIotProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListL3AddressProfiles

> []XiqL3AddressProfile ListL3AddressProfiles(ctx, addressType)

List L3 address profiles

List all L3 Address Profiles.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**addressType** | **string**| The address type | 

### Return type

[**[]XiqL3AddressProfile**](XiqL3AddressProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListRadioProfiles

> PagedXiqRadioProfile ListRadioProfiles(ctx, optional)

List radio profiles

List a page of radio profiles.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListRadioProfilesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListRadioProfilesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqRadioProfile**](PagedXiqRadioProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListRpMacOuiProfiles

> PagedXiqRpMacOuiProfile ListRpMacOuiProfiles(ctx, optional)

List MAC OUI profiles

List a page of MAC OUI profiles.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListRpMacOuiProfilesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListRpMacOuiProfilesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqRpMacOuiProfile**](PagedXiqRpMacOuiProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSsids

> PagedXiqSsid ListSsids(ctx, optional)

List SSIDs

List SSIDs with filter and pagination.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListSsidsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListSsidsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqSsid**](PagedXiqSsid.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListUserProfiles

> PagedXiqUserProfile ListUserProfiles(ctx, optional)

List user profiles

List a page of user profiles.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListUserProfilesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListUserProfilesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqUserProfile**](PagedXiqUserProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RenameSsid

> RenameSsid(ctx, id, body)

Rename SSID (Wireless name)

Change SSID broadcast name (Wireless name).

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**body** | **string**| The new SSID name | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetSsidModeDot1x

> SetSsidModeDot1x(ctx, id, xiqSetSsidModeDot1xRequest)

Change the SSID mode to 802.1x

Change the SSID mode to 802.1x.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**xiqSetSsidModeDot1xRequest** | [**XiqSetSsidModeDot1xRequest**](XiqSetSsidModeDot1xRequest.md)| The payload to change the SSID mode to 802.1x | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetSsidModeOpen

> SetSsidModeOpen(ctx, id)

Change the SSID mode to open access

Change the SSID mode to open access.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetSsidModePpsk

> SetSsidModePpsk(ctx, id, xiqSetSsidModePpskRequest)

Change the SSID mode to PPSK

Change the SSID mode to PPSK.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**xiqSetSsidModePpskRequest** | [**XiqSetSsidModePpskRequest**](XiqSetSsidModePpskRequest.md)| The payload to change the SSID mode to PPSK | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetSsidModePsk

> SetSsidModePsk(ctx, id, xiqSetSsidModePskRequest)

Change the SSID mode to PSK

Change the SSID mode to PSK.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**xiqSetSsidModePskRequest** | [**XiqSetSsidModePskRequest**](XiqSetSsidModePskRequest.md)| The payload to change the SSID mode to PSK | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetSsidModeWep

> SetSsidModeWep(ctx, id, xiqSetSsidModeWepRequest)

Change the SSID mode to WEP

Change the SSID mode to WEP.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The SSID ID | 
**xiqSetSsidModeWepRequest** | [**XiqSetSsidModeWepRequest**](XiqSetSsidModeWepRequest.md)| The payload to change the SSID mode to WEP | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClassificationRule

> XiqClassificationRule UpdateClassificationRule(ctx, id, xiqUpdateClassificationRuleRequest)

Update classification rule

Update the exist classification rule.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The classification rule ID | 
**xiqUpdateClassificationRuleRequest** | [**XiqUpdateClassificationRuleRequest**](XiqUpdateClassificationRuleRequest.md)| The payload to update exist classification rule | 

### Return type

[**XiqClassificationRule**](XiqClassificationRule.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCloudConfigGroup

> XiqCloudConfigGroup UpdateCloudConfigGroup(ctx, id, xiqUpdateCloudConfigGroupRequest)

Update cloud config group information

Update the cloud config group details having the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The cloud config group ID | 
**xiqUpdateCloudConfigGroupRequest** | [**XiqUpdateCloudConfigGroupRequest**](XiqUpdateCloudConfigGroupRequest.md)| Update cloud config group request body | 

### Return type

[**XiqCloudConfigGroup**](XiqCloudConfigGroup.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCoUserProfile

> XiqUserProfile UpdateCoUserProfile(ctx, id, xiqUpdateUserProfileRequest)

Update user profile

Update an existing user profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The user profile ID. | 
**xiqUpdateUserProfileRequest** | [**XiqUpdateUserProfileRequest**](XiqUpdateUserProfileRequest.md)| The payload of user profile. | 

### Return type

[**XiqUserProfile**](XiqUserProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateIotProfile

> XiqIotProfile UpdateIotProfile(ctx, id, xiqIotProfileRequest)

Update radio profile by ID

Update the existing radio profile by the profile ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The radio profile ID. | 
**xiqIotProfileRequest** | [**XiqIotProfileRequest**](XiqIotProfileRequest.md)| The payload of the update radio profile request. | 

### Return type

[**XiqIotProfile**](XiqIotProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNeighborhoodAnalysis

> XiqRpNeighborhoodAnalysis UpdateNeighborhoodAnalysis(ctx, id, xiqUpdateRpNeighborhoodAnalysisRequest)

Update neighborhood analysis settings

Update the neighborhood analysis settings belonging to a radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The neighborhood analysis settings ID. | 
**xiqUpdateRpNeighborhoodAnalysisRequest** | [**XiqUpdateRpNeighborhoodAnalysisRequest**](XiqUpdateRpNeighborhoodAnalysisRequest.md)| The payload of the update neighborhood analysis settings request. | 

### Return type

[**XiqRpNeighborhoodAnalysis**](XiqRpNeighborhoodAnalysis.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateRadioProfile

> XiqRadioProfile UpdateRadioProfile(ctx, id, xiqUpdateRadioProfileRequest)

Update radio profile by ID

Update the existing radio profile by the profile ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The radio profile ID. | 
**xiqUpdateRadioProfileRequest** | [**XiqUpdateRadioProfileRequest**](XiqUpdateRadioProfileRequest.md)| The payload of the update radio profile request. | 

### Return type

[**XiqRadioProfile**](XiqRadioProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateRpChannelSelection

> XiqRpChannelSelection UpdateRpChannelSelection(ctx, id, xiqUpdateRpChannelSelectionRequest)

Update channel selection settings

Update the channel selection settings belonging to a radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The channel selection settings ID. | 
**xiqUpdateRpChannelSelectionRequest** | [**XiqUpdateRpChannelSelectionRequest**](XiqUpdateRpChannelSelectionRequest.md)| The payload of the update channel selection settings request. | 

### Return type

[**XiqRpChannelSelection**](XiqRpChannelSelection.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateRpMacOuiProfile

> XiqRpMacOuiProfile UpdateRpMacOuiProfile(ctx, id, xiqUpdateRpMacOuiProfileRequest)

Update MAC OUI profile

Update the existing MAC OUI profile for radio usage optimization.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The MAC OUI profile ID. | 
**xiqUpdateRpMacOuiProfileRequest** | [**XiqUpdateRpMacOuiProfileRequest**](XiqUpdateRpMacOuiProfileRequest.md)| The payload of the update MAC OUI profile request. | 

### Return type

[**XiqRpMacOuiProfile**](XiqRpMacOuiProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateRpMiscellaneousSettings

> XiqRpMiscellaneousSettings UpdateRpMiscellaneousSettings(ctx, id, xiqUpdateRpMiscellaneousSettingsRequest)

Update radio miscellaneous settings

Update the radio miscellaneous settings belonging to a radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The radio miscellaneous settings ID. | 
**xiqUpdateRpMiscellaneousSettingsRequest** | [**XiqUpdateRpMiscellaneousSettingsRequest**](XiqUpdateRpMiscellaneousSettingsRequest.md)| The payload of the update radio miscellaneous settings request. | 

### Return type

[**XiqRpMiscellaneousSettings**](XiqRpMiscellaneousSettings.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateRpRadioUsageOptimization

> XiqRpRadioUsageOptimization UpdateRpRadioUsageOptimization(ctx, id, xiqUpdateRpRadioUsageOptimizationRequest)

Update radio usage optimization settings

Update the radio usage optimization settings belonging to a radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The radio usage optimization settings ID. | 
**xiqUpdateRpRadioUsageOptimizationRequest** | [**XiqUpdateRpRadioUsageOptimizationRequest**](XiqUpdateRpRadioUsageOptimizationRequest.md)| The payload of the update radio usage optimization settings request. | 

### Return type

[**XiqRpRadioUsageOptimization**](XiqRpRadioUsageOptimization.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateRpSensorScanSettings

> XiqRpSensorScanSettings UpdateRpSensorScanSettings(ctx, id, xiqUpdateRpSensorScanSettingsRequest)

Update sensor scan settings

Update the sensor scan settings belonging to a radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The sensor scan settings ID. | 
**xiqUpdateRpSensorScanSettingsRequest** | [**XiqUpdateRpSensorScanSettingsRequest**](XiqUpdateRpSensorScanSettingsRequest.md)| The payload of the update sensor scan settings request. | 

### Return type

[**XiqRpSensorScanSettings**](XiqRpSensorScanSettings.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateRpWmmQosSettings

> XiqRpWmmQosSettings UpdateRpWmmQosSettings(ctx, id, xiqUpdateRpWmmQosSettingsRequest)

Update Wmm QoS settings

Update the Wi-Fi Multimedia (WMM) QoS settings belonging to a radio profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The Wmm QoS settings ID. | 
**xiqUpdateRpWmmQosSettingsRequest** | [**XiqUpdateRpWmmQosSettingsRequest**](XiqUpdateRpWmmQosSettingsRequest.md)| The payload of the update Wmm QoS settings request. | 

### Return type

[**XiqRpWmmQosSettings**](XiqRpWmmQosSettings.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

