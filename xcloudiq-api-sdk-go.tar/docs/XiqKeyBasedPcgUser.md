# XiqKeyBasedPcgUser

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The user name of key based PCG, which could not share with other exist key based PCG | 
**Email** | **string** | The email for deliver key based PCG user password | 
**UserGroupName** | **string** | The user group name | 
**Id** | **int64** | The user ID | 
**CreateTime** | [**time.Time**](time.Time.md) | The create timestamp | 
**UpdateTime** | [**time.Time**](time.Time.md) | The create timestamp | 
**OrgId** | **int64** | The organization ID | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


