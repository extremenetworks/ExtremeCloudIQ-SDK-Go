# XiqHiqContext

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ReadingOrgIds** | **[]int64** | The organization ID list for reading data (Empty means read data from all organizations in the HIQ) | 
**CreatingOrgId** | **int64** | The organization ID for creating new data | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


