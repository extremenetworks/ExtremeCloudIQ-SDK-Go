# XiqDfsRecurenceChannelStatsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DfsChannelStatsEntities** | [**[]XiqDfsChannelStatsEntity**](XiqDfsChannelStatsEntity.md) | the channel stats data | [optional] 
**MinChannel** | **int32** | The min channel | [optional] 
**MaxChannel** | **int32** | The max channel | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


