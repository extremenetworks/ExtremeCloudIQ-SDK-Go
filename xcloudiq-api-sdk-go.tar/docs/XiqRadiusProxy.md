# XiqRadiusProxy

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**Name** | **string** | The RADIUS proxy name | [optional] 
**Description** | **string** | The RADIUS proxy description | [optional] 
**FormatType** | [**XiqRadiusProxyFormatType**](XiqRadiusProxyFormatType.md) |  | [optional] 
**RetryCount** | **int32** | The retry count of RADIUS proxy | [optional] 
**RetryDelay** | **int32** | The retry delay of RADIUS proxy | [optional] 
**DeadTime** | **int32** | The dead time of RADIUS proxy | [optional] 
**EnableInjectOperatorNameAttribute** | **bool** | The flag for enable inject operator name attribute | [optional] 
**Clients** | [**[]XiqRadiusClient**](XiqRadiusClient.md) | The RADIUS clients of RADIUS proxy | [optional] 
**Realms** | [**[]XiqRadiusProxyRealm**](XiqRadiusProxyRealm.md) | The RADIUS realms of RADIUS proxy | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


