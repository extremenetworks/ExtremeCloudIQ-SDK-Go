# XiqDateTimeType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DayOfMonth** | **int32** | The day of month | 
**Month** | **int32** | The month | 
**Year** | **int32** | The year | 
**HourOfDay** | **int32** | The 24-hour format hour of day | 
**MinuteOfHour** | **int32** | The minute of the hour | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


