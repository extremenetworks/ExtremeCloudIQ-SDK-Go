# XiqWirelessPerformanceEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **int64** | The timestamp | 
**QualityIndex** | **int32** | The quality index | [optional] 
**TotalClients** | **int32** | The total clients | [optional] 
**TimeToConnectScore** | **int32** | The time to connect score | [optional] 
**PerformanceScore** | **int32** | The performance score | [optional] 
**Snr** | **int32** | The average snr | [optional] 
**RetriesData** | [**XiqWirelessPerformanceRetriesEntity**](XiqWirelessPerformanceRetriesEntity.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


