# XiqWirelessPerformanceEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **int64** | the timestamp | 
**QualityIndex** | **int32** | the quality index | [optional] 
**TotalClients** | **int32** | the total clients | [optional] 
**TimeToConnectScore** | **int32** | the time to connect score | [optional] 
**PerformanceScore** | **int32** | the performance score | [optional] 
**Snr** | **int32** | the average snr | [optional] 
**RetriesData** | [**XiqWirelessPerformanceRetriesEntity**](XiqWirelessPerformanceRetriesEntity.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


