# XiqAnomaliesSeverityEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LowSeverityAnomaliesCount** | **int32** | Anomalies count with low severity | [optional] 
**MediumSeverityAnomaliesCount** | **int32** | Anomalies count with medium severity | [optional] 
**HighSeverityAnomaliesCount** | **int32** | Anomalies count with high severity | [optional] 
**AnomaliesCountBySeverity** | **int32** | Total Anomalies count by severity | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


