# XiqPcgPortAssignmentEntryDetail

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**Device** | [**XiqPcgPortAssignmentEntryDeviceMeta**](XiqPcgPortAssignmentEntryDeviceMeta.md) |  | [optional] 
**Eth1** | [**XiqPcgPortAssignmentEntryEthUserMeta**](XiqPcgPortAssignmentEntryEthUserMeta.md) |  | [optional] 
**Eth2** | [**XiqPcgPortAssignmentEntryEthUserMeta**](XiqPcgPortAssignmentEntryEthUserMeta.md) |  | [optional] 
**Eth3** | [**XiqPcgPortAssignmentEntryEthUserMeta**](XiqPcgPortAssignmentEntryEthUserMeta.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


