# XiqValidTimePeriodAfterFirstLogin

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ValidTimePeriod** | **int32** | The valid time period after the first login | 
**ValidTimePeriodUnit** | [**XiqDateTimeUnitType**](XiqDateTimeUnitType.md) |  | 
**FirstLoginWithin** | **int32** | The first time the access key must be used | 
**FirstLoginWithinUnit** | [**XiqDateTimeUnitType**](XiqDateTimeUnitType.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


