# XiqRpRadioUsageOptimization

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**Preamble** | **string** | The preamble data length -- \&quot;AUTO\&quot; or \&quot;LONG\&quot; | [optional] 
**BeaconPeriod** | **int32** | The amount of time between beacons from 40 up to 3500. | [optional] 
**EnableFrameBurst** | **bool** | Whether to enable Frame Burst | [optional] 
**EnableSmartAntenna** | **bool** | Whether to enable Smart Antenna (Enabling this option will disable (Null) for MU-MIMO) | [optional] 
**EnableBackhaulFailover** | **bool** | Whether to enable backhaul failover. Backhaul failover settings determine the thresholds at which the device switches from a wired to a wireless backhaul link, and the thresholds at which the device switches back | [optional] 
**WirelessBackhaulSwitchTriggerTime** | **int32** | Switch to Wireless Backhaul after 1 up to 5 seconds after the wired link fails | [optional] 
**WiredBackhaulRevertHoldTime** | **int32** | Revert Back to Wired Backhaul after 1 up to 300 seconds after the wired link is established | [optional] 
**EnableBandSteering** | **bool** | Whether to enable band steering. Enabling steers clients from 2.4 GHz to 5.0 GHz radio band | [optional] 
**BandSteeringMode** | **string** | The band steering mode -- \&quot;BALANCE\&quot;, \&quot;URGE_5G\&quot;, or \&quot;ENFORCE_5G\&quot; | [optional] 
**IgnoreInitialClientConnectionNumber** | **int32** | The number of connection attempts from 1 to 100 for 2.4 GHz clients to ignore before responding for URGE_5G steering mode. | [optional] 
**EnableClientLoadBalancing** | **bool** | Whether to enable client load balancing.  Enabling load-balances clients across neighboring Extreme Networks within the same hive. Set WiFi0 and WiFi1 radios to the same load balancing mode when it is based on the number of associated stations. | [optional] 
**LoadBalancingMode** | **string** | The client load balancing mode -- \&quot;AIRTIME_BASED\&quot; or \&quot;CLIENT_NUMBER\&quot; | [optional] 
**CrcErrorRatePerDevice** | **int32** | The CRC Error rate threshold from 1 up to 99 for \&quot;AIRTIME_BASED\&quot; load balancing. Ignore probe and association requests per device when CRC Error rate exceeds the threshold. | [optional] 
**RfInterferencePerDevice** | **int32** | The RF Interference threshold from 1 up to 99 for \&quot;AIRTIME_BASED\&quot; load balancing. Ignore probe and association requests per device when RF Interference exceeds the threshold. | [optional] 
**AverageAirtimePerClient** | **int32** | The Average Airtime Per Client threshold from 1 up to 5 for \&quot;AIRTIME_BASED\&quot; load balancing. Ignore probe and association requests per device when Average Airtime Per Client exceeds the threshold. | [optional] 
**AnchorPeriod** | **int32** | The Anchor Period from 10 up to 600 for both \&quot;AIRTIME_BASED\&quot; and \&quot;CLIENT_NUMBER\&quot; load balancing. Ignore probe and association requests from clients associated with other Extreme Networks devices until Anchor Period Eelapses in the range of 10 to 600 seconds | [optional] 
**NeighborQueryInterval** | **int32** | In both client load balancing modes, query neighbors about client load every 1 up to 600 seconds | [optional] 
**EnableWeakSignalProbeRequestSuppression** | **bool** | Whether to enable Weak Signal Probe Request Suppression. Weak Signal Probe Request Suppression allows the configuration of signal-to-noise threshold beyond which the device does not respond to client probes. | [optional] 
**WeakSnrThreshold** | **int32** | The signal to noise threshold from 1 up to 100 for Weak Signal Probe Request Suppression. | [optional] 
**EnableSafetyNet** | **bool** | Whether to enable Safety Net. When a device is overloaded or is probed by clients with a low signal-to-noise ratio,  Safety Net allows the device to respond to association requests  after a certain time period lapses. | [optional] 
**SafetyNetPeriod** | **int32** | The Safety Net Time Period from 5 up to 300 seconds. | [optional] 
**EnableHighDensity** | **bool** | Whether to enable High Density Configuration. Enabling optimizes performance in high density environments | [optional] 
**ManagementFrameBasicDataRate** | **string** | The data rates to support in high density environment -- \&quot;HIGH\&quot; or \&quot;LOW\&quot; | [optional] 
**EnableSuppressSuccessiveProbeRequest** | **bool** | Whether to Reduce Response to Probe Requests. Enabling suppresses successive requests within the same beacon interval | [optional] 
**ProbeResponseReductionOption** | **string** | The suppress response to broadcast probes options --  \&quot;ONLY_ONE_SSID_RESPOND_AT_A_TIME\&quot; (allowed for only one SSID to respond at a time), \&quot;REDUCE_CERTAIN_CLIENTS_RESPONSE\&quot; (reducing responses to certain client devices). | [optional] 
**SuppressionLimit** | **int32** | The Number of Connection Attempts from 1 up to 10 | [optional] 
**EnableRadioBalance** | **bool** | Whether to enable Radio Load Balancing. Enabling distributes wireless clients that support 5 GHz band evenly across the two radios in Dual-5G mode when an SSID is available on both radios | [optional] 
**EnableAmpdu** | **bool** | Enable Aggregate MAC Protocol Data Units to combine data frames into larger frames before transmission. | [optional] 
**EnableMuMimo** | **bool** | Whether to enable Multiple-Input Multiple-Output (802.11ac &amp; 802.11ax) for multiple-user access by using different spatial streams. | [optional] 
**EnableOfdmaDownLink** | **bool** | Whether to enable OFDMA for AP downlink communication. | [optional] 
**EnableOfdmaUpLink** | **bool** | Whether to enable OFDMA for AP uplink communication. | [optional] 
**BssColoring** | **int32** | Whether to enable BSS Coloring (802.11ax ) to identify overlapping basic service sets (OBSSs). | [optional] 
**EnableTargetWeakTime** | **bool** | Whether to enable Target Weak Time. | [optional] 
**MacOuis** | [**[]XiqRpMacOuiProfile**](XiqRpMacOuiProfile.md) | The device vendor identifiers for the \&quot;REDUCE_CERTAIN_CLIENTS_RESPONSE\&quot; for the probe response reduction option | [optional] 
**RatioFor5gClients** | **int32** | The percentage distribution from 1 up to 100 for 2.4 and 5.0 GHz clients for \&quot;BALANCE\&quot; steering mode. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


