# XiqAnomalyDeviceWithLocation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BuildingId** | **int64** | The building ID | 
**LocationName** | **string** | The location name | 
**Muted** | **bool** | To filter muted anomalies | 
**Severity** | [**XiqAnomalySeverity**](XiqAnomalySeverity.md) |  | 
**AnomalyType** | [**XiqAnomalyType**](XiqAnomalyType.md) |  | 
**LastDetectedTime** | **int64** | The last detected time of anomaly | 
**DeviceId** | **int64** | The device ID | 
**DeviceName** | **string** | The device name | 
**DeviceModel** | **string** | The device model | 
**DeviceMake** | **string** | The device make | 
**SwitchStack** | **bool** | The device model | 
**Category** | [**XiqDeviceCategory**](XiqDeviceCategory.md) |  | 
**InterfaceName** | **string** | The interface name | 
**LocationId** | **int64** | The location ID | [optional] 
**AnomalyId** | **string** | The anomaly ID | [optional] 
**Frequency** | **string** | The frequency | [optional] 
**ChannelNumber** | **int32** | The channel number | [optional] 
**ChannelMode** | **string** | The channel mode | [optional] 
**RecommendedAction** | **string** | The recommended action | [optional] 
**Issue** | **string** | The issue | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


