# \LogApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ListAccountingLogs**](LogApi.md#ListAccountingLogs) | **Get** /logs/accounting | List accounting logs
[**ListAuditLogs**](LogApi.md#ListAuditLogs) | **Get** /logs/audit | List audit logs
[**ListAuthLogs**](LogApi.md#ListAuthLogs) | **Get** /logs/auth | List auth logs
[**ListCredentialLogs**](LogApi.md#ListCredentialLogs) | **Get** /logs/credential | List credential logs
[**ListEmailLogs**](LogApi.md#ListEmailLogs) | **Get** /logs/email | List Email logs
[**ListSmsLogs**](LogApi.md#ListSmsLogs) | **Get** /logs/sms | List SMS logs



## ListAccountingLogs

> PagedXiqAccountingLog ListAccountingLogs(ctx, optional)

List accounting logs

List a page of accounting logs.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListAccountingLogsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListAccountingLogsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **username** | **optional.String**| The user login name | 
 **callingStationId** | **optional.String**| The calling station ID | 
 **startTime** | **optional.Int64**| The start time to query, epoch time in milliseconds since 1/1/1970, default is 0 if not specified or is negative | 
 **endTime** | **optional.Int64**| The end time to query, epoch time in milliseconds since 1/1/1970, default is now if not specified or is negative | 

### Return type

[**PagedXiqAccountingLog**](PagedXiqAccountingLog.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuditLogs

> PagedXiqAuditLog ListAuditLogs(ctx, optional)

List audit logs

List a page of audit logs.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListAuditLogsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListAuditLogsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **sortField** | [**optional.Interface of XiqAuditLogSortField**](.md)| The field for sorting | 
 **sortOrder** | [**optional.Interface of XiqSortOrder**](.md)| The sorting order | 
 **categories** | [**optional.Interface of []XiqAuditLogCategory**](XiqAuditLogCategory.md)| Audit category | 
 **username** | **optional.String**| The user login name | 
 **startTime** | **optional.Int64**| The start time to query, epoch time in milliseconds since 1/1/1970, default is 0 if not specified or is negative | 
 **endTime** | **optional.Int64**| The end time to query, epoch time in milliseconds since 1/1/1970, default is now if not specified or is negative, endTime - startTime must be no greater than 2592000000 (30 days) | 
 **keyword** | **optional.String**| The case-insensitive keyword to search in description | 

### Return type

[**PagedXiqAuditLog**](PagedXiqAuditLog.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthLogs

> PagedXiqAuthLog ListAuthLogs(ctx, optional)

List auth logs

List a page of auth logs.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListAuthLogsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListAuthLogsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **username** | **optional.String**| The user login name | 
 **callingStationId** | **optional.String**| The calling station ID | 
 **startTime** | **optional.Int64**| The start time to query, epoch time in milliseconds since 1/1/1970, default is 0 if not specified or is negative | 
 **endTime** | **optional.Int64**| The end time to query, epoch time in milliseconds since 1/1/1970, default is now if not specified or is negative | 

### Return type

[**PagedXiqAuthLog**](PagedXiqAuthLog.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCredentialLogs

> PagedXiqCredentialLog ListCredentialLogs(ctx, optional)

List credential logs

List a page of credential logs.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListCredentialLogsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListCredentialLogsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **username** | **optional.String**| The user login name | 
 **startTime** | **optional.Int64**| The start time to query, epoch time in milliseconds since 1/1/1970, default is 0 if not specified or is negative | 
 **endTime** | **optional.Int64**| The end time to query, epoch time in milliseconds since 1/1/1970, default is now if not specified or is negative | 

### Return type

[**PagedXiqCredentialLog**](PagedXiqCredentialLog.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListEmailLogs

> PagedXiqEmailLog ListEmailLogs(ctx, optional)

List Email logs

List a page of Email logs.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListEmailLogsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListEmailLogsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **username** | **optional.String**| The user login name | 
 **startTime** | **optional.Int64**| The start time to query, epoch time in milliseconds since 1/1/1970, default is 0 if not specified or is negative | 
 **endTime** | **optional.Int64**| The end time to query, epoch time in milliseconds since 1/1/1970, default is now if not specified or is negative | 

### Return type

[**PagedXiqEmailLog**](PagedXiqEmailLog.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSmsLogs

> PagedXiqSmsLog ListSmsLogs(ctx, optional)

List SMS logs

List a page of SMS logs.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListSmsLogsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListSmsLogsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **phoneNumber** | **optional.String**| The phone number | 
 **startTime** | **optional.Int64**| The start time to query, epoch time in milliseconds since 1/1/1970, default is 0 if not specified or is negative | 
 **endTime** | **optional.Int64**| The end time to query, epoch time in milliseconds since 1/1/1970, default is now if not specified or is negative | 

### Return type

[**PagedXiqSmsLog**](PagedXiqSmsLog.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

