# XiqUpdateExternalRadiusServerRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The external RADIUS server name | 
**SharedSecret** | **string** | The shared secret for the external RADIUS server (optional) | [optional] 
**AuthenticationPort** | **int32** | The authentication port for the external RADIUS server (1 ~ 65535) | [default to 1812]
**AccountingPort** | **int32** | The accounting port for the external RADIUS server (1 ~ 65535) | [default to 1813]
**ServerType** | [**XiqRadiusServerType**](XiqRadiusServerType.md) |  | 
**IpAddr** | **string** | The IP address or hostname of the RADIUS server | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


