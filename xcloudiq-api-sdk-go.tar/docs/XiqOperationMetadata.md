# XiqOperationMetadata

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Status** | [**XiqOperationStatus**](XiqOperationStatus.md) |  | 
**Cancelable** | **bool** | Indicates if the operation can be canceled in the current status | 
**Percentage** | **int32** | The progress in percentage ranges from 0 to 100 (it&#39;s not guaranteed to be accurate) | [optional] 
**Step** | **string** | The optional step name for multiple steps operations when the operation is running | [optional] 
**CreateTime** | [**time.Time**](time.Time.md) | The operation&#39;s create time, which is the time when the operation is in PENDING status | 
**UpdateTime** | [**time.Time**](time.Time.md) | The operation&#39;s last update time | 
**StartTime** | [**time.Time**](time.Time.md) | The operation&#39;s start time, which is the time when the operation is in RUNNING status | [optional] 
**EndTime** | [**time.Time**](time.Time.md) | The operation&#39;s end time, which is the time when the operation is done | [optional] 
**ExpiresIn** | **int64** | The number of seconds remaining until the operation expires and is to be deleted. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


