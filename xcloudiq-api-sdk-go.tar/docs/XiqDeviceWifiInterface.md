# XiqDeviceWifiInterface

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Frequency** | **string** | The WiFi frequency. | [optional] 
**SsidCount** | **int32** | The number of SSID assigned on this wireless interface. | [optional] 
**ClientCount** | **int64** | The number of clients associated to this wireless interface. | [optional] 
**NeighborClients** | **int64** | The number of neighboring clients. | [optional] 
**ChannelUtil** | **int32** | The channel utilization. | [optional] 
**Channel** | **int32** | The channel associated. | [optional] 
**ChannelWidth** | **int32** | The channel width. | [optional] 
**TxUtilization** | **int64** | The total tx utilization. | [optional] 
**RxUtilization** | **int64** | The total rx utilization. | [optional] 
**TxByteCount** | **int64** | The total tx byte count. | [optional] 
**RxByteCount** | **int64** | The total rx byte count. | [optional] 
**NoiseFloor** | **int64** | The noise floor. | [optional] 
**CrcErrorFrame** | **int64** | The crc error frame count. | [optional] 
**TxRetryFrame** | **int64** | The tx retry frame | [optional] 
**RxRetryFrame** | **int64** | The rx retry fram. | [optional] 
**UnicastTxPacketCount** | **int64** | The unicast tx packet count. | [optional] 
**UnicastRxPacketCount** | **int64** | The unicast rx packet count. | [optional] 
**BroadcastTxPacketCount** | **int64** | The broadcast tx packet count. | [optional] 
**BroadcastRxPacketCount** | **int64** | The broadcast rx packet count. | [optional] 
**TxAirTime** | **int64** | The tx air time. | [optional] 
**RxAirTime** | **int64** | The rx air time. | [optional] 
**TotalUtilization** | **int64** | The total utilization. | [optional] 
**ScanAvgInterference** | **int32** | The average interference. | [optional] 
**MacAddress** | **string** | The bssid. | [optional] 
**Power** | **int32** | The radio power. | [optional] 
**RxErrors** | **int64** | The rx errors. | [optional] 
**TxErrors** | **int64** | The tx errors. | [optional] 
**InterfaceName** | **string** | The interface name. | [optional] 
**RadioProfileName** | **string** | The ExtremecloudIQ radio profile name. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


