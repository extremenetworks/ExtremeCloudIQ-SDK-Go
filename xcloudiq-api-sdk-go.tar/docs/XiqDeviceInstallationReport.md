# XiqDeviceInstallationReport

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Onboarded** | **bool** |  | [optional] 
**LocationName** | **string** |  | [optional] 
**NetworkPolicyName** | **string** |  | [optional] 
**DeviceTemplateName** | **string** |  | [optional] 
**IpAddress** | **string** |  | [optional] 
**DefaultGateway** | **string** |  | [optional] 
**NtpServer** | **string** |  | [optional] 
**DnsServer** | **string** |  | [optional] 
**EnablePoe** | **bool** |  | [optional] 
**XiqConnectivity** | **bool** |  | [optional] 
**InstallationImages** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


