# XiqUpdateFloorRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ParentId** | **int64** | The parent building ID | [optional] 
**Name** | **string** | The floor name | [optional] 
**Environment** | [**XiqRfEnvironmentType**](XiqRfEnvironmentType.md) |  | [optional] 
**DbAttenuation** | **float64** | The floor attenuation in dBs | [optional] 
**MeasurementUnit** | [**XiqMeasurementUnit**](XiqMeasurementUnit.md) |  | [optional] 
**InstallationHeight** | **float64** | The installation height | [optional] 
**MapSizeWidth** | **float64** | The floor map width | [optional] 
**MapSizeHeight** | **float64** | The floor map height | [optional] 
**MapName** | **string** | The floor map name | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


