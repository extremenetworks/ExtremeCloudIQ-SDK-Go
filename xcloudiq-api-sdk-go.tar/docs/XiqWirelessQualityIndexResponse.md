# XiqWirelessQualityIndexResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TimeToConnectScore** | **int32** | the time to connect score | [optional] 
**QualityIndex** | **int32** | the quality index | [optional] 
**PerformanceScore** | **int32** | the performance score | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


