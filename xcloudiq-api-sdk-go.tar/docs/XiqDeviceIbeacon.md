# XiqDeviceIbeacon

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeviceId** | **int64** | The device ID. | 
**Enabled** | **bool** | Whether the device beacon is enabled. | [optional] 
**Major** | **int32** | Identification of a subset of beacons in a geographical venue. | [optional] 
**Minor** | **int32** | Identification of a beacon in a specific location. | [optional] 
**Power** | **int32** | The transmission power in dBm. | [optional] 
**EnableMonitoring** | **bool** | Whether iBeacon monitoring is enabled. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


