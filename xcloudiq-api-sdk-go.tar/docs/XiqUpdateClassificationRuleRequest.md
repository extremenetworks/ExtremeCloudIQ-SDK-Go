# XiqUpdateClassificationRuleRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The name of classification assignment | 
**Description** | **string** | The description of classification assignment | [optional] 
**Classifications** | [**[]XiqUpdateClassificationRequest**](XiqUpdateClassificationRequest.md) | The details of rule Rules | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


