# \NotificationApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateSubscriptions**](NotificationApi.md#CreateSubscriptions) | **Post** /subscriptions/webhook | Create webhook subscriptions
[**DeleteSubscription**](NotificationApi.md#DeleteSubscription) | **Delete** /subscriptions/webhook/{id} | Delete webhook subscription
[**List**](NotificationApi.md#List) | **Get** /subscriptions/webhook | List webhook subscriptions



## CreateSubscriptions

> CreateSubscriptions(ctx, xiqCreateWebhookSubscriptionRequest)

Create webhook subscriptions

Create multiple webhook subscriptions.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateWebhookSubscriptionRequest** | [**[]XiqCreateWebhookSubscriptionRequest**](XiqCreateWebhookSubscriptionRequest.md)| The payload of create multiple webhook subscriptions | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSubscription

> DeleteSubscription(ctx, id)

Delete webhook subscription

Delete an exist webhook subscription.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The webhook subscription ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## List

> []XiqWebhookSubscription List(ctx, )

List webhook subscriptions

List all webhook subscriptions.

### Required Parameters

This endpoint does not need any parameter.

### Return type

[**[]XiqWebhookSubscription**](XiqWebhookSubscription.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

