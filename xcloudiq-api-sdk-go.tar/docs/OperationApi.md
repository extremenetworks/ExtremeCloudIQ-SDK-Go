# \OperationApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CancelOperation**](OperationApi.md#CancelOperation) | **Post** /operations/{operationId}/:cancel | Cancel Long-Running Operation (LRO)
[**DeleteOperation**](OperationApi.md#DeleteOperation) | **Delete** /operations/{operationId} | Delete Long-Running Operation (LRO)
[**GetOperation**](OperationApi.md#GetOperation) | **Get** /operations/{operationId} | Get Long-Running Operation (LRO) status and result



## CancelOperation

> CancelOperation(ctx, operationId)

Cancel Long-Running Operation (LRO)

When the cancelable is true in operation metadata the clients are allowed to send a cancel request to ask the backend to cancel the operation. The server makes its best effort to cancel the operation, but success is not guaranteed.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**operationId** | **string**| The operation ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteOperation

> DeleteOperation(ctx, operationId)

Delete Long-Running Operation (LRO)

The Long-Running Operation (LRO) can be deleted when the operation is done or in PENDING status.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**operationId** | **string**| The operation ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetOperation

> XiqOperationObject GetOperation(ctx, operationId)

Get Long-Running Operation (LRO) status and result

Get the Long-Running Operation (LRO) status and result. The response will include either result or error if the operation is done.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**operationId** | **string**| The operation ID | 

### Return type

[**XiqOperationObject**](XiqOperationObject.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

