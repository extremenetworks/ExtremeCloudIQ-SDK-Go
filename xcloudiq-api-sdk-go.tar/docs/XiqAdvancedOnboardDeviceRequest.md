# XiqAdvancedOnboardDeviceRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Extreme** | [**[]XiqExtremeDevice**](XiqExtremeDevice.md) | The selected target devices | [optional] 
**Exos** | [**[]XiqExosDevice**](XiqExosDevice.md) | The selected target devices | [optional] 
**Voss** | [**[]XiqVossDevice**](XiqVossDevice.md) | The selected target devices | [optional] 
**Wing** | [**[]XiqWingDevice**](XiqWingDevice.md) | The selected target devices | [optional] 
**Dell** | [**[]XiqDellDevice**](XiqDellDevice.md) | The selected target devices | [optional] 
**Dt** | [**[]XiqDigitalTwinOnboardDevice**](XiqDigitalTwinOnboardDevice.md) | The selected target devices | [optional] 
**Unmanaged** | **bool** | Whether to unmanage the devices | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


