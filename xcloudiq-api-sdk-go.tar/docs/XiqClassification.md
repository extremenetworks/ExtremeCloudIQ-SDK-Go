# XiqClassification

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**ClassificationType** | [**XiqClassificationType**](XiqClassificationType.md) |  | 
**Match** | **bool** | Contains or not contains) | 
**ClassificationId** | **int64** | The ID of location, cloud config group, IP address, IP subnet or IP range. | 
**Value** | **string** | The value of classification | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


