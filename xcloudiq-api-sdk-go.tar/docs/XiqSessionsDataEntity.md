# XiqSessionsDataEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **int64** | The timestamp | 
**DataRateFailurePercent** | **float64** | The data rate failure percent  | [optional] 
**ClientCount** | **int32** | The client count | [optional] 
**NormalFailurePercent** | **int32** | The normal failure percent | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


