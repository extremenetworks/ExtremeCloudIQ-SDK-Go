# XiqAssignDevicesNetworkPolicyRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Devices** | [**XiqDeviceFilter**](XiqDeviceFilter.md) |  | 
**NetworkPolicyId** | **int64** | The assigned network policy | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


