# XiqPcgPortAssignment

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeviceId** | **int64** | The device ID of AP150W or AP302W | 
**Eth1UserId** | **int64** | The eth1 user ID, get available users from \&quot;/pcgs/key-based/network-policy-{policyId}/users\&quot; | [optional] 
**Eth2UserId** | **int64** | The eth2 user ID, get available users from \&quot;/pcgs/key-based/network-policy-{policyId}/users\&quot; | [optional] 
**Eth3UserId** | **int64** | The eth3 user ID, get available users from \&quot;/pcgs/key-based/network-policy-{policyId}/users\&quot; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


