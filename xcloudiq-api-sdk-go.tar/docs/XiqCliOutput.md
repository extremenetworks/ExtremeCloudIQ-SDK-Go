# XiqCliOutput

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cli** | **string** | The CLI sent to the device | 
**ResponseCode** | [**XiqCliResponseCode**](XiqCliResponseCode.md) |  | 
**Output** | **string** | The CLI output | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


