# XiqIotProfileThreadGateway

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ShortPanId** | **string** | The Personal Area Network (PAN) ID. (4 hex digits). FFFF is reserved. | 
**ExtPanId** | **string** | The Extended Personal Area Network (PAN) ID. (16 hex digits) | 
**MasterKey** | **string** | The network key is used to secure access to the Thread network. It is used to encrypt and authenticate all messages on the network. (32 hex digits) | 
**NetworkName** | **string** | A human-readable name for the network, up to 16 bytes in length. | 
**Channel** | **int32** | 802.15.4 channel number, 11-26 | 
**CommCredentials** | **string** | The Commissioner Credential is used along with the Extended PAN ID and Network Name to create the PSKc (Pre-Shared Key for the Commissioner). | [optional] 
**CommTimeout** | **int32** | After this timeout the Commissioner will shutdown. The default is 120 sec. but the max is approximately 23 days. | [optional] 
**EnableNat64** | **bool** | Enable NAT64 functions including the translator and the prefix publishing. | [optional] 
**WhiteList** | [**[]XiqIotpTgWhiteListEntry**](XiqIotpTgWhiteListEntry.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


