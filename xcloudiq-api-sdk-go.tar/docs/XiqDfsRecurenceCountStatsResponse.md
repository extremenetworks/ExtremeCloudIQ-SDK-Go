# XiqDfsRecurenceCountStatsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DfsChannelChangesEntities** | [**[]XiqDfsChannelChangesEntity**](XiqDfsChannelChangesEntity.md) | the count stats data | [optional] 
**Normal** | **int32** | The normal count | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


