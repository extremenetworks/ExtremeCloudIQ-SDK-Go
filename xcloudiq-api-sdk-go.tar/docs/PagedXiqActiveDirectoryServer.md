# PagedXiqActiveDirectoryServer

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Page** | **int32** | The current page number | 
**Count** | **int32** | The element count of the current page | 
**TotalPages** | **int32** | The total page number based on request page size | 
**TotalCount** | **int64** | The total element count | 
**Data** | [**[]XiqActiveDirectoryServer**](XiqActiveDirectoryServer.md) | The data in the current page | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


