# XiqUser

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**LoginName** | **string** | Login name, i.e. username or login Email | 
**FirstName** | **string** | The first name | [optional] 
**LastName** | **string** | The last name, i.e. family name | [optional] 
**DisplayName** | **string** | The name to display | [optional] 
**Phone** | **string** | The Phone Number | [optional] 
**JobTitle** | **string** | The job title | [optional] 
**Locale** | **string** | The locale | [optional] 
**UserRole** | [**XiqUserRole**](XiqUserRole.md) |  | [optional] 
**IdleTimeout** | **int32** | The idle timeout in minutes, the minimum value is 5 minutes and the maximum value is 4 hours | [optional] 
**LastLoginTime** | [**time.Time**](time.Time.md) | The last login time | [optional] 
**OrgId** | **int64** | The HIQ organization ID if it is HIQ user | [optional] 
**LocationIds** | **[]int64** | The assigned location IDs. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


