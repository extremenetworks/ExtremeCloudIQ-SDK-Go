# XiqLocation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**ParentId** | **int64** | The parent location ID | [optional] 
**Name** | **string** | The location name | 
**UniqueName** | **string** | The unique location name | 
**Type** | **string** | The location type | 
**Address** | **string** | The address for the location | [optional] 
**Children** | [**[]XiqLocation**](XiqLocation.md) | The child locations | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


