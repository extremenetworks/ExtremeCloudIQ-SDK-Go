# XiqEndUser

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**Name** | **string** | The user common name | 
**Description** | **string** | The user description | [optional] 
**EmailAddress** | **string** | The user email address | 
**PhoneNumber** | **string** | The user phone number | 
**Password** | **string** | The user password | [optional] 
**UserName** | **string** | The user identifiable name or the same one from common name, emailAddress or phoneNumber | 
**Organization** | **string** | The organization name | [optional] 
**VisitPurpose** | **string** | The purpose of visit | [optional] 
**EmailPasswordDelivery** | **string** | The email address for password delivery | [optional] 
**SmsPasswordDelivery** | **string** | The sms number for password delivery | [optional] 
**UserGroupId** | **int64** | The user group ID | 
**UserGroupName** | **string** | The user group name | 
**ApprovalType** | **string** | The approval type | 
**ExpiredTime** | **int64** | The password expired time | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


