# XiqClient

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**LocationId** | **int64** | The location ID | [optional] 
**DeviceId** | **int64** | The device ID | [optional] 
**Hostname** | **string** | The hostname of the client | [optional] 
**MacAddress** | **string** | The MAC address of the client | [optional] 
**IpAddress** | **string** | The IP address of the client | [optional] 
**Ipv6Address** | **string** | The IPv6 address of the client | [optional] 
**OsType** | **string** | The OS type of the client | [optional] 
**Username** | **string** | The username of the client. | [optional] 
**UserProfileName** | **string** | The user profile name of the client | [optional] 
**Connected** | **bool** | Client is connected or not | [optional] 
**OnlineTime** | [**time.Time**](time.Time.md) | The online time for the client | [optional] 
**OfflineTime** | [**time.Time**](time.Time.md) | The offline time for the client | [optional] 
**Vlan** | **int32** | The associate VLAN | [optional] 
**ConnectionType** | **int32** | The connection type | [optional] 
**Ssid** | **string** | The SSID | [optional] 
**Port** | **string** | The associate device port | [optional] 
**OrgName** | **string** | The organization name | [optional] 
**DeviceFunction** | **int32** | The associated device function | [optional] 
**DeviceMacAddress** | **string** | The associated device mac address | [optional] 
**DeviceName** | **string** | The associated device name | [optional] 
**Auth** | **int32** | The authentication type | [optional] 
**Channel** | **int32** | The channel value | [optional] 
**ClientHealth** | **int32** | The health score of client | [optional] 
**ApplicationHealth** | **int32** | The health score of application | [optional] 
**RadioHealth** | **int32** | The health score of radio | [optional] 
**NetworkHealth** | **int32** | The health score of network | [optional] 
**RadioType** | **int32** | The radio type | [optional] 
**EncryptionMethod** | **int32** | The encryption method | [optional] 
**InterfaceName** | **string** | The interface name | [optional] 
**Bssid** | **string** | The bssid | [optional] 
**Rssi** | **int32** | The RSSI | [optional] 
**Snr** | **int32** | The SNR | [optional] 
**Description** | **string** | The description of client | [optional] 
**Category** | **string** | The category of client | [optional] 
**Mobility** | **string** | The client mobility | [optional] 
**PortTypeName** | **string** | The client port type name | [optional] 
**WingAp** | **bool** | Wing ap flag | [optional] 
**Vendor** | **string** | The vendor of client | [optional] 
**Locations** | [**[]XiqLocationLegend**](XiqLocationLegend.md) | The detailed location | [optional] 
**ProductType** | **string** | The Category which describes the Extreme device types(For example:For example:SR_2208P, AP_4000, AP_5010) | [optional] 
**Alias** | **string** | The alias of the client | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


