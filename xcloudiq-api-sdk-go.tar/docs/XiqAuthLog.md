# XiqAuthLog

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | The auth log id | 
**AuthType** | **string** | The auth type | [optional] 
**Sn** | **string** | The serial number | [optional] 
**VhmId** | **string** | The vhm id | [optional] 
**Username** | **string** | The username | [optional] 
**Reply** | **string** | The reply | [optional] 
**CalledStationId** | **string** | The called station id | [optional] 
**CallingStationId** | **string** | The calling station id | [optional] 
**AuthDate** | **int64** | The authentication date | [optional] 
**Ssid** | **string** | The ssid | [optional] 
**Identity** | **string** | The identity | [optional] 
**NasPortType** | **string** | The nas port type | [optional] 
**RejectReason** | **string** | The reject reason | [optional] 
**NasIdentifier** | **string** | The nas identifier | [optional] 
**MgmtMacAddress** | **string** | The management mac address | [optional] 
**OrgId** | **int64** | The org id | [optional] 
**Timestamp** | **int64** | The audit log timestamp | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


