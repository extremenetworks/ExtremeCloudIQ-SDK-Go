# XiqDellDevices

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SnToSt** | **map[string]string** | Serial number -&gt; Service tag | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


