# XiqAssignDevicesLocationRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Devices** | [**XiqDeviceFilter**](XiqDeviceFilter.md) |  | 
**DeviceLocation** | [**XiqDeviceLocationAssignment**](XiqDeviceLocationAssignment.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


