# XiqApplicationTopClientsUsage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ApplicationId** | **int64** | The application ID | [optional] 
**ClientId** | **int64** | The TOP N client ID | [optional] 
**ClientMacAddress** | **string** | The MAC address of TOP N client | [optional] 
**ClientHostName** | **string** | The host name of TOP N client | [optional] 
**Usage** | **int64** | The TOP N client usage | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


