# XiqUpdateBuildingRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ParentId** | **int64** | The parent location ID | [optional] 
**Name** | **string** | The building name | [optional] 
**Address** | **string** | The street address | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


