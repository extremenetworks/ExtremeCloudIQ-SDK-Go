# XiqUpdateActionAnomalyDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BuildingId** | **int64** | The building ID | 
**LocationId** | **int64** | The location ID | 
**AnomalyId** | **string** | The anomaly ID | 
**AnomalyType** | [**XiqAnomalyType**](XiqAnomalyType.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


