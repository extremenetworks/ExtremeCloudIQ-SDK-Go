# XiqDeploymentStatus

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CurrentProgress** | **int32** | The current deploy progress if not finished, range from 0 to 100 | [optional] 
**CurrentStepCode** | **string** | The code of the current deploy step if not finished | [optional] 
**CurrentStepMessage** | **string** | The readable message of the current deploy step if not finished | [optional] 
**IsFinishedSuccessful** | **bool** | Indicates whether the last deployment is successful if finished | [optional] 
**LastDeployTime** | **int64** | The last deployed time (Only valid when in_progress &#x3D; false) | [optional] 
**Finished** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


