# XiqFirmwareUpgradePolicy

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnableEnforceUpgrade** | **bool** | Whether enforce firmware upgrade even if the versions are the same | 
**EnableDistributedUpgrade** | **bool** | Whether enable distributed firmware upgrade (Only applicable to APs) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


