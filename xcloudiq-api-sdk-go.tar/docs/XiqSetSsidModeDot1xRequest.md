# XiqSetSsidModeDot1xRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**KeyManagement** | [**XiqSsidDot1xKeyManagement**](XiqSsidDot1xKeyManagement.md) |  | 
**EncryptionMethod** | [**XiqSsidDot1xEncryptionMethod**](XiqSsidDot1xEncryptionMethod.md) |  | 
**EnableIdm** | **bool** | Flag for using ExtremeCloud IQ Authentication Service or not | 
**TransitionMode** | **bool** | Flag for enabling transition mode if using WPA3 as the key management type | [optional] 
**RadiusServerGroupId** | **int64** | The RADIUS server group ID if not using ExtremeCloud IQ Authentication Service | [optional] 
**UserGroupIds** | **[]int64** | The user group IDs if using ExtremeCloud IQ Authentication Service | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


