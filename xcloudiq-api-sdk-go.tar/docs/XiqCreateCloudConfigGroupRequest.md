# XiqCreateCloudConfigGroupRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The CCG name | 
**Description** | **string** | The CCG description | [optional] 
**DeviceIds** | **[]int64** | The device ID list. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


