# XiqWebhookSubscription

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**Application** | **string** | The external application name. | 
**Url** | **string** | The webhook endpoint URL. | 
**Secret** | **string** | The basic auth secret for the webhook endpoint. | 
**DataType** | [**XiqSubscriptionDataType**](XiqSubscriptionDataType.md) |  | 
**MessageType** | [**XiqSubscriptionMessageType**](XiqSubscriptionMessageType.md) |  | 
**Status** | [**XiqSubscriptionStatus**](XiqSubscriptionStatus.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


