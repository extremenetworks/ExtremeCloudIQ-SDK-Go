# XiqFlapCountEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **int64** | The timestamp | 
**FlapCount** | **float32** | The flap count | [optional] 
**SubOptimalCount** | **int32** | The sub-optimal count | [optional] 
**OptimalTimeSpent** | **float64** | The time spent | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


