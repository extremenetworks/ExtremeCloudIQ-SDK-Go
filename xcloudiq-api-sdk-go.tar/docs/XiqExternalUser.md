# XiqExternalUser

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**LoginName** | **string** | Login name, i.e. username or login Email | 
**UserRole** | [**XiqUserRole**](XiqUserRole.md) |  | 
**OrgId** | **int64** | The HIQ organization ID if it is HIQ user. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


