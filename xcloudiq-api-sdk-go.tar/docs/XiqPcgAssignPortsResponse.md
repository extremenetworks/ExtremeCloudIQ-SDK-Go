# XiqPcgAssignPortsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PolicyId** | **int64** | The network policy ID | 
**PolicyName** | **string** | The network policy name | 
**PcgPortAssignmentEntries** | [**[]XiqPcgPortAssignmentEntry**](XiqPcgPortAssignmentEntry.md) | The port assignment entry list | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


