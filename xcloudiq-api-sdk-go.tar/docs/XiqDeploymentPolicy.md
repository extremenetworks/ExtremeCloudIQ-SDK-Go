# XiqDeploymentPolicy

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnableCompleteConfigurationUpdate** | **bool** | true if update complete configuration, otherwise update delta configuration | 
**FirmwareUpgradePolicy** | [**XiqFirmwareUpgradePolicy**](XiqFirmwareUpgradePolicy.md) |  | [optional] 
**FirmwareActivateOption** | [**XiqFirmwareActivateOption**](XiqFirmwareActivateOption.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


