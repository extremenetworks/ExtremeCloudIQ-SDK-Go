# XiqDeploymentPolicy

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnableCompleteConfigurationUpdate** | **bool** | true if update complete configuration, otherwise update delta configuration. Note: ExtremeCloud IQ will neither upgrade device firmware nor reboot device for a delta configuration push. That means that the other parameters for firmware upgrade and activation are not required when this is false. | 
**FirmwareUpgradePolicy** | [**XiqFirmwareUpgradePolicy**](XiqFirmwareUpgradePolicy.md) |  | [optional] 
**FirmwareActivateOption** | [**XiqFirmwareActivateOption**](XiqFirmwareActivateOption.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


