# XiqUpdateEndUserRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UserGroupId** | **int64** | The user group ID | 
**Name** | **string** | The user common name | 
**UserName** | **string** | The designated username the same as the common name, emailAddress, or phoneNumber | [optional] 
**Organization** | **string** | The organization name | [optional] 
**VisitPurpose** | **string** | The purpose of visit | [optional] 
**Description** | **string** | The user description | [optional] 
**EmailAddress** | **string** | The user email | [optional] 
**PhoneNumber** | **string** | The user phone number | [optional] 
**Password** | **string** | The user password | [optional] 
**EmailPasswordDelivery** | **string** | The password delivery Email | [optional] 
**SmsPasswordDelivery** | **string** | The password delivery SMS | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


