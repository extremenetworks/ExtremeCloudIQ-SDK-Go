# XiqVossDevice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SerialNumber** | **string** | The serial number | 
**Location** | [**XiqDeviceLocationAssignment**](XiqDeviceLocationAssignment.md) |  | [optional] 
**NetworkPolicyId** | **int64** | The assigned network policy | [optional] 
**Hostname** | **string** | The device hostname | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


