# XiqAnomalyDevicesByLocationResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LocationEntity** | [**XiqAnomalyLocationEntity**](XiqAnomalyLocationEntity.md) |  | [optional] 
**Devices** | [**[]XiqAnomalyDeviceEntity**](XiqAnomalyDeviceEntity.md) | the anomaly devices data | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


