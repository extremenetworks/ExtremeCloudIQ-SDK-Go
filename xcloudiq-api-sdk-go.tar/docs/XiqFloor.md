# XiqFloor

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**ParentId** | **int64** | The parent building ID | 
**Name** | **string** | The floor name | 
**UniqueName** | **string** | The floor unique name | 
**Environment** | [**XiqRfEnvironmentType**](XiqRfEnvironmentType.md) |  | 
**DbAttenuation** | **float64** | The floor attenuation in dBs | 
**MeasurementUnit** | [**XiqMeasurementUnit**](XiqMeasurementUnit.md) |  | 
**InstallationHeight** | **float64** | The installation height | 
**MapSizeWidth** | **float64** | The floormap width | [optional] 
**MapSizeHeight** | **float64** | The floormap height | [optional] 
**MapName** | **string** | The floormap name | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


