# XiqDeviceStats

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TotalDeviceCount** | **int32** |  | [optional] 
**ManagedDeviceCount** | **int32** |  | [optional] 
**ConnectedDeviceCount** | **int32** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


