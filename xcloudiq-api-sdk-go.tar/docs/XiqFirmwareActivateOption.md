# XiqFirmwareActivateOption

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnableActivateAtNextReboot** | **bool** | Activate at next reboot (requires rebooting manually) | [optional] 
**ActivationDelaySeconds** | **int64** | Activate after the given seconds | [optional] 
**ActivationTime** | **int64** | Activate at the following time according to the system clock on the updated device | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


