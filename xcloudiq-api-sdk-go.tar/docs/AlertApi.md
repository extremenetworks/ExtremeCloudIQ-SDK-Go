# \AlertApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CountAlertsByGroup**](AlertApi.md#CountAlertsByGroup) | **Get** /alerts/count-by-{group} | Count the alerts by different grouping
[**ListAlerts**](AlertApi.md#ListAlerts) | **Get** /alerts | List the alerts



## CountAlertsByGroup

> map[string]int64 CountAlertsByGroup(ctx, group, startTime, endTime)

Count the alerts by different grouping

Count the number of alerts and events based on Severity, Category, and Alert Type.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**group** | [**XiqAlertGroupQuery**](.md)| The group to count from | 
**startTime** | **int64**| The start time for counting the alerts | 
**endTime** | **int64**| The end time for counting the alerts | 

### Return type

**map[string]int64**

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAlerts

> PagedXiqAlert ListAlerts(ctx, startTime, endTime, optional)

List the alerts

List a page of alerts by filter.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**startTime** | **int64**| The start time for querying alerts in milliseconds | 
**endTime** | **int64**| The end time for querying alerts in milliseconds | 
 **optional** | ***ListAlertsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListAlertsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **severity** | [**optional.Interface of XiqAlertSeverity**](.md)| The alert severity to filter | 
 **category** | [**optional.Interface of XiqAlertCategory**](.md)| The alert category to filter | 
 **alertType** | **optional.String**| The alert type to filter | 
 **keyword** | **optional.String**| The keyword to filter, such as device SN or MAC address | 

### Return type

[**PagedXiqAlert**](PagedXiqAlert.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

