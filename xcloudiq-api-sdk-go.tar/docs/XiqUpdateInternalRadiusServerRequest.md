# XiqUpdateInternalRadiusServerRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The internal RADIUS server name | 
**Description** | **string** | The internal RADIUS server description | [optional] 
**AuthenticationMethodGroup** | [**XiqInternalRadiusServerAuthenticationMethodGroup**](XiqInternalRadiusServerAuthenticationMethodGroup.md) |  | 
**DefaultAuthenticationMethod** | [**XiqInternalRadiusServerAuthenticationMethod**](XiqInternalRadiusServerAuthenticationMethod.md) |  | 
**EnableVerifyServerCert** | **bool** | Enable verify server cert or not | 
**ServerKeyPassword** | **string** | password for server key | [optional] 
**EnableCheckCertCommonName** | **bool** | Enable check cert common name or not | 
**EnableCheckUserForTlsAuth** | **bool** | Enable check user for TLS auth or not | 
**EnableCheckUserForPeapAuth** | **bool** | Enable check user for PEAP auth or not, for Active Directory as the external user directory only | [optional] 
**EnableCheckUserForTtlsAuth** | **bool** | Enable check user for TTLS auth or not, for Active Directory as the external user directory only | [optional] 
**EnableAuthenticationServer** | **bool** | Enable the RADIUS server as authentication or not | 
**EnableRadiusAccountingSettings** | **bool** | Enable the RADIUS server as accounting or not, must enable authentication server if want to enable accounting settings | 
**AuthenticationServerPort** | **int32** | Port for the authentication, must enable authentication. Max:65535, Min:1 | [optional] [default to 1812]
**ActiveSessionLimit** | **int32** | Active session limit, must enable accounting setting. Max:15, Min:0 | [optional] [default to 0]
**ActiveSessionAgeTimeout** | **int32** | Active session age timeout in seconds, must enable accounting setting. Max:300000000, Min:0 | [optional] [default to 30]
**CaCertificateId** | **int64** | The CA certificate ID, which could be fetched from endpoint: &#39;/certificates&#39; and pick up with type &#39;CA&#39; | 
**ServerCertificateId** | **int64** | The Server certificate ID, which could be fetched from endpoint: &#39;/certificates&#39; and pick up with type &#39;CERT&#39; | 
**ServerKeyId** | **int64** | The Server key ID, which could be fetched from endpoint: &#39;/certificates&#39; and pick up with type &#39;KEY&#39; | 
**Clients** | [**[]XiqRadiusClient**](XiqRadiusClient.md) | The RADIUS clients of RADIUS proxy, which could be fetched form endpoint: &#39;/radius-proxy&#39; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


