# XiqRpWmmQosSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**AccessCategory** | **string** | The media categories, including \&quot;VOICE\&quot;, \&quot;VIDEO\&quot;, \&quot;BEST_EFFORT\&quot;, and \&quot;BACKGROUND\&quot; | [optional] 
**ArbitrationInterframeSpace** | **int32** | The Arbitration Interframe space from 1 up to 15. | [optional] 
**MinContentionWindow** | **int32** | The Minimum Contention window from 1 up to 15. | [optional] 
**MaxContentionWindow** | **int32** | The Maximum Contention window from 1 up to 15. | [optional] 
**TransmissionOpportunityLimit** | **int32** | The Transmission Opportunity limit from 0 up to 8192. | [optional] 
**EnableNoAck** | **bool** | Whether to enable No Acknowledgment | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


