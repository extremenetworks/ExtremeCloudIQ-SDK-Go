# XiqAtpPacketCountsEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **int64** | The timestamp | 
**UnicastTx** | **float32** | Unicast Tx | [optional] 
**UnicastRx** | **float32** | Unicast Rx | [optional] 
**MulticastTx** | **float32** | Multicast Tx | [optional] 
**MulticastRx** | **float32** | Multicast Rx | [optional] 
**BroadcastTx** | **float32** | Broadcast Tx | [optional] 
**BroadcastRx** | **float32** | Broadcast Rx | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


