# XiqCreateVlanObjectClassifiedEntryRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VlanId** | **int32** | The VLAN ID | 
**ClassificationRuleId** | **int64** | The classification rule ID | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


