# XiqDigitalTwinDevice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Make** | [**XiqDigitalTwinMake**](XiqDigitalTwinMake.md) |  | 
**Model** | [**XiqDigitalTwinModel**](XiqDigitalTwinModel.md) |  | 
**OsType** | **string** | The Digital Twin device OS type. | [optional] 
**OsVersion** | **string** | The Digital Twin device OS version. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


