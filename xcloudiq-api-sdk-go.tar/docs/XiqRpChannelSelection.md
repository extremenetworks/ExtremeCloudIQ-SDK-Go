# XiqRpChannelSelection

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**EnableDynamicChannelSwitching** | **bool** | Whether to dynamically select and switch channels based on the defined criteria. | [optional] 
**ChannelWidth** | **string** | The channel frequency range | [optional] 
**EnableDynamicFrequencySelection** | **bool** | Whether dynamic frequency selection is enabled (a/n, a, ac mode) | [optional] 
**EnableStaticChannel** | **bool** | Whether static channel is enabled (manual channel selection return) | [optional] 
**EnableZeroWaitDfs** | **bool** | Whether ZeroWait DFS is enabled | [optional] 
**EnableUseLastSelection** | **bool** | Whether to use the last known power and channel during the AP boot up process | [optional] 
**ExcludeChannels** | **string** | The comma-separated list of excluded channels not on the selected channel width. | [optional] 
**ExcludeChannelsWidth** | **string** | The comma-separated list of excluded channels on the selected channel width. | [optional] 
**Channel** | **int32** | The number of channel selections from 1 up to 165 or AUTO for default selection. | [optional] 
**EnableLimitChannelSelection** | **bool** | Whether to allow for limiting the channel selection to non-overlapping channels. (b/g,g/n/, axes modes) | [optional] 
**ChannelRegion** | **string** | The channel region -- \&quot;USA\&quot;, \&quot;Canada\&quot;, \&quot;Europe\&quot;, or \&quot;World\&quot; | [optional] 
**ChannelModel** | **int32** | The number of channel models to limit. | [optional] 
**Channels** | **string** | The comma separated list of channels allowed channel switching | [optional] 
**EnableChannelAutoSelection** | **bool** | Whether to enable automatic channel switching during specified time interval. | [optional] 
**ChannelSelectionStartTime** | **string** | The start time for channel switching in 24-hr time format of hh:mm | [optional] 
**ChannelSelectionEndTime** | **string** | The end time for channel switching in 24-hr time format of hh:mm | [optional] 
**EnableAvoidSwitchChannelIfClientsConnected** | **bool** | Whether to avoid channel switching if there are already max connected clients | [optional] 
**ChannelSelectionMaxClients** | **int32** | The maximum number of connected clients from 0 up to 100 to avoid switching | [optional] 
**EnableSwitchChannelIfExceedThreshold** | **bool** | Whether to enable channel switching when RF interference exceeds the threshold | [optional] 
**RfInterferenceThreshold** | **int32** | The RF interference threshold from 10 up to 80 for channel switching. | [optional] 
**CrcErrorThreshold** | **int32** | The CRC error threshold from 10 up to 80 for channel switching. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


