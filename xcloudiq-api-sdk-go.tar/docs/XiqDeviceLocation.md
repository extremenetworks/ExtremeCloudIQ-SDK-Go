# XiqDeviceLocation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LocationId** | **int64** | The assigned location ID, it must NOT be BUILDING type | [optional] 
**CreateTime** | [**time.Time**](time.Time.md) | The timestamp when the device assigned to the location | 
**UpdateTime** | [**time.Time**](time.Time.md) | The timestamp when the location info was last updated | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**ParentId** | **int64** | The parent location ID | [optional] 
**LocationName** | **string** | The location name | 
**LocationUniqueName** | **string** | The unique location name | 
**LocationType** | **string** | The location type | 
**LocationAddress** | **string** | The address for the location | [optional] 
**X** | **float64** | The horizontal value in the floor map | [optional] 
**Y** | **float64** | The vertical value in the floor map | [optional] 
**Latitude** | **float64** | The latitude in the geography | [optional] 
**Longitude** | **float64** | The longitude in the geography | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


