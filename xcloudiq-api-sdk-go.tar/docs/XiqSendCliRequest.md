# XiqSendCliRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Devices** | [**XiqDeviceFilter**](XiqDeviceFilter.md) |  | 
**Clis** | **[]string** | The one or multiple CLIs to send | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


