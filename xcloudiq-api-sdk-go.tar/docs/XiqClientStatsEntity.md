# XiqClientStatsEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClientMac** | **string** | The client mac | [optional] 
**ClientName** | **string** | The client name | [optional] 
**ClientHostOs** | **string** | The client host os | [optional] 
**AvgSnr** | **int32** | The average SNR | [optional] 
**AvgTxRate** | **int32** | The average TX rate | [optional] 
**AvgRxRate** | **int32** | The average RX rate | [optional] 
**ClientId** | **int64** | The client id | [optional] 
**AvgRssi** | **int32** |  The average RSSI  | [optional] 
**HealthScore** | [**XiqAnomalyHealthType**](XiqAnomalyHealthType.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


