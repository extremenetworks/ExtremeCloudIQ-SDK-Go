# XiqPoeFlappingStatsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Summary** | **string** | the anomaly location | [optional] 
**FlapCountEntities** | [**[]XiqFlapCountEntity**](XiqFlapCountEntity.md) | the anomaly devices data | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


