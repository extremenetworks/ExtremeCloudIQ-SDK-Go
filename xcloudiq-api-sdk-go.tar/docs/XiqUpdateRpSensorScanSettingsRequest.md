# XiqUpdateRpSensorScanSettingsRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnableScanAllChannels** | **bool** | Whether to enable scanning all channels | [optional] 
**DwellTime** | **string** | The dwell time in the range from 250 to 30000 ms | [optional] 
**ScanChannels** | **string** | The comma separated list of scan channels | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


