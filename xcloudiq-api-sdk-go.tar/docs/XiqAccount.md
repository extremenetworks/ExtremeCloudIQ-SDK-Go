# XiqAccount

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**Name** | **string** | Account name | 
**AccountType** | [**XiqAccountType**](XiqAccountType.md) |  | 
**AccountMode** | [**XiqAccountMode**](XiqAccountMode.md) |  | 
**Quota** | **string** | The API quota policy | 
**DataCenter** | **string** | The default Regional Data Center (RDC) to hold data from customer network | 
**Industry** | **string** | The industry of the account belongs to | [optional] 
**Country** | **string** | The country for the account | [optional] 
**State** | **string** | The state for the account (if any) | [optional] 
**City** | **string** | The city for the account | [optional] 
**Address** | **string** | The address for the account | [optional] 
**Zipcode** | **string** | The zipcode of the address | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


