# XiqDeviceLevelSsid

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SsidId** | **int64** | The SSID ID to override, cannot be null. | 
**Ssid** | **string** | The broadcast ssid name to override. Can only override if the SSID profile is OPEN or PSK mode. | [optional] 
**Passphrase** | **string** | The ssid passphrase to override. Can only override if the SSID profile is in PSK mode. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


