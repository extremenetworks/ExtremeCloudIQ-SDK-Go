# XiqAuditLog

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The audit log id | 
**Category** | [**XiqAuditLogCategory**](XiqAuditLogCategory.md) |  | [optional] 
**UserId** | **int64** | The user id | [optional] 
**Code** | **int32** | The audit log code | [optional] 
**Username** | **string** | The user name | [optional] 
**VhmName** | **string** | The vhm name | [optional] 
**Parameters** | **string** | The audit log parameters | [optional] 
**OrgId** | **int64** | The org id | [optional] 
**Timestamp** | **int64** | The audit log timestamp | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


