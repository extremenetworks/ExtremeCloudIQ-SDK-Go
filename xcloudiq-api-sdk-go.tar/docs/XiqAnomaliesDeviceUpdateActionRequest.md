# XiqAnomaliesDeviceUpdateActionRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AnomalyType** | [**XiqAnomalyType**](XiqAnomalyType.md) |  | [optional] 
**ActionType** | [**XiqActionType**](XiqActionType.md) |  | [optional] 
**LocationId** | **int64** | The location id | [optional] 
**AnomalyId** | **string** | The anomaly Id | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


