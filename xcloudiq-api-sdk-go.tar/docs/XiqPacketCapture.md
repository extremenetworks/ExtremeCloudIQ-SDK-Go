# XiqPacketCapture

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | [optional] 
**StartTime** | [**time.Time**](time.Time.md) | The packet capture start time | [optional] 
**EndTime** | [**time.Time**](time.Time.md) | The packet capture end time | [optional] 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**Name** | **string** | The packet capture session name. If the name is null or empty, it will be auto generated. | [optional] 
**Duration** | **int32** | An integer containing the set packet capture duration in seconds, from 5 to a maximum of 604800 seconds (1 week). If duration is set to 0 or unspecified, capture stops when platform-maximum size is reached. | [optional] 
**CaptureIdType** | [**XiqCaptureIdentifierType**](XiqCaptureIdentifierType.md) |  | [optional] 
**ApSerialNumber** | **string** | The globally unique serial number of the device being registered. The serial number is represented as a string. | [optional] 
**DeviceIds** | **[]int64** | The device ID list. | [optional] 
**LocationId** | **int64** | The assigned location ID, it must be FLOOR type | [optional] 
**Destination** | [**XiqDestinationType**](XiqDestinationType.md) |  | [optional] 
**Filter** | [**XiqCaptureFilter**](XiqCaptureFilter.md) |  | [optional] 
**CaptureIf** | [**XiqCaptureLocation**](XiqCaptureLocation.md) |  | [optional] 
**Status** | [**XiqPacketCaptureStatus**](XiqPacketCaptureStatus.md) |  | [optional] 
**Results** | [**[]XiqCaptureResult**](XiqCaptureResult.md) | The list of packet capture results - a PacketCaptureResult for each device&#39;s interface | [optional] 
**CloudStorage** | **string** | XIQ cloud storage location for the archive of all capture files in this capture session, if available. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


