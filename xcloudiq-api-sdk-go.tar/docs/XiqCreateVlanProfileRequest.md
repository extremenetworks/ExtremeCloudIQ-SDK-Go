# XiqCreateVlanProfileRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The VLAN profile name | 
**DefaultVlanId** | **int32** | The default VLAN ID | 
**EnableClassification** | **bool** | If apply VLANs to devices using classification | 
**ClassifiedEntries** | [**[]XiqCreateVlanObjectClassifiedEntryRequest**](XiqCreateVlanObjectClassifiedEntryRequest.md) | The VLAN object classified entries | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


