# XiqVlanProfile

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**Name** | **string** | The VLAN profile name | 
**DefaultVlanId** | **int32** | The default VLAN ID | 
**EnableClassification** | **bool** | If apply VLANs to devices using classification | 
**ClassifiedEntries** | [**[]XiqVlanObjectClassifiedEntry**](XiqVlanObjectClassifiedEntry.md) | The VLAN object classified entries | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


