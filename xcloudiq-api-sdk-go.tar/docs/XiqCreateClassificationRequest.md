# XiqCreateClassificationRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClassificationType** | **string** | Classification type | 
**Match** | **bool** | Contains or not contains | 
**ClassificationTypeId** | **int64** | The ID of location, cloud config group, IP address, IP subnet or IP range. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


