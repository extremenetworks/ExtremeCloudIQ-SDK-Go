# XiqCreateLdapServerRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The LDAP server name | 
**Description** | **string** | The LDAP server description(optional) | [optional] 
**EnableTls** | **bool** | To enable TLS or not, if ture, caCertificateId, clientCertificateId and clientKeyId must be specified | 
**BindDn** | **string** | The LDAP server bind DN name | 
**BindDnPassword** | **string** | The LDAP server bind DN password | 
**BaseDn** | **string** | The RADIUS user base DN | 
**L3AddressProfileId** | **int64** | The L3 address profile ID | 
**ProtocolType** | [**XiqLdapProtocolType**](XiqLdapProtocolType.md) |  | 
**EnableStripRealmName** | **bool** | enable strip realm name or not | 
**DestinationPort** | **int32** | The LDAP server destination port (1 ~ 65535) | 
**VerificationMode** | [**XiqLdapServerVerificationMode**](XiqLdapServerVerificationMode.md) |  | 
**CaCertificateId** | **int64** | The CA certificate ID, refer to XiqCertificate | [optional] 
**ClientCertificateId** | **int64** | The client certificate ID, refer to XiqCertificate | [optional] 
**ClientKeyId** | **int64** | The client key ID, refer to XiqCertificate | [optional] 
**ClientKeyPassword** | **string** | The LDAP server client key password | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


