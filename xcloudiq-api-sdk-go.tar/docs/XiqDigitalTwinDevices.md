# XiqDigitalTwinDevices

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Dts** | [**[]XiqDigitalTwinDevice**](XiqDigitalTwinDevice.md) | The Digital Twin devices to onboard. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


