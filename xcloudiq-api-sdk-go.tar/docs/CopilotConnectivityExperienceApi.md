# \CopilotConnectivityExperienceApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetWiredConnectivityExperience**](CopilotConnectivityExperienceApi.md#GetWiredConnectivityExperience) | **Get** /copilot/connectivity/wired/experience | 
[**GetWiredEvents**](CopilotConnectivityExperienceApi.md#GetWiredEvents) | **Get** /copilot/connectivity/wired/events | 
[**GetWiredHardware**](CopilotConnectivityExperienceApi.md#GetWiredHardware) | **Get** /copilot/connectivity/wired/hardware | 
[**GetWiredQualityIndex**](CopilotConnectivityExperienceApi.md#GetWiredQualityIndex) | **Get** /copilot/connectivity/wired/quality-index | 
[**GetWirelessApps**](CopilotConnectivityExperienceApi.md#GetWirelessApps) | **Get** /copilot/connectivity/wireless/apps | 
[**GetWirelessConnectivityExperience**](CopilotConnectivityExperienceApi.md#GetWirelessConnectivityExperience) | **Get** /copilot/connectivity/wireless/experience | 
[**GetWirelessEvents**](CopilotConnectivityExperienceApi.md#GetWirelessEvents) | **Get** /copilot/connectivity/wireless/events | 
[**GetWirelessPerformance**](CopilotConnectivityExperienceApi.md#GetWirelessPerformance) | **Get** /copilot/connectivity/wireless/performance | 
[**GetWirelessQualityIndex**](CopilotConnectivityExperienceApi.md#GetWirelessQualityIndex) | **Get** /copilot/connectivity/wireless/quality-index | 
[**GetWirelessTimeToConnect**](CopilotConnectivityExperienceApi.md#GetWirelessTimeToConnect) | **Get** /copilot/connectivity/wireless/time-to-connect | 
[**GetWirelessViews**](CopilotConnectivityExperienceApi.md#GetWirelessViews) | **Get** /copilot/connectivity/wireless/views | 



## GetWiredConnectivityExperience

> PagedXiqConnectivityExperienceData GetWiredConnectivityExperience(ctx, viewType, startTime, endTime, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**viewType** | [**XiqWiredViewType**](.md)| The type of View | 
**startTime** | **int64**| The start time to query, epoch time in milliseconds since 1/1/1970 | 
**endTime** | **int64**| The end time to query, epoch time in milliseconds since 1/1/1970 | 
 **optional** | ***GetWiredConnectivityExperienceOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetWiredConnectivityExperienceOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **sortField** | [**optional.Interface of XiqSortField**](.md)| sort by name or quality index | 
 **sortOrder** | [**optional.Interface of XiqSortOrder**](.md)| The sorting order | 

### Return type

[**PagedXiqConnectivityExperienceData**](PagedXiqConnectivityExperienceData.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWiredEvents

> PagedXiqWiredEventEntity GetWiredEvents(ctx, viewType, startTime, endTime, forensicBucket, scoreType, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**viewType** | [**XiqWiredViewType**](.md)| The type of View | 
**startTime** | **int64**| The start time to query, epoch time in milliseconds since 1/1/1970 | 
**endTime** | **int64**| The end time to query, epoch time in milliseconds since 1/1/1970 | 
**forensicBucket** | [**XiqForensicBucket**](.md)| The selected time bucket | 
**scoreType** | [**XiqCopilotWiredEventsScoreType**](.md)| The selected score type | 
 **optional** | ***GetWiredEventsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetWiredEventsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------





 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **sortBy** | [**optional.Interface of XiqCopilotEventsWiredSortField**](.md)| The sort field | 
 **sortOrder** | [**optional.Interface of XiqSortOrder**](.md)| The sorting order | 
 **viewId** | **optional.String**| The view id based on view type | [default to ]
 **searchKey** | **optional.String**| The selected search key | [default to ]
 **locationType** | **optional.String**| The selected location type | [default to ]
 **locationId** | **optional.String**| The selected location id | [default to 0]
 **timestamp** | **optional.Int64**| The timestamp to query, epoch time in milliseconds since 1/1/1970 | 

### Return type

[**PagedXiqWiredEventEntity**](PagedXiqWiredEventEntity.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWiredHardware

> XiqWiredHardwareResponse GetWiredHardware(ctx, viewType, startTime, endTime, forensicBucket, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**viewType** | [**XiqWiredViewType**](.md)| The type of View | 
**startTime** | **int64**| The start time to query, epoch time in milliseconds since 1/1/1970 | 
**endTime** | **int64**| The end time to query, epoch time in milliseconds since 1/1/1970 | 
**forensicBucket** | [**XiqForensicBucket**](.md)| The selected time bucket | 
 **optional** | ***GetWiredHardwareOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetWiredHardwareOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




 **viewId** | **optional.String**| The view id based on view type | [default to ]

### Return type

[**XiqWiredHardwareResponse**](XiqWiredHardwareResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWiredQualityIndex

> XiqWiredQualityIndexResponse GetWiredQualityIndex(ctx, startTime, endTime, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**startTime** | **int64**| The start time to query, epoch time in milliseconds since 1/1/1970 | 
**endTime** | **int64**| The end time to query, epoch time in milliseconds since 1/1/1970 | 
 **optional** | ***GetWiredQualityIndexOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetWiredQualityIndexOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **viewType** | [**optional.Interface of XiqWiredViewType**](.md)| The type of View | 
 **viewId** | **optional.String**| The view id based on view type | [default to ]
 **forensicBucket** | [**optional.Interface of XiqForensicBucket**](.md)| The selected time bucket | 

### Return type

[**XiqWiredQualityIndexResponse**](XiqWiredQualityIndexResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWirelessApps

> XiqWirelessAppsResponse GetWirelessApps(ctx, viewType, startTime, endTime, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**viewType** | [**XiqConnectivityExperienceViewType**](.md)| The type of View | 
**startTime** | **int64**| The start time to query, epoch time in milliseconds since 1/1/1970 | 
**endTime** | **int64**| The end time to query, epoch time in milliseconds since 1/1/1970 | 
 **optional** | ***GetWirelessAppsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetWirelessAppsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **viewId** | **optional.String**| The view type identifier | [default to ]
 **forensicBucket** | [**optional.Interface of XiqForensicBucket**](.md)| The time period bucket detected | 
 **locationId** | **optional.String**| The location identifier | [default to 0]
 **locationType** | **optional.String**| The location type | [default to ]

### Return type

[**XiqWirelessAppsResponse**](XiqWirelessAppsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWirelessConnectivityExperience

> PagedXiqConnectivityExperienceData GetWirelessConnectivityExperience(ctx, viewType, startTime, endTime, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**viewType** | [**XiqConnectivityExperienceViewType**](.md)| View by location, ssid or osTypes | 
**startTime** | **int64**| The start time to query, epoch time in milliseconds since 1/1/1970 | 
**endTime** | **int64**| The end time to query, epoch time in milliseconds since 1/1/1970 | 
 **optional** | ***GetWirelessConnectivityExperienceOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetWirelessConnectivityExperienceOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Number of Records, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **sortField** | [**optional.Interface of XiqSortField**](.md)| sort by name or quality index | 
 **sortOrder** | [**optional.Interface of XiqSortOrder**](.md)| The sorting order | 

### Return type

[**PagedXiqConnectivityExperienceData**](PagedXiqConnectivityExperienceData.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWirelessEvents

> PagedXiqCopilotWirelessEvent GetWirelessEvents(ctx, viewType, startTime, endTime, scoreType, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**viewType** | [**XiqConnectivityExperienceViewType**](.md)| View by location, ssid or osTypes | 
**startTime** | **int64**| The start time to query, epoch time in milliseconds since 1/1/1970 | 
**endTime** | **int64**| The end time to query, epoch time in milliseconds since 1/1/1970 | 
**scoreType** | [**XiqCopilotWirelessEventsScoreType**](.md)| The wireless score type | 
 **optional** | ***GetWirelessEventsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetWirelessEventsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Number of Records, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **sortField** | [**optional.Interface of XiqCopilotEventsWirelessSortField**](.md)| the sort field | 
 **sortOrder** | [**optional.Interface of XiqSortOrder**](.md)| The sorting order | 
 **viewId** | **optional.String**| The view type identifier | [default to ]
 **forensicBucket** | [**optional.Interface of XiqForensicBucket**](.md)| The time period bucket detected | 
 **searchKey** | **optional.String**| The search key | [default to ]
 **locationId** | **optional.String**| The location identifier | [default to 0]
 **locationType** | **optional.String**| The location type | 
 **timestamp** | **optional.Int64**| The timestamp to query, epoch time in milliseconds since 1/1/1970 | 

### Return type

[**PagedXiqCopilotWirelessEvent**](PagedXiqCopilotWirelessEvent.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWirelessPerformance

> XiqWirelessConnectivityPerformanceResponse GetWirelessPerformance(ctx, viewType, startTime, endTime, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**viewType** | [**XiqConnectivityExperienceViewType**](.md)| The type of View | 
**startTime** | **int64**| The start time to query, epoch time in milliseconds since 1/1/1970 | 
**endTime** | **int64**| The end time to query, epoch time in milliseconds since 1/1/1970 | 
 **optional** | ***GetWirelessPerformanceOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetWirelessPerformanceOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **viewId** | **optional.String**| The view type identifier | [default to ]
 **forensicBucket** | [**optional.Interface of XiqForensicBucket**](.md)| The time period bucket detected | 
 **locationId** | **optional.String**| The location identifier | [default to 0]
 **locationType** | **optional.String**| The location type | [default to ]

### Return type

[**XiqWirelessConnectivityPerformanceResponse**](XiqWirelessConnectivityPerformanceResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWirelessQualityIndex

> XiqWirelessQualityIndexResponse GetWirelessQualityIndex(ctx, viewType, startTime, endTime, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**viewType** | [**XiqConnectivityExperienceViewType**](.md)| The type of View | 
**startTime** | **int64**| The start time to query, epoch time in milliseconds since 1/1/1970 | 
**endTime** | **int64**| The end time to query, epoch time in milliseconds since 1/1/1970 | 
 **optional** | ***GetWirelessQualityIndexOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetWirelessQualityIndexOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **viewId** | **optional.String**| The view type identifier | [default to ]
 **forensicBucket** | [**optional.Interface of XiqForensicBucket**](.md)| The time period bucket detected | 
 **locationId** | **optional.String**| The location identifier | [default to 0]
 **locationType** | **optional.String**| The location type | 

### Return type

[**XiqWirelessQualityIndexResponse**](XiqWirelessQualityIndexResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWirelessTimeToConnect

> XiqWirelessTimeToConnectResponse GetWirelessTimeToConnect(ctx, viewType, startTime, endTime, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**viewType** | [**XiqConnectivityExperienceViewType**](.md)| The type of View | 
**startTime** | **int64**| The start time to query, epoch time in milliseconds since 1/1/1970 | 
**endTime** | **int64**| The end time to query, epoch time in milliseconds since 1/1/1970 | 
 **optional** | ***GetWirelessTimeToConnectOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetWirelessTimeToConnectOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **viewId** | **optional.String**| The view type identifier | [default to ]
 **forensicBucket** | [**optional.Interface of XiqForensicBucket**](.md)| The time period bucket detected | 
 **locationId** | **optional.String**| The location identifier | [default to 0]
 **locationType** | **optional.String**| The location type | 

### Return type

[**XiqWirelessTimeToConnectResponse**](XiqWirelessTimeToConnectResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWirelessViews

> XiqWirelessViewsTypeResponse GetWirelessViews(ctx, viewType)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**viewType** | [**XiqWirelessViewsListType**](.md)| The type of View | 

### Return type

[**XiqWirelessViewsTypeResponse**](XiqWirelessViewsTypeResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

