# XiqRpMacOuiProfile

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**Name** | **string** | The product model | [optional] 
**Description** | **string** | The product description | [optional] 
**Predefined** | **bool** | Whether the MAC Oui is predefined. | [optional] 
**Value** | **string** | The MAC octets | [optional] 
**MacType** | **string** | The type or \&quot;MAC_OUI\&quot; | [optional] 
**DefenderDefined** | **bool** | Whether defender is defined | [optional] 
**ExtremeIotDefined** | **bool** | Whether is the Extreme Iot Defined | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


