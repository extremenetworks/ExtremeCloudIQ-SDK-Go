# XiqDevice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**SerialNumber** | **string** | The device serial number, valid for all non-HAC devices | [optional] 
**ServiceTag** | **string** | The device service tag, valid for all HAC devices | [optional] 
**MacAddress** | **string** | The device MAC address | [optional] 
**DeviceFunction** | [**XiqDeviceFunction**](XiqDeviceFunction.md) |  | [optional] 
**ProductType** | **string** | The product type, such as: AP_230, BR_100, NX9600, etc. | [optional] 
**Hostname** | **string** | The device hostname | [optional] 
**IpAddress** | **string** | The device IPv4 address | [optional] 
**SoftwareVersion** | **string** | The device OS software version | [optional] 
**DeviceAdminState** | [**XiqDeviceAdminState**](XiqDeviceAdminState.md) |  | [optional] 
**Connected** | **bool** | The device connection status | [optional] 
**LastConnectTime** | [**time.Time**](time.Time.md) | The device last connect time | [optional] 
**NetworkPolicyName** | **string** | The network policy name for the device | [optional] 
**NetworkPolicyId** | **int64** | The network policy ID for the device | [optional] 
**PrimaryNtpServerAddress** | **string** | The primary NTP server address for the device | [optional] 
**PrimaryDnsServerAddress** | **string** | The primary DNS server address for the device | [optional] 
**SubnetMask** | **string** | The subnet mask for the device | [optional] 
**DefaultGateway** | **string** | The default gateway for the device | [optional] 
**Ipv6Address** | **string** | The ipv6 address for the device | [optional] 
**Ipv6Netmask** | **int32** | The ipv6 netmask for the device | [optional] 
**Simulated** | **bool** | The device is simulated or not | [optional] 
**DisplayVersion** | **string** | The display version for the device | [optional] 
**ActiveClients** | **int32** | The active client count for the device | [optional] 
**LocationId** | **int64** | The location ID for the device | [optional] 
**Locations** | [**[]XiqLocationLegend**](XiqLocationLegend.md) | The detailed location | [optional] 
**CountryCode** | **int32** | The assigned country code on the device | [optional] 
**Description** | **string** | The device description | [optional] 
**LldpCdpInfos** | [**[]XiqDeviceLldpCdpInfo**](XiqDeviceLldpCdpInfo.md) | The device LLDP/CDP information | [optional] 
**SystemUpTime** | **int64** | The device uptime | [optional] 
**ConfigMismatch** | **bool** | Config audit status(MATCHED or UNMATCHED) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


