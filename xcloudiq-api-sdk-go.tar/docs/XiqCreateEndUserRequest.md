# XiqCreateEndUserRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UserGroupId** | **int64** | The user group ID | 
**Name** | **string** | The user common name | [optional] 
**UserName** | **string** | The designated username, must match either the user&#39;s name, emailAddress, or phoneNumber | 
**Organization** | **string** | The organization name | [optional] 
**VisitPurpose** | **string** | The purpose of visit | [optional] 
**Description** | **string** | The user description | [optional] 
**EmailAddress** | **string** | The user email | [optional] 
**PhoneNumber** | **string** | The user phone number | [optional] 
**Password** | **string** | The user password, if null a random password will be generated base on the user group rule | [optional] 
**EmailPasswordDelivery** | **string** | The password delivery Email | [optional] 
**SmsPasswordDelivery** | **string** | The password delivery SMS | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


