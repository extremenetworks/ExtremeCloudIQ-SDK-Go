# \ConfigurationDeploymentApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeployConfig**](ConfigurationDeploymentApi.md#DeployConfig) | **Post** /deployments | Push configuration and upgrade firmware
[**GetDeployOverview**](ConfigurationDeploymentApi.md#GetDeployOverview) | **Get** /deployments/overview | Get configuration deployment overview
[**GetDeployStatus**](ConfigurationDeploymentApi.md#GetDeployStatus) | **Get** /deployments/status | Get configuration deployment status



## DeployConfig

> XiqDeploymentResponse DeployConfig(ctx, xiqDeploymentRequest)

Push configuration and upgrade firmware

Push configuration and upgrade firmware to the target devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqDeploymentRequest** | [**XiqDeploymentRequest**](XiqDeploymentRequest.md)| The device deploy configuration | 

### Return type

[**XiqDeploymentResponse**](XiqDeploymentResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDeployOverview

> XiqDeploymentOverview GetDeployOverview(ctx, )

Get configuration deployment overview

Get configuration deployment status overview.

### Required Parameters

This endpoint does not need any parameter.

### Return type

[**XiqDeploymentOverview**](XiqDeploymentOverview.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDeployStatus

> map[string]XiqDeploymentStatus GetDeployStatus(ctx, deviceIds)

Get configuration deployment status

Get configuration deployment status for the target devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**deviceIds** | [**[]int64**](int64.md)| The target device IDs | 

### Return type

[**map[string]XiqDeploymentStatus**](XiqDeploymentStatus.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

