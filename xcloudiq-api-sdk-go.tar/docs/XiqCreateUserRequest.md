# XiqCreateUserRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LoginName** | **string** | Login name, i.e. username or login Email | 
**DisplayName** | **string** | The user name to displa | 
**IdleTimeout** | **int32** | The idle timeout in minutes, the minimum value is 5 minutes and the maximum value is 4 hours | [optional] 
**UserRole** | [**XiqUserRole**](XiqUserRole.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


