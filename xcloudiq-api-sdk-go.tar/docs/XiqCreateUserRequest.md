# XiqCreateUserRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LoginName** | **string** | Login name, i.e. username or login Email | 
**DisplayName** | **string** | The user name to display | 
**IdleTimeout** | **int32** | The idle timeout in minutes. | 
**UserRole** | [**XiqUserRole**](XiqUserRole.md) |  | 
**LocationIds** | **[]int64** | The location IDs to assign. Null or empty list will assign Admin default locations. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


