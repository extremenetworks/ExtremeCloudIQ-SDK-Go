# XiqRadioProfile

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**Name** | **string** | The radio profile name | [optional] 
**Predefined** | **bool** | Whether the radio profile is predefined or user-customized. | [optional] 
**Description** | **string** | The radio profile description. | [optional] 
**TransmissionPower** | **int32** | The transmission power floor from 1 up to 20 dBm or null for Auto. | [optional] 
**MaxTransmitPower** | **int32** | The maximum transmit power from 10 up to 20 dBm. | [optional] 
**TransmissionPowerFloor** | **int32** | The transmission power floor from 2 up to 20 dBm. | [optional] 
**TransmissionPowerMaxDrop** | **int32** | The transmission power max drop from 0 up to 18 dB. | [optional] 
**MaxClients** | **int32** | The maximum number of clients from 1 up to 255. | [optional] 
**EnableClientTransmissionPower** | **bool** | Whether or not client transmission power control (802.11h) is enabled. | [optional] 
**ClientTransmissionPower** | **int32** | The client transmission power from 1 up to 20 dBm if it is enabled. | [optional] 
**EnableOfdma** | **bool** | Whether to enable Orthogonal Frequency Division Multiple Access (802.11ax) for multiple-user access by subdividing a channel. | [optional] 
**RadioMode** | [**XiqRadioMode**](XiqRadioMode.md) |  | [optional] 
**NeighborhoodAnalysisId** | **int64** | The neighborhood analysis Id. | [optional] 
**ChannelSelectionId** | **int64** | The channel selection Id. | [optional] 
**RadioUsageOptimizationId** | **int64** | The radio usage optimization Id. | [optional] 
**MiscellaneousSettingsId** | **int64** | The miscellaneous settings Id | [optional] 
**PresenceServerSettingsId** | **int64** | The presence server settings Id. | [optional] 
**SensorScanSettingsId** | **int64** | The sensor scan settings Id. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


