# XiqWiredHardwareEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**QualityIndex** | **int32** | the quality index | [optional] 
**Timestamp** | **int64** | the timestamp | 
**TotalSwitches** | **int32** | the total number of switches | [optional] 
**AffectedRatio** | **int32** | the affected ratio | [optional] 
**Affected** | **float64** | the affected percentage | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


