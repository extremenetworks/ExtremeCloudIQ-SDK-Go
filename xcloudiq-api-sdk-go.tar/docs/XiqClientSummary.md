# XiqClientSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ConnectedWirelessClientCount** | **int64** | The connected wireless client count | [optional] 
**DetectedWiredClientCount** | **int64** | The detected wired client count | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


