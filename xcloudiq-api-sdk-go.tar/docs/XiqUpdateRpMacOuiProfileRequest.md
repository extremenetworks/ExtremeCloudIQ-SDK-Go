# XiqUpdateRpMacOuiProfileRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The product name | [optional] 
**Value** | **string** | The product MAC or OUI | [optional] 
**Description** | **string** | The product description | [optional] 
**MacType** | **string** | The json type, eg, \&quot;mac-oui-profile\&quot;  or \&quot;MAC_OUI\&quot; | [optional] 
**DefenderDefined** | **bool** | Whether defender is defined | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


