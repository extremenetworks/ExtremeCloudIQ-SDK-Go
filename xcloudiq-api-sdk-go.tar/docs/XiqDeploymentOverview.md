# XiqDeploymentOverview

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InProgressDevices** | **int32** | The device count with in progress deployment | 
**TotalProgress** | **int32** | The total progress, range from 0 to 100 | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


