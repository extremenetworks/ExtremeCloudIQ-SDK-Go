# XiqRadiusClientObjectEntry

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ServerRole** | [**XiqServerRole**](XiqServerRole.md) |  | 
**ServerType** | [**XiqRadiusClientObjectType**](XiqRadiusClientObjectType.md) |  | 
**RadiusServerId** | **int64** | The ID of the RADIUS server object, for EXTERNAL_RADIUS_SERVER please use the ID of external RADIUS server object. For INTERNAL_RADIUS_SERVER, please use the RADIUS device ID | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


