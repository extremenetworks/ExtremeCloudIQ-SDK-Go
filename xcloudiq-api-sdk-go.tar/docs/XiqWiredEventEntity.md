# XiqWiredEventEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeviceId** | **string** | the device id | [optional] 
**Hostname** | **string** | the host name | [optional] 
**InterfaceErrors** | **float64** | the interface errors ratio | [optional] 
**MaximumErrors** | **float64** | the maximum errors ratio | [optional] 
**MgmtIp** | **string** | the management ip | [optional] 
**Port** | **string** | the port | [optional] 
**SerialNumber** | **string** | the device serial number | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


