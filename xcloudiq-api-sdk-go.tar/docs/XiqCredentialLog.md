# XiqCredentialLog

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The Credential log id | 
**Username** | **string** | The username | [optional] 
**VhmId** | **string** | The vhm id | [optional] 
**OrgId** | **int64** | The org id | [optional] 
**Timestamp** | **int64** | The credential log timestamp | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


