# XiqUpdateRpWmmQosSettingsRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArbitrationInterframeSpace** | **int32** | The Arbitration Interframe space, in the range of 1 to 15. | [optional] 
**MinContentionWindow** | **int32** | The Minimum Contention window, in the range of 1 to 15. | [optional] 
**MaxContentionWindow** | **int32** | The Maximum Contention window, in the range of 1 to 15. | [optional] 
**TransmissionOpportunityLimit** | **int32** | The Transmission Opportunity limit, in the range of 0 to 8192. | [optional] 
**EnableNoAck** | **bool** | Whether to enable No Acknowledgment | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


