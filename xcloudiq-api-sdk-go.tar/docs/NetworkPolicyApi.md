# \NetworkPolicyApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddSsidsToNetworkPolicy**](NetworkPolicyApi.md#AddSsidsToNetworkPolicy) | **Post** /network-policies/{id}/ssids/:add | Add SSIDs to a network policy
[**CreateNetworkPolicy**](NetworkPolicyApi.md#CreateNetworkPolicy) | **Post** /network-policies | Create network policy
[**DeleteNetworkPolicy**](NetworkPolicyApi.md#DeleteNetworkPolicy) | **Delete** /network-policies/{id} | Delete the network policy
[**DeleteSsidsFromNetworkPolicy**](NetworkPolicyApi.md#DeleteSsidsFromNetworkPolicy) | **Post** /network-policies/{id}/ssids/:remove | Removes SSIDs from the network policy
[**GetNetworkPolicy**](NetworkPolicyApi.md#GetNetworkPolicy) | **Get** /network-policies/{id} | Get the network policy
[**ListNetworkPolices**](NetworkPolicyApi.md#ListNetworkPolices) | **Get** /network-policies | List network policies
[**ListSsidsByNetworkPolicy**](NetworkPolicyApi.md#ListSsidsByNetworkPolicy) | **Get** /network-policies/{id}/ssids | List SSIDs for a network policy
[**UpdateNetworkPolicy**](NetworkPolicyApi.md#UpdateNetworkPolicy) | **Put** /network-policies/{id} | Update the network policy



## AddSsidsToNetworkPolicy

> AddSsidsToNetworkPolicy(ctx, id, requestBody)

Add SSIDs to a network policy

Add SSIDs to a specific network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The network policy ID | 
**requestBody** | [**[]int64**](int64.md)| The SSID ids to be added to the network policy | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkPolicy

> XiqNetworkPolicy CreateNetworkPolicy(ctx, xiqCreateNetworkPolicyRequest)

Create network policy

Create a new network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateNetworkPolicyRequest** | [**XiqCreateNetworkPolicyRequest**](XiqCreateNetworkPolicyRequest.md)| The body of create network policy API | 

### Return type

[**XiqNetworkPolicy**](XiqNetworkPolicy.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkPolicy

> DeleteNetworkPolicy(ctx, id)

Delete the network policy

Delete an existing network policy by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The network policy ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSsidsFromNetworkPolicy

> DeleteSsidsFromNetworkPolicy(ctx, id, requestBody)

Removes SSIDs from the network policy

Removing multiple SSIDs from the network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The network policy ID | 
**requestBody** | [**[]int64**](int64.md)| The SSID ids to be removed from the network policy | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkPolicy

> XiqNetworkPolicy GetNetworkPolicy(ctx, id)

Get the network policy

Get an existing network policy by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The network policy ID | 

### Return type

[**XiqNetworkPolicy**](XiqNetworkPolicy.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkPolices

> PagedXiqNetworkPolicy ListNetworkPolices(ctx, optional)

List network policies

List a page of network policies.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListNetworkPolicesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListNetworkPolicesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqNetworkPolicy**](PagedXiqNetworkPolicy.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSsidsByNetworkPolicy

> PagedXiqSsid ListSsidsByNetworkPolicy(ctx, id, optional)

List SSIDs for a network policy

List a page of SSIDs for a specific network policy.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The network policy ID | 
 **optional** | ***ListSsidsByNetworkPolicyOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListSsidsByNetworkPolicyOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqSsid**](PagedXiqSsid.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkPolicy

> XiqNetworkPolicy UpdateNetworkPolicy(ctx, id, xiqUpdateNetworkPolicyRequest)

Update the network policy

Update network policy by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The network policy ID | 
**xiqUpdateNetworkPolicyRequest** | [**XiqUpdateNetworkPolicyRequest**](XiqUpdateNetworkPolicyRequest.md)| The body of update network policy API | 

### Return type

[**XiqNetworkPolicy**](XiqNetworkPolicy.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

