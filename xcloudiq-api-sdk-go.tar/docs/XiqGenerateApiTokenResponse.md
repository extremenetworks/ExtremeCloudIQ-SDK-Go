# XiqGenerateApiTokenResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessToken** | **string** | The API access token | 
**CreateTime** | [**time.Time**](time.Time.md) | The create timestamp | 
**ExpireTime** | [**time.Time**](time.Time.md) | The expire timestamp, if null means no expiration | [optional] 
**CreatorId** | **int64** | The user ID who created the API token | 
**CustomerId** | **int64** | The customer ID who owns the API token | 
**Description** | **string** | The description for the API token | [optional] 
**Permissions** | **[]string** | The permissions for the API token | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


