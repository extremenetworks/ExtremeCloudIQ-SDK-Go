# \EssentialsExtremeLocationApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetClientLastLocation**](EssentialsExtremeLocationApi.md#GetClientLastLocation) | **Get** /essentials/eloc/clients/{clientMac}/last-known-location | Get the last known location of the client



## GetClientLastLocation

> EssentialsElocLastKnownLocation GetClientLastLocation(ctx, clientMac, floorId, parentId)

Get the last known location of the client

Get the last known location of the client on the floor plan.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**clientMac** | **string**| The mac address of client | 
**floorId** | **int64**| Location Id of the floor | 
**parentId** | **int64**| Location Id of the floor&#39;s parent | 

### Return type

[**EssentialsElocLastKnownLocation**](EssentialsElocLastKnownLocation.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

