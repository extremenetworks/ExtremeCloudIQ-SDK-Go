# XiqLdapServer

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**Name** | **string** | The LDAP server name | 
**Description** | **string** | The LDAP server description | [optional] 
**EnableTls** | **bool** | The LDAP server is enabled TLS or not | [optional] 
**BindDn** | **string** | The LDAP server bind DN name | [optional] 
**BindDnPassword** | **string** | The LDAP server bind DN password | [optional] 
**BaseDn** | **string** | The RADIUS user base DN | [optional] 
**L3AddressProfileId** | **int64** | The L3 address profile ID | [optional] 
**ProtocolType** | [**XiqLdapProtocolType**](XiqLdapProtocolType.md) |  | [optional] 
**EnableStripRealmName** | **bool** | Enable strip realm name or not | [optional] 
**DestinationPort** | **int32** | The LDAP server destination port | [optional] 
**VerificationMode** | [**XiqLdapServerVerificationMode**](XiqLdapServerVerificationMode.md) |  | [optional] 
**CaCertificateId** | **int64** | The CA certificate ID | [optional] 
**ClientCertificateId** | **int64** | The client certificate ID | [optional] 
**ClientKeyId** | **int64** | The client key ID | [optional] 
**ClientKeyPassword** | **string** | The LDAP server client key password | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


