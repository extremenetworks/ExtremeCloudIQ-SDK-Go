# XiqUserGroup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**Name** | **string** | The user group name | 
**Description** | **string** | The user group description | [optional] 
**Predefined** | **bool** | Whether it is predefined | 
**PasswordDbLocation** | [**XiqPasswordDbLocation**](XiqPasswordDbLocation.md) |  | 
**PasswordType** | [**XiqPasswordType**](XiqPasswordType.md) |  | 
**PcgUseOnly** | **bool** |  Whether it&#39;s for PCG use only | [optional] 
**PcgType** | [**XiqPcgType**](XiqPcgType.md) |  | [optional] 
**PpskUseOnly** | **bool** | Whether it&#39;s for PPSK use only | [optional] 
**EnableCwpReg** | **bool** | Whether to enable CWP registration setting | [optional] 
**PasswordSettings** | [**XiqPasswordSettings**](XiqPasswordSettings.md) |  | 
**ExpirationSettings** | [**XiqExpirationSettings**](XiqExpirationSettings.md) |  | 
**DeliverySettings** | [**XiqDeliverySettings**](XiqDeliverySettings.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


