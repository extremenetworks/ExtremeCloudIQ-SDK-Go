# XiqChangeDevicesIbeaconRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeviceIds** | **[]int64** | The list of device IDs.  Consult ExtremeNetworks documentation for the complete list of devices that support the beacon transmitter.  The following are some of the AP devices with the embedded beacon: AP122, AP122X, AP150W, AP245X, AP250, and AP550. | 
**Enabled** | **bool** | Whether to enable the device beacon.  Default to true for newly enabled device. | [optional] 
**Major** | **int32** | Identification of a subset of beacons in a geographical venue. Default to 1 for newly enabled device. | [optional] 
**Minor** | **int32** | Identification of a beacon in a specific location. Default to 1 for newly enabled device. | [optional] 
**Power** | **int32** | The transmission power in dBm. Default to -59 for newly enabled device. | [optional] 
**EnableMonitoring** | **bool** | Whether to enable iBeacon monitoring. Default to true for newly enabled device. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


