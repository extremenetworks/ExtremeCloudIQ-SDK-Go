# XiqLocationTreeMap

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MapName** | **string** | The background map name. | 
**Width** | **float64** | The x-dimension of the map in pixels. | [optional] 
**Height** | **float64** | The y-dimension of the map in pixels. | [optional] 
**Data** | **string** | The base-64 encoded string of the map. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


