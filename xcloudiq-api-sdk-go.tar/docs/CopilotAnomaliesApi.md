# \CopilotAnomaliesApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetDevicesByLocation**](CopilotAnomaliesApi.md#GetDevicesByLocation) | **Get** /copilot/anomalies/devices-by-location | 
[**GetDfsRecurrenceChannelStats**](CopilotAnomaliesApi.md#GetDfsRecurrenceChannelStats) | **Get** /copilot/anomalies/dfs-recurrence/channel-stats | 
[**GetDfsRecurrenceCountStats**](CopilotAnomaliesApi.md#GetDfsRecurrenceCountStats) | **Get** /copilot/anomalies/dfs-recurrence/count-stats | 
[**GetPoeFlappingStats**](CopilotAnomaliesApi.md#GetPoeFlappingStats) | **Get** /copilot/anomalies/poeflapping/stats | 
[**ListAnomalyLocations**](CopilotAnomaliesApi.md#ListAnomalyLocations) | **Get** /copilot/anomalies/locations | 



## GetDevicesByLocation

> XiqAnomalyDevicesByLocationResponse GetDevicesByLocation(ctx, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***GetDevicesByLocationOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetDevicesByLocationOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **anomalyType** | [**optional.Interface of XiqAnomalyType**](.md)| Anomaly type | 
 **locationId** | **optional.Int64**| The location id | [default to 0]

### Return type

[**XiqAnomalyDevicesByLocationResponse**](XiqAnomalyDevicesByLocationResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDfsRecurrenceChannelStats

> XiqDfsRecurenceChannelStatsResponse GetDfsRecurrenceChannelStats(ctx, anomalyId, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**anomalyId** | **string**| The anomaly id | 
 **optional** | ***GetDfsRecurrenceChannelStatsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetDfsRecurrenceChannelStatsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **locationId** | **optional.Int64**| The location id | [default to 0]

### Return type

[**XiqDfsRecurenceChannelStatsResponse**](XiqDfsRecurenceChannelStatsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDfsRecurrenceCountStats

> XiqDfsRecurenceCountStatsResponse GetDfsRecurrenceCountStats(ctx, anomalyId, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**anomalyId** | **string**| The anomaly id | 
 **optional** | ***GetDfsRecurrenceCountStatsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetDfsRecurrenceCountStatsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **locationId** | **optional.Int64**| The location id | [default to 0]

### Return type

[**XiqDfsRecurenceCountStatsResponse**](XiqDfsRecurenceCountStatsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPoeFlappingStats

> XiqPoeFlappingStatsResponse GetPoeFlappingStats(ctx, anomalyId, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**anomalyId** | **string**| The anomaly id | 
 **optional** | ***GetPoeFlappingStatsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetPoeFlappingStatsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **locationId** | **optional.Int64**| The location id | [default to 0]

### Return type

[**XiqPoeFlappingStatsResponse**](XiqPoeFlappingStatsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAnomalyLocations

> XiqCopilotPagedXiqAnomalyLocationEntity ListAnomalyLocations(ctx, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListAnomalyLocationsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListAnomalyLocationsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **anomalyType** | [**optional.Interface of XiqAnomalyType**](.md)| Anomaly type | 
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Number of Records, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **sortField** | [**optional.Interface of XiqAnomalySortField**](.md)| sort by field | 
 **sortOrder** | [**optional.Interface of XiqSortOrder**](.md)| The sorting order | 
 **excludeMuted** | **optional.Bool**| exclude muted | [default to false]

### Return type

[**XiqCopilotPagedXiqAnomalyLocationEntity**](XiqCopilotPagedXiqAnomalyLocationEntity.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

