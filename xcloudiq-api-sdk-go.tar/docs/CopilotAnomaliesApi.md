# \CopilotAnomaliesApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAnomaliesNotifications**](CopilotAnomaliesApi.md#GetAnomaliesNotifications) | **Get** /copilot/anomalies/notifications | 
[**GetAssuranceScansOverviewData**](CopilotAnomaliesApi.md#GetAssuranceScansOverviewData) | **Get** /copilot/assurance-scans/overview | 
[**GetAtpDeviceStats**](CopilotAnomaliesApi.md#GetAtpDeviceStats) | **Get** /copilot/anomalies/adverse-traffic/device-stats | 
[**GetAtpPacketCounts**](CopilotAnomaliesApi.md#GetAtpPacketCounts) | **Get** /copilot/anomalies/adverse-traffic/packet-counts | 
[**GetDevicesByLocation**](CopilotAnomaliesApi.md#GetDevicesByLocation) | **Get** /copilot/anomalies/devices-by-location | 
[**GetDfsRecurrenceChannelStats**](CopilotAnomaliesApi.md#GetDfsRecurrenceChannelStats) | **Get** /copilot/anomalies/dfs-recurrence/channel-stats | 
[**GetDfsRecurrenceCountStats**](CopilotAnomaliesApi.md#GetDfsRecurrenceCountStats) | **Get** /copilot/anomalies/dfs-recurrence/count-stats | 
[**GetPoeFlappingStats**](CopilotAnomaliesApi.md#GetPoeFlappingStats) | **Get** /copilot/anomalies/poeflapping/stats | 
[**GetPortEfficiencySpeedDuplexStats**](CopilotAnomaliesApi.md#GetPortEfficiencySpeedDuplexStats) | **Get** /copilot/anomalies/port-efficiency/speed-duplex-stats | 
[**GetPortEfficiencyStats**](CopilotAnomaliesApi.md#GetPortEfficiencyStats) | **Get** /copilot/anomalies/port-efficiency/stats | 
[**GetWifiCapacityClientList**](CopilotAnomaliesApi.md#GetWifiCapacityClientList) | **Get** /copilot/anomalies/wifi-capacity/client-list | 
[**GetWifiCapacityStats**](CopilotAnomaliesApi.md#GetWifiCapacityStats) | **Get** /copilot/anomalies/wifi-capacity/stats | 
[**GetWifiEfficiencyClientList**](CopilotAnomaliesApi.md#GetWifiEfficiencyClientList) | **Get** /copilot/anomalies/wifi-efficiency/client-list | 
[**GetWifiEfficiencyStats**](CopilotAnomaliesApi.md#GetWifiEfficiencyStats) | **Get** /copilot/anomalies/wifi-efficiency/stats | 
[**ListAnomalyLocations**](CopilotAnomaliesApi.md#ListAnomalyLocations) | **Get** /copilot/anomalies/locations | 
[**UpdateAnomaliesFeedback**](CopilotAnomaliesApi.md#UpdateAnomaliesFeedback) | **Put** /copilot/anomalies/devices/feedback | 
[**UpdateAnomalyAction**](CopilotAnomaliesApi.md#UpdateAnomalyAction) | **Put** /copilot/anomalies/update-action | 
[**UpdateAnomalyDeviceAction**](CopilotAnomaliesApi.md#UpdateAnomalyDeviceAction) | **Put** /copilot/anomalies/devices/update-action | 



## GetAnomaliesNotifications

> XiqAnomaliesNotificationsResponse GetAnomaliesNotifications(ctx, )



### Required Parameters

This endpoint does not need any parameter.

### Return type

[**XiqAnomaliesNotificationsResponse**](XiqAnomaliesNotificationsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAssuranceScansOverviewData

> XiqAssuranceScansOverviewResponse GetAssuranceScansOverviewData(ctx, )



### Required Parameters

This endpoint does not need any parameter.

### Return type

[**XiqAssuranceScansOverviewResponse**](XiqAssuranceScansOverviewResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAtpDeviceStats

> XiqAtpDeviceStatsResponse GetAtpDeviceStats(ctx, anomalyId)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**anomalyId** | **string**| The anomaly id | 

### Return type

[**XiqAtpDeviceStatsResponse**](XiqAtpDeviceStatsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAtpPacketCounts

> XiqAtpPacketCountsResponse GetAtpPacketCounts(ctx, anomalyId)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**anomalyId** | **string**| The anomaly id | 

### Return type

[**XiqAtpPacketCountsResponse**](XiqAtpPacketCountsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDevicesByLocation

> XiqAnomalyDevicesByLocationResponse GetDevicesByLocation(ctx, locationIds, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**locationIds** | [**[]int64**](int64.md)| The location IDs | 
 **optional** | ***GetDevicesByLocationOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetDevicesByLocationOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **anomalyType** | [**optional.Interface of XiqAnomalyType**](.md)| Anomaly type | 

### Return type

[**XiqAnomalyDevicesByLocationResponse**](XiqAnomalyDevicesByLocationResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDfsRecurrenceChannelStats

> XiqDfsRecurenceChannelStatsResponse GetDfsRecurrenceChannelStats(ctx, anomalyId)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**anomalyId** | **string**| The anomaly id | 

### Return type

[**XiqDfsRecurenceChannelStatsResponse**](XiqDfsRecurenceChannelStatsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDfsRecurrenceCountStats

> XiqDfsRecurenceCountStatsResponse GetDfsRecurrenceCountStats(ctx, anomalyId)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**anomalyId** | **string**| The anomaly id | 

### Return type

[**XiqDfsRecurenceCountStatsResponse**](XiqDfsRecurenceCountStatsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPoeFlappingStats

> XiqPoeFlappingStatsResponse GetPoeFlappingStats(ctx, anomalyId)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**anomalyId** | **string**| The anomaly id | 

### Return type

[**XiqPoeFlappingStatsResponse**](XiqPoeFlappingStatsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPortEfficiencySpeedDuplexStats

> XiqPortEfficiencySpeedDuplexStatsResponse GetPortEfficiencySpeedDuplexStats(ctx, anomalyId)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**anomalyId** | **string**| The anomaly id | 

### Return type

[**XiqPortEfficiencySpeedDuplexStatsResponse**](XiqPortEfficiencySpeedDuplexStatsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPortEfficiencyStats

> XiqPortEfficiencyStatsResponse GetPortEfficiencyStats(ctx, anomalyId)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**anomalyId** | **string**| The anomaly id | 

### Return type

[**XiqPortEfficiencyStatsResponse**](XiqPortEfficiencyStatsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWifiCapacityClientList

> XiqWifiCapacityClientListResponse GetWifiCapacityClientList(ctx, deviceId, channel, timestamp)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**deviceId** | **int64**| The device id | 
**channel** | **int32**| The channel | 
**timestamp** | **int64**| The timestamp | 

### Return type

[**XiqWifiCapacityClientListResponse**](XiqWifiCapacityClientListResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWifiCapacityStats

> XiqWifiCapacityStatsResponse GetWifiCapacityStats(ctx, anomalyId)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**anomalyId** | **string**| The anomaly id | 

### Return type

[**XiqWifiCapacityStatsResponse**](XiqWifiCapacityStatsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWifiEfficiencyClientList

> XiqWifiEfficiencyClientListResponse GetWifiEfficiencyClientList(ctx, deviceId, channel, timestamp)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**deviceId** | **int64**| The device id | 
**channel** | **int32**| The channel number | 
**timestamp** | **int64**| The timestamp | 

### Return type

[**XiqWifiEfficiencyClientListResponse**](XiqWifiEfficiencyClientListResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWifiEfficiencyStats

> XiqWifiEfficiencyStatsResponse GetWifiEfficiencyStats(ctx, anomalyId)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**anomalyId** | **string**| The anomaly id | 

### Return type

[**XiqWifiEfficiencyStatsResponse**](XiqWifiEfficiencyStatsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAnomalyLocations

> XiqCopilotPagedXiqAnomalyLocationEntity ListAnomalyLocations(ctx, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListAnomalyLocationsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListAnomalyLocationsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **anomalyType** | [**optional.Interface of XiqAnomalyType**](.md)| Anomaly type | 
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Number of Records, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **sortField** | [**optional.Interface of XiqAnomalySortField**](.md)| sort by field | 
 **sortOrder** | [**optional.Interface of XiqSortOrder**](.md)| The sorting order | 
 **excludeMuted** | **optional.Bool**| exclude muted | [default to false]

### Return type

[**XiqCopilotPagedXiqAnomalyLocationEntity**](XiqCopilotPagedXiqAnomalyLocationEntity.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAnomaliesFeedback

> XiqCopilotAnomaliesActionResponse UpdateAnomaliesFeedback(ctx, xiqAnomaliesFeedbackRequest)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqAnomaliesFeedbackRequest** | [**XiqAnomaliesFeedbackRequest**](XiqAnomaliesFeedbackRequest.md)|  | 

### Return type

[**XiqCopilotAnomaliesActionResponse**](XiqCopilotAnomaliesActionResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAnomalyAction

> XiqCopilotAnomaliesActionResponse UpdateAnomalyAction(ctx, xiqAnomaliesUpdateActionRequest)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqAnomaliesUpdateActionRequest** | [**XiqAnomaliesUpdateActionRequest**](XiqAnomaliesUpdateActionRequest.md)|  | 

### Return type

[**XiqCopilotAnomaliesActionResponse**](XiqCopilotAnomaliesActionResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAnomalyDeviceAction

> XiqCopilotAnomaliesActionResponse UpdateAnomalyDeviceAction(ctx, xiqAnomaliesDeviceUpdateActionRequest)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqAnomaliesDeviceUpdateActionRequest** | [**XiqAnomaliesDeviceUpdateActionRequest**](XiqAnomaliesDeviceUpdateActionRequest.md)|  | 

### Return type

[**XiqCopilotAnomaliesActionResponse**](XiqCopilotAnomaliesActionResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

