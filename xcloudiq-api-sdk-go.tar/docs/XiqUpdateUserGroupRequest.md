# XiqUpdateUserGroupRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The user group name | 
**Description** | **string** | The user group description | [optional] 
**PasswordDbLocation** | [**XiqPasswordDbLocation**](XiqPasswordDbLocation.md) |  | 
**PpskUseOnly** | **bool** | Whether it&#39;s for PPSK use only | [optional] 
**PasswordType** | [**XiqPasswordType**](XiqPasswordType.md) |  | 
**EnableMaxClientsPerPpsk** | **bool** | The enablement for the maximum number of clients per private PSK | [optional] 
**MaxClientsPerPpsk** | **int32** | The maximum number of clients per private PSK | [optional] 
**PcgUseOnly** | **bool** | Whether it&#39;s for PCG use only | [optional] 
**PcgType** | [**XiqPcgType**](XiqPcgType.md) |  | [optional] 
**EnableCwpReg** | **bool** | Whether to enable CWP registration setting | [optional] 
**PasswordSettings** | [**XiqPasswordSettings**](XiqPasswordSettings.md) |  | 
**ExpirationSettings** | [**XiqExpirationSettings**](XiqExpirationSettings.md) |  | 
**DeliverySettings** | [**XiqDeliverySettings**](XiqDeliverySettings.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


