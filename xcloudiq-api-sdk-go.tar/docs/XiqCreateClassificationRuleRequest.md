# XiqCreateClassificationRuleRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The name of classification rule | 
**Description** | **string** | The description of classification rule | [optional] 
**Classifications** | [**[]XiqCreateClassificationRequest**](XiqCreateClassificationRequest.md) | The details of rule assignments | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


