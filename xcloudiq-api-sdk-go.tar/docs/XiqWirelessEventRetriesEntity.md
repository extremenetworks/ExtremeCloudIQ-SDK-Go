# XiqWirelessEventRetriesEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AvgRxRetry** | **float64** | the average duration of rxRetry | [optional] 
**MaxRxRetry** | **float64** | the maximum duration of rxRetry | [optional] 
**AvgTxRetry** | **float64** | the average duration of txRetry | [optional] 
**MaxTxRetry** | **float64** | the maximum duration of txRetry | [optional] 
**RxRetryThreshold** | **float64** | the threshold value of rxRetry | [optional] 
**TxRetryThreshold** | **float64** | the threshold value of txRetry | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


