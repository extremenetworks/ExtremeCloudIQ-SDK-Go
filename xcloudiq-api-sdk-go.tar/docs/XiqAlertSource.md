# XiqAlertSource

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SourceName** | **string** | The alert source name | [optional] 
**SourceType** | [**XiqAlertSourceType**](XiqAlertSourceType.md) |  | [optional] 
**SourceId** | **string** | The alert source ID | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


