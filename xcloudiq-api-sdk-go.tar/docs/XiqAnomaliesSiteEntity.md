# XiqAnomaliesSiteEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BuildingId** | **int64** | the location type | [optional] 
**LocationName** | **string** | the location type | [optional] 
**AnomaliesCountByLocation** | **int32** | the location type | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


