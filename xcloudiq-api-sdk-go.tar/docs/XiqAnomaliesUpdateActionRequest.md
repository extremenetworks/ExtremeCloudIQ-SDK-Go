# XiqAnomaliesUpdateActionRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AnomalyType** | [**XiqAnomalyType**](XiqAnomalyType.md) |  | [optional] 
**ActionType** | [**XiqActionType**](XiqActionType.md) |  | [optional] 
**BuildingId** | **int64** | The location id | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


