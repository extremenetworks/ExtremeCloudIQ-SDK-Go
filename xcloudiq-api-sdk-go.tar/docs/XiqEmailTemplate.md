# XiqEmailTemplate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**Name** | **string** | The email template name | 
**Description** | **string** | The email template description | [optional] 
**Predefined** | **bool** | Wheter or not it is a system prefined template | 
**Content** | **string** | The email template form. | [optional] 
**EnablePreview** | **bool** | The setting to enable preview | [optional] 
**LogoUrl** | **string** | The logo url | [optional] 
**IconUrl** | **string** | The icon url | [optional] 
**PasswordType** | [**XiqPasswordType**](XiqPasswordType.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


