# XiqAnomaliesCountVoEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **int64** | The timestamp | 
**TotalAnomaliesCount** | **int64** | The total anomalies count | [optional] 
**WifiEfficiencyCount** | **int64** | The wifi efficiency count | [optional] 
**WifiCapacityCount** | **int64** | The wifi capacity count | [optional] 
**PoeCount** | **int64** | The poe flapping count | [optional] 
**PeCount** | **int64** | The port efficiency count | [optional] 
**DfsCount** | **int64** | The dfs recurrece count | [optional] 
**MbCastCount** | **int64** | The multibroadcast count | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


