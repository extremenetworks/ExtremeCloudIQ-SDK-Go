# XiqAnomaliesNotificationsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TotalAnomalyCount** | **int64** | The total anomaly count | [optional] 
**LocationEntity** | [**[]XiqAnomalyLocationEntity**](XiqAnomalyLocationEntity.md) | the anomaly location | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


