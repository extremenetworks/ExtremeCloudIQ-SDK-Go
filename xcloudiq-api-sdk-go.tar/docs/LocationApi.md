# \LocationApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateBuilding**](LocationApi.md#CreateBuilding) | **Post** /locations/building | Create building
[**CreateFloor**](LocationApi.md#CreateFloor) | **Post** /locations/floor | Create floor
[**CreateLocation**](LocationApi.md#CreateLocation) | **Post** /locations | Create location
[**DeleteBuilding**](LocationApi.md#DeleteBuilding) | **Delete** /locations/building/{id} | Delete building by ID
[**DeleteFloor**](LocationApi.md#DeleteFloor) | **Delete** /locations/floor/{id} | Delete floor by ID
[**DeleteLocation**](LocationApi.md#DeleteLocation) | **Delete** /locations/{id} | Delete location by ID
[**GetLocationTree**](LocationApi.md#GetLocationTree) | **Get** /locations/tree | Get location tree
[**UpdateBuilding**](LocationApi.md#UpdateBuilding) | **Put** /locations/building/{id} | Update building
[**UpdateFloor**](LocationApi.md#UpdateFloor) | **Put** /locations/floor/{id} | Update floor
[**UpdateLocation**](LocationApi.md#UpdateLocation) | **Put** /locations/{id} | Update location
[**UploadFloorplan**](LocationApi.md#UploadFloorplan) | **Post** /locations/floorplan | Upload floorplan



## CreateBuilding

> XiqBuilding CreateBuilding(ctx, xiqCreateBuildingRequest)

Create building

Create a new building under the parent location.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateBuildingRequest** | [**XiqCreateBuildingRequest**](XiqCreateBuildingRequest.md)| Create building request body | 

### Return type

[**XiqBuilding**](XiqBuilding.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateFloor

> XiqFloor CreateFloor(ctx, xiqCreateFloorRequest)

Create floor

Create a new floor under the parent building.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateFloorRequest** | [**XiqCreateFloorRequest**](XiqCreateFloorRequest.md)| Create floor request body | 

### Return type

[**XiqFloor**](XiqFloor.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateLocation

> XiqLocation CreateLocation(ctx, xiqCreateLocationRequest)

Create location

Create a new location under the parent location.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateLocationRequest** | [**XiqCreateLocationRequest**](XiqCreateLocationRequest.md)| Create location request body | 

### Return type

[**XiqLocation**](XiqLocation.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteBuilding

> DeleteBuilding(ctx, id, optional)

Delete building by ID

Delete the building for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The building ID | 
 **optional** | ***DeleteBuildingOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a DeleteBuildingOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **forceDelete** | **optional.Bool**| Force deletion of this building and its descendants recursively | [default to false]

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteFloor

> DeleteFloor(ctx, id)

Delete floor by ID

Delete the floor for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The floor ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteLocation

> string DeleteLocation(ctx, id, optional)

Delete location by ID

Delete the location for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The location ID | 
 **optional** | ***DeleteLocationOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a DeleteLocationOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **forceDelete** | **optional.Bool**| Force deletion of this location and its descendants recursively | [default to false]

### Return type

**string**

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetLocationTree

> []XiqLocation GetLocationTree(ctx, optional)

Get location tree

Get location hierarchical tree.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***GetLocationTreeOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetLocationTreeOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **parentId** | **optional.Int64**| The parent location ID, return root locations if parent is null | 
 **expandChildren** | **optional.Bool**| Whether to return the child locations recursively, default is true. Set it to false to improve performance when there are a lot of child locations. | [default to true]

### Return type

[**[]XiqLocation**](XiqLocation.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateBuilding

> XiqBuilding UpdateBuilding(ctx, id, xiqUpdateBuildingRequest)

Update building

Update the building information with the building ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The building ID | 
**xiqUpdateBuildingRequest** | [**XiqUpdateBuildingRequest**](XiqUpdateBuildingRequest.md)| Update building request body | 

### Return type

[**XiqBuilding**](XiqBuilding.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFloor

> XiqFloor UpdateFloor(ctx, id, xiqUpdateFloorRequest)

Update floor

Update floor information with the floor ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The floor ID. | 
**xiqUpdateFloorRequest** | [**XiqUpdateFloorRequest**](XiqUpdateFloorRequest.md)| Update floor request body | 

### Return type

[**XiqFloor**](XiqFloor.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateLocation

> XiqLocation UpdateLocation(ctx, id, xiqUpdateLocationRequest)

Update location

Update the location information with the specified location ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The location ID | 
**xiqUpdateLocationRequest** | [**XiqUpdateLocationRequest**](XiqUpdateLocationRequest.md)| Update location request body | 

### Return type

[**XiqLocation**](XiqLocation.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadFloorplan

> UploadFloorplan(ctx, file)

Upload floorplan

Upload the floorplan map for the VIQ.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**file** | ***os.File*****os.File**| The floorplan image file to upload.   For better performance, Extreme Networks recommends that the image file (.png .jpeg) be less than 500 KB. | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: multipart/form-data
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

