# \LocationApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateBuilding**](LocationApi.md#CreateBuilding) | **Post** /locations/building | Create building
[**CreateFloor**](LocationApi.md#CreateFloor) | **Post** /locations/floor | Create floor
[**CreateLocation**](LocationApi.md#CreateLocation) | **Post** /locations | Create location
[**CreateSite**](LocationApi.md#CreateSite) | **Post** /locations/site | Create site
[**DeleteBuilding**](LocationApi.md#DeleteBuilding) | **Delete** /locations/building/{id} | Delete building by ID
[**DeleteFloor**](LocationApi.md#DeleteFloor) | **Delete** /locations/floor/{id} | Delete floor by ID
[**DeleteLocation**](LocationApi.md#DeleteLocation) | **Delete** /locations/{id} | Delete location by ID
[**DeleteSite**](LocationApi.md#DeleteSite) | **Delete** /locations/site/{id} | Delete site by ID
[**GetLocationDevicesList**](LocationApi.md#GetLocationDevicesList) | **Get** /locations/tree/devices | Get devices on the location hierarchy.
[**GetLocationMapsList**](LocationApi.md#GetLocationMapsList) | **Get** /locations/tree/maps | Get maps on the location hierarchy.
[**GetLocationTree**](LocationApi.md#GetLocationTree) | **Get** /locations/tree | Get location tree
[**InitializeLocation**](LocationApi.md#InitializeLocation) | **Post** /locations/:init | Initialize organization location
[**ListBuildings**](LocationApi.md#ListBuildings) | **Get** /locations/building | List the buildings
[**ListFloors**](LocationApi.md#ListFloors) | **Get** /locations/floor | List the floors
[**ListSites**](LocationApi.md#ListSites) | **Get** /locations/site | List the sites
[**UpdateBuilding**](LocationApi.md#UpdateBuilding) | **Put** /locations/building/{id} | Update building
[**UpdateFloor**](LocationApi.md#UpdateFloor) | **Put** /locations/floor/{id} | Update floor
[**UpdateLocation**](LocationApi.md#UpdateLocation) | **Put** /locations/{id} | Update location
[**UpdateSite**](LocationApi.md#UpdateSite) | **Put** /locations/site/{id} | Update site by ID
[**UploadFloorplan**](LocationApi.md#UploadFloorplan) | **Post** /locations/floorplan | Upload floorplan



## CreateBuilding

> XiqBuilding CreateBuilding(ctx, xiqCreateBuildingRequest)

Create building

Create a new building under the parent location.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateBuildingRequest** | [**XiqCreateBuildingRequest**](XiqCreateBuildingRequest.md)| Create building request body | 

### Return type

[**XiqBuilding**](XiqBuilding.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateFloor

> XiqFloor CreateFloor(ctx, xiqCreateFloorRequest)

Create floor

Create a new floor under the parent building.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateFloorRequest** | [**XiqCreateFloorRequest**](XiqCreateFloorRequest.md)| Create floor request body | 

### Return type

[**XiqFloor**](XiqFloor.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateLocation

> XiqLocation CreateLocation(ctx, xiqCreateLocationRequest)

Create location

Create a new location under the parent location.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateLocationRequest** | [**XiqCreateLocationRequest**](XiqCreateLocationRequest.md)| Create location request body | 

### Return type

[**XiqLocation**](XiqLocation.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSite

> XiqSite CreateSite(ctx, xiqCreateSiteRequest)

Create site

Create a new site under the Generic.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateSiteRequest** | [**XiqCreateSiteRequest**](XiqCreateSiteRequest.md)| Create site request body | 

### Return type

[**XiqSite**](XiqSite.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteBuilding

> DeleteBuilding(ctx, id, optional)

Delete building by ID

Delete the building for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The building ID | 
 **optional** | ***DeleteBuildingOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a DeleteBuildingOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **forceDelete** | **optional.Bool**| Force deletion of this building and its descendants recursively | [default to false]

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteFloor

> DeleteFloor(ctx, id)

Delete floor by ID

Delete the floor for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The floor ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteLocation

> string DeleteLocation(ctx, id, optional)

Delete location by ID

Delete the location for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The location ID | 
 **optional** | ***DeleteLocationOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a DeleteLocationOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **forceDelete** | **optional.Bool**| Force deletion of this location and its descendants recursively | [default to false]

### Return type

**string**

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSite

> string DeleteSite(ctx, id, optional)

Delete site by ID

Delete the site for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The site ID | 
 **optional** | ***DeleteSiteOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a DeleteSiteOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **forceDelete** | **optional.Bool**| Force deletion of this site and its descendants recursively | [default to false]

### Return type

**string**

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetLocationDevicesList

> PagedXiqLocationTreeDevice GetLocationDevicesList(ctx, optional)

Get devices on the location hierarchy.

Get devices on the location hierarchy with pagination.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***GetLocationDevicesListOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetLocationDevicesListOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **locationId** | **optional.Int64**| The location ID, or null for all locations. | 
 **expandChildren** | **optional.Bool**| Whether to return the child locations recursively, default is true. Set it to false to improve performance when there are a lot of child locations. | [default to true]

### Return type

[**PagedXiqLocationTreeDevice**](PagedXiqLocationTreeDevice.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetLocationMapsList

> PagedXiqLocationTreeMap GetLocationMapsList(ctx, optional)

Get maps on the location hierarchy.

Get maps on the location hierarchy with pagination.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***GetLocationMapsListOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetLocationMapsListOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **locationId** | **optional.Int64**| The location ID, or null for all locations. | 
 **expandChildren** | **optional.Bool**| Whether to return the child locations recursively, default is true. Set it to false to improve performance when there are a lot of child locations. | [default to true]

### Return type

[**PagedXiqLocationTreeMap**](PagedXiqLocationTreeMap.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetLocationTree

> []XiqLocation GetLocationTree(ctx, optional)

Get location tree

Get location hierarchical tree.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***GetLocationTreeOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetLocationTreeOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **parentId** | **optional.Int64**| The parent location ID, return root locations if parent is null | 
 **expandChildren** | **optional.Bool**| Whether to return the child locations recursively, default is true. Set it to false to improve performance when there are a lot of child locations. | [default to true]

### Return type

[**[]XiqLocation**](XiqLocation.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## InitializeLocation

> XiqLocation InitializeLocation(ctx, xiqInitializeLocationRequest)

Initialize organization location

Initialize the organization location hierarchy tree.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqInitializeLocationRequest** | [**XiqInitializeLocationRequest**](XiqInitializeLocationRequest.md)| Initialize organization location request body | 

### Return type

[**XiqLocation**](XiqLocation.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListBuildings

> PagedXiqBuilding ListBuildings(ctx, optional)

List the buildings

List a page of buildings by filter.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListBuildingsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListBuildingsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **name** | **optional.String**| Name to search the buildings. It&#39;s case insensitive. | 

### Return type

[**PagedXiqBuilding**](PagedXiqBuilding.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListFloors

> PagedXiqFloor ListFloors(ctx, optional)

List the floors

List a page of floors by filter.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListFloorsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListFloorsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **name** | **optional.String**| Name to search floors. It&#39;s case insensitive | 

### Return type

[**PagedXiqFloor**](PagedXiqFloor.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSites

> PagedXiqSite ListSites(ctx, optional)

List the sites

List a page of sites by filter.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListSitesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListSitesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **name** | **optional.String**| Name to search the sites. It&#39;s case insensitive | 

### Return type

[**PagedXiqSite**](PagedXiqSite.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateBuilding

> XiqBuilding UpdateBuilding(ctx, id, xiqUpdateBuildingRequest)

Update building

Update the building information with the building ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The building ID | 
**xiqUpdateBuildingRequest** | [**XiqUpdateBuildingRequest**](XiqUpdateBuildingRequest.md)| Update building request body | 

### Return type

[**XiqBuilding**](XiqBuilding.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFloor

> XiqFloor UpdateFloor(ctx, id, xiqUpdateFloorRequest)

Update floor

Update floor information with the floor ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The floor ID. | 
**xiqUpdateFloorRequest** | [**XiqUpdateFloorRequest**](XiqUpdateFloorRequest.md)| Update floor request body | 

### Return type

[**XiqFloor**](XiqFloor.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateLocation

> XiqLocation UpdateLocation(ctx, id, xiqUpdateLocationRequest)

Update location

Update the location information with the specified location ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The location ID | 
**xiqUpdateLocationRequest** | [**XiqUpdateLocationRequest**](XiqUpdateLocationRequest.md)| Update location request body | 

### Return type

[**XiqLocation**](XiqLocation.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSite

> XiqSite UpdateSite(ctx, id, xiqUpdateSiteRequest)

Update site by ID

Update the site for the specified ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The site ID | 
**xiqUpdateSiteRequest** | [**XiqUpdateSiteRequest**](XiqUpdateSiteRequest.md)| Update site request body | 

### Return type

[**XiqSite**](XiqSite.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadFloorplan

> UploadFloorplan(ctx, file)

Upload floorplan

Upload the floorplan map for the VIQ.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**file** | ***os.File*****os.File**| The floorplan image file to upload.   For better performance, Extreme Networks recommends that the image file (.png .jpeg) be less than 500 KB. | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: multipart/form-data
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

