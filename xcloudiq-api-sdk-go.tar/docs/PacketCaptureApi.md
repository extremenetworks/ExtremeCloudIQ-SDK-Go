# \PacketCaptureApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreatePacketCapture**](PacketCaptureApi.md#CreatePacketCapture) | **Post** /packetcaptures | Create a new packet capture session
[**DeletePacketCapture**](PacketCaptureApi.md#DeletePacketCapture) | **Delete** /packetcaptures/{id} | Delete a packet capture session
[**GetPacketCapture**](PacketCaptureApi.md#GetPacketCapture) | **Get** /packetcaptures/{id} | Get a packet capture session
[**GetPacketCaptureFile**](PacketCaptureApi.md#GetPacketCaptureFile) | **Get** /packetcaptures/files | Get an AP packet capture file
[**ListPacketCaptures**](PacketCaptureApi.md#ListPacketCaptures) | **Get** /packetcaptures | List packet capture sessions
[**StopPacketCapture**](PacketCaptureApi.md#StopPacketCapture) | **Post** /packetcaptures/{id}/:stop | Stop a packet capture session
[**UploadPacketCaptureFiles**](PacketCaptureApi.md#UploadPacketCaptureFiles) | **Post** /packetcaptures/{id}/:upload | Upload a packet capture session&#39;s capture files



## CreatePacketCapture

> XiqPacketCapture CreatePacketCapture(ctx, xiqPacketCapture)

Create a new packet capture session

Create and start a new packet capture session with requested capture location and filter criteria.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqPacketCapture** | [**XiqPacketCapture**](XiqPacketCapture.md)| The packet capture to start | 

### Return type

[**XiqPacketCapture**](XiqPacketCapture.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePacketCapture

> DeletePacketCapture(ctx, id)

Delete a packet capture session

Delete an existing packet capture session and capture files by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The packet capture ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPacketCapture

> XiqPacketCapture GetPacketCapture(ctx, id, optional)

Get a packet capture session

Get packet capture session by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The packet capture ID | 
 **optional** | ***GetPacketCaptureOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetPacketCaptureOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **fields** | [**optional.Interface of []XiqPacketCaptureField**](XiqPacketCaptureField.md)| The packet capture fields to return | 

### Return type

[**XiqPacketCapture**](XiqPacketCapture.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPacketCaptureFile

> []string GetPacketCaptureFile(ctx, cloudFileUrl)

Get an AP packet capture file

Get an AP packet capture file from XIQ cloud storage.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**cloudFileUrl** | **string**| The packet capture file path | 

### Return type

**[]string**

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json, application/octet-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPacketCaptures

> PagedXiqPacketCapture ListPacketCaptures(ctx, optional)

List packet capture sessions

List packet captures with filters and pagination.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListPacketCapturesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListPacketCapturesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchString** | **optional.String**| The string to be searched in capture session name, interface name and device host name | 
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 500 | [default to 10]
 **sortField** | [**optional.Interface of XiqPacketCaptureSortField**](.md)| Sort field. Available values - NAME, START_TIME and STATUS | 
 **order** | [**optional.Interface of XiqSortOrder**](.md)| Sort order (ascending by default) | 
 **fields** | [**optional.Interface of []XiqPacketCaptureField**](XiqPacketCaptureField.md)| The packet capture fields to return | 

### Return type

[**PagedXiqPacketCapture**](PagedXiqPacketCapture.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## StopPacketCapture

> StopPacketCapture(ctx, id, xiqCaptureStopRequest)

Stop a packet capture session

Stop an active packet capture session.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The packet capture ID | 
**xiqCaptureStopRequest** | [**XiqCaptureStopRequest**](XiqCaptureStopRequest.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UploadPacketCaptureFiles

> UploadPacketCaptureFiles(ctx, id)

Upload a packet capture session's capture files

Upload the capture files from a packet capture session, if files previously failed to be uploaded to XIQ cloud.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The packet capture ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

