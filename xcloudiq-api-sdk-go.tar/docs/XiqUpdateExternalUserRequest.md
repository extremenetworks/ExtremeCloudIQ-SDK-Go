# XiqUpdateExternalUserRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UserRole** | [**XiqUserRole**](XiqUserRole.md) |  | [optional] 
**OrgId** | **int64** | The HIQ organization ID if it is HIQ user, otherwise leave it as empty. | [optional] 
**EnableApiAccess** | **bool** | Whether to enable API access, false by default. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


