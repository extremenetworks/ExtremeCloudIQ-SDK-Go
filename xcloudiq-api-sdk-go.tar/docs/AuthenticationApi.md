# \AuthenticationApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**Login**](AuthenticationApi.md#Login) | **Post** /login | User login with username and password
[**Logout**](AuthenticationApi.md#Logout) | **Post** /logout | User logout, a.k.a. Revoke the current access token



## Login

> XiqLoginResponse Login(ctx, xiqLoginRequest)

User login with username and password

Get access token via username and password authentication. The client must present Bearer token to access the protected API endpoints.The Bearer token should be present in the \"Authorization\" request header field and use the \"Bearer\" HTTP authentication scheme to transmit the access token.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqLoginRequest** | [**XiqLoginRequest**](XiqLoginRequest.md)| Login request body | 

### Return type

[**XiqLoginResponse**](XiqLoginResponse.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## Logout

> Logout(ctx, )

User logout, a.k.a. Revoke the current access token

User logout, the current access token will be revoked and the following access with the same token will be immediately denied.

### Required Parameters

This endpoint does not need any parameter.

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

