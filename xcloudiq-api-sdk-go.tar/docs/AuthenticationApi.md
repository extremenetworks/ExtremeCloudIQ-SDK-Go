# \AuthenticationApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**Login**](AuthenticationApi.md#Login) | **Post** /login | User login with username and password



## Login

> XiqLoginResponse Login(ctx, xiqLoginRequest)

User login with username and password

Get access token via username and password authentication. The client must send this token in the Authorization header when making requests to protected resources:Authorization: Bearer <token>

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqLoginRequest** | [**XiqLoginRequest**](XiqLoginRequest.md)| Login request body | 

### Return type

[**XiqLoginResponse**](XiqLoginResponse.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

