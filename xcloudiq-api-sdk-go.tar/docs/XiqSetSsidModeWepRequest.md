# XiqSetSsidModeWepRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**KeyManagement** | [**XiqSsidWepKeyManagement**](XiqSsidWepKeyManagement.md) |  | 
**EncryptionMethod** | [**XiqSsidWepEncryptionMethod**](XiqSsidWepEncryptionMethod.md) |  | 
**AuthenticationMethod** | [**XiqSsidWepAuthenticationMethod**](XiqSsidWepAuthenticationMethod.md) |  | [optional] 
**DefaultKey** | [**XiqSsidWepDefaultKey**](XiqSsidWepDefaultKey.md) |  | [optional] 
**KeyType** | [**XiqSsidKeyType**](XiqSsidKeyType.md) |  | [optional] 
**KeyValue** | **string** | The first key value, must be 13 characters long for WEP104, and 5 characters long for WEP40, cannot be null if it is the default key | [optional] 
**KeyValue2** | **string** | The second key value, must be 13 characters long for WEP104, and 5 characters long for WEP40, cannot be null if it is the default key | [optional] 
**KeyValue3** | **string** | The third key value, must be 13 characters long for WEP104, and 5 characters long for WEP40, cannot be null if it is the default key | [optional] 
**KeyValue4** | **string** | The fourth key value, must be 13 characters long for WEP104, and 5 characters long for WEP40, cannot be null if it is the default key | [optional] 
**RadiusServerGroupId** | **int64** | The RADIUS server group ID if using WEP_8021x as the key management | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


