# XiqLoginResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessToken** | **string** | The access token with JWT format issued by ExtremeCloud IQ | 
**TokenType** | **string** | The type of token, only supports \&quot;Bearer\&quot; currently | 
**ExpiresIn** | **int32** | The lifetime in seconds of the access token | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


