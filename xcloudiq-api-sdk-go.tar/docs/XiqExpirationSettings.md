# XiqExpirationSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExpirationType** | [**XiqExpirationType**](XiqExpirationType.md) |  | [optional] 
**ValidDuringDates** | [**XiqValidDuringDateSettings**](XiqValidDuringDateSettings.md) |  | [optional] 
**ValidForTimePeriod** | [**XiqValidForTimePeriodSettings**](XiqValidForTimePeriodSettings.md) |  | [optional] 
**ValidDaily** | [**XiqValidDailySettings**](XiqValidDailySettings.md) |  | [optional] 
**ExpirationAction** | [**XiqExpirationActionType**](XiqExpirationActionType.md) |  | [optional] 
**PostExpirationAction** | [**XiqPostExpirationAction**](XiqPostExpirationAction.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


