# XiqRpNeighborhoodAnalysis

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**EnableBackgroundScan** | **bool** | Whether to enable background scanning of neighboring devices | [optional] 
**BackgroundScanInterval** | **int32** | The background scan interval from 1 up to 1440 minutes | [optional] 
**EnableSkipScanWhenClientsConnected** | **bool** | Whether to enable skipping of background scan when devices have client connections | [optional] 
**EnableSkipScanWhenClientsInPowerSaveMode** | **bool** | Whether to skipping of background scan when connected devices are in power save mode | [optional] 
**EnableSkipScanWhenProcessVoiceTraffic** | **bool** | Whether to enable skipping of background scan when devices have network traffic with voice priority | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


