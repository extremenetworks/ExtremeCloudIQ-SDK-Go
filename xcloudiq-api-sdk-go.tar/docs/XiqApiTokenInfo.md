# XiqApiTokenInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UserName** | **string** | The login username | 
**UserId** | **int64** | The login user ID | 
**Role** | **string** | The role of login user | 
**OwnerId** | **int64** | The home ownerId of login user | 
**DataCenter** | **string** | The home data center of login user | 
**Scopes** | **[]string** | The login user permissions | 
**IssuedAt** | [**time.Time**](time.Time.md) | The time at which the JWT was issued | 
**ExpirationTime** | [**time.Time**](time.Time.md) | The expiration time on or after which the JWT MUST NOT be accepted for processing | [optional] 
**ExpiresIn** | **int64** | The expires in seconds | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


