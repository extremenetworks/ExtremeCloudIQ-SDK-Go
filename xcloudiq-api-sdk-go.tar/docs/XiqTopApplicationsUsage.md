# XiqTopApplicationsUsage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The application ID | [optional] 
**Name** | **string** | The application name | [optional] 
**Clients** | **int64** | The associated unique client count | [optional] 
**Users** | **int64** | The associated unique user count | [optional] 
**Usage** | **int64** | The application usage | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


