# XiqValidDailySettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DailyStartHour** | **int32** | The 24-hour format start hour of the day | 
**DailyStartMinute** | **int32** | The minute of the hour | 
**DailyEndHour** | **int32** | The 24-hour format end hour of day the end | 
**DailyEndMinute** | **int32** | The minute of the hour | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


