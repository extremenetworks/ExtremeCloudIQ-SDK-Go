# XiqCreateRadiusProxyRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The RADIUS proxy name | 
**Description** | **string** | The RADIUS proxy description | [optional] 
**FormatType** | [**XiqRadiusProxyFormatType**](XiqRadiusProxyFormatType.md) |  | 
**RetryCount** | **int32** | The retry count of RADIUS proxy | 
**RetryDelay** | **int32** | The retry delay of RADIUS proxy | 
**DeadTime** | **int32** | The dead time of RADIUS proxy | 
**EnableInjectOperatorNameAttribute** | **bool** | The flag for enable inject operator name attribute | [optional] 
**Clients** | [**[]XiqCreateRadiusClient**](XiqCreateRadiusClient.md) | The RADIUS clients of RADIUS proxy | [optional] 
**Realms** | [**[]XiqCreateRadiusProxyRealm**](XiqCreateRadiusProxyRealm.md) | The RADIUS realms of RADIUS proxy, provide at least two default RADIUS realms with name &#39;DEFAULT&#39; and &#39;NULL&#39; | 
**DeviceIds** | **[]int64** | The device IDS to assign RADIUS proxy | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


