# XiqWifiEfficiencyClientListResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClientStatsEntities** | [**[]XiqClientStatsEntity**](XiqClientStatsEntity.md) | the anomaly devices data | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


