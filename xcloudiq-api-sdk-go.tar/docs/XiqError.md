# XiqError

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ErrorCode** | **string** | The error code | 
**ErrorId** | **string** | The error ID for internal troubleshooting | 
**ErrorMessage** | **string** | The error detail message | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


