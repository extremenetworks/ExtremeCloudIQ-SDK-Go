# XiqRadiusProxyRealm

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The RADIUS proxy realm ID | [optional] 
**Name** | **string** | The RADIUS proxy realm name | [optional] 
**EnableStripRealmName** | **bool** | The flag for enable strip realm name | [optional] 
**RadiusClientObjectId** | **int64** | The associate RADIUS client object ID | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


