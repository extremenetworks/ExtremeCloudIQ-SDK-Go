# XiqWirelessTimeToConnectEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **int64** | the timestamp | 
**QualityIndex** | **int32** | the quality index | [optional] 
**TotalClients** | **int32** | the total clients | [optional] 
**TimeToConnectScore** | **int32** | the time to connect score | [optional] 
**AboveAssocThreshold** | **int32** | the above assoc threshold | [optional] 
**AboveAuthThreshold** | **int32** | the above auth threshold | [optional] 
**AboveDhcpThreshold** | **int32** | the above dhcp threshold | [optional] 
**TimeToAssoc** | **int32** | the time to associate | [optional] 
**TimeToAuth** | **int32** | the time to authenticate | [optional] 
**TimeToDhcp** | **int32** | the time to dhcp | [optional] 
**PerformanceScore** | **int32** | the performance score | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


