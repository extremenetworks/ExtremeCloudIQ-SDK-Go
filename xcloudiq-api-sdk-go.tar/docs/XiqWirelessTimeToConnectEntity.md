# XiqWirelessTimeToConnectEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **int64** | The timestamp | 
**QualityIndex** | **int32** | The quality index | [optional] 
**TotalClients** | **int32** | The total clients | [optional] 
**TimeToConnectScore** | **int32** | The time to connect score | [optional] 
**AboveAssocThreshold** | **int32** | The above association threshold | [optional] 
**AboveAuthThreshold** | **int32** | The above authentication threshold | [optional] 
**AboveDhcpThreshold** | **int32** | The above dhcp threshold | [optional] 
**TimeToAssoc** | **int32** | The time to associate | [optional] 
**TimeToAuth** | **int32** | The time to authenticate | [optional] 
**TimeToDhcp** | **int32** | The time to dhcp | [optional] 
**PerformanceScore** | **int32** | The performance score | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


