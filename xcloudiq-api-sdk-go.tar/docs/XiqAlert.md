# XiqAlert

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | The unique identifier | 
**OwnerId** | **int64** | The owner ID | [optional] 
**Timestamp** | [**time.Time**](time.Time.md) | The alert create time | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**Type** | **string** | The alert type | [optional] 
**Summary** | **string** | A high-level, text summary message of the event. Will be used to construct an alert&#39;s description. | [optional] 
**Severity** | [**XiqAlertSeverity**](XiqAlertSeverity.md) |  | [optional] 
**Category** | [**XiqAlertCategory**](XiqAlertCategory.md) |  | [optional] 
**Source** | [**XiqAlertSource**](XiqAlertSource.md) |  | [optional] 
**Tags** | **map[string]string** | Additional information for the alert | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


