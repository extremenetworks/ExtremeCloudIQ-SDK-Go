# \HIQApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateOrganization**](HIQApi.md#CreateOrganization) | **Post** /hiq/organizations | Create a new organization
[**DeleteOrganization**](HIQApi.md#DeleteOrganization) | **Delete** /hiq/organizations/{id} | Delete an existing organization
[**GetCreatingOrgId**](HIQApi.md#GetCreatingOrgId) | **Get** /hiq/context/creating | Get organization for creating new data
[**GetHiqContext**](HIQApi.md#GetHiqContext) | **Get** /hiq/context | Get HIQ context
[**GetHiqStatus**](HIQApi.md#GetHiqStatus) | **Get** /hiq/status | Get HIQ status
[**GetReadingOrgIds**](HIQApi.md#GetReadingOrgIds) | **Get** /hiq/context/reading | Get organizations for reading data
[**ListOrganizations**](HIQApi.md#ListOrganizations) | **Get** /hiq/organizations | List all organizations
[**RenameOrganization**](HIQApi.md#RenameOrganization) | **Post** /hiq/organizations/{id}/:rename | Rename an existing organization
[**SetCreatingOrgId**](HIQApi.md#SetCreatingOrgId) | **Put** /hiq/context/creating | Set organization for creating new data
[**SetHiqContext**](HIQApi.md#SetHiqContext) | **Put** /hiq/context | Set HIQ context
[**SetReadingOrgIds**](HIQApi.md#SetReadingOrgIds) | **Put** /hiq/context/reading | Set organizations for reading data



## CreateOrganization

> XiqOrganization CreateOrganization(ctx, xiqCreateOrganizationRequest)

Create a new organization

Create a new organization in current HIQ (Available when HIQ is enabled).

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateOrganizationRequest** | [**XiqCreateOrganizationRequest**](XiqCreateOrganizationRequest.md)| Create new organization request body | 

### Return type

[**XiqOrganization**](XiqOrganization.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteOrganization

> DeleteOrganization(ctx, id)

Delete an existing organization

Delete an existing organization (Available when HIQ is enabled).

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| Organization ID to delete | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCreatingOrgId

> int64 GetCreatingOrgId(ctx, )

Get organization for creating new data

Get organization for creating new data (Only one organization is active for creating new data). Appliable when HIQ is enabled.

### Required Parameters

This endpoint does not need any parameter.

### Return type

**int64**

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHiqContext

> XiqHiqContext GetHiqContext(ctx, )

Get HIQ context

Get the current effective HIQ context for reading or creating data in organizations. Appliable when HIQ is enabled.

### Required Parameters

This endpoint does not need any parameter.

### Return type

[**XiqHiqContext**](XiqHiqContext.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHiqStatus

> XiqHiqStatus GetHiqStatus(ctx, )

Get HIQ status

Get Hierarchical ExtremeCloud IQ (HIQ) status.

### Required Parameters

This endpoint does not need any parameter.

### Return type

[**XiqHiqStatus**](XiqHiqStatus.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetReadingOrgIds

> []int64 GetReadingOrgIds(ctx, )

Get organizations for reading data

Get organizations for reading data (Empty list means reading data from all organizations in the HIQ). Appliable when HIQ is enabled.

### Required Parameters

This endpoint does not need any parameter.

### Return type

**[]int64**

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListOrganizations

> []XiqOrganization ListOrganizations(ctx, )

List all organizations

List all organizations in current HIQ (Available when HIQ is enabled).

### Required Parameters

This endpoint does not need any parameter.

### Return type

[**[]XiqOrganization**](XiqOrganization.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RenameOrganization

> RenameOrganization(ctx, id, body)

Rename an existing organization

Rename an existing organization (Available when HIQ is enabled).

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| Organization ID to rename | 
**body** | **string**| The new organization name | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetCreatingOrgId

> SetCreatingOrgId(ctx, body)

Set organization for creating new data

Set organization for creating new data (Only one organization is active for creating new data). Only HIQ Admin can performance this operation when HIQ is enabled.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**body** | **int64**| The organization ID used for creating new data | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetHiqContext

> SetHiqContext(ctx, xiqHiqContext)

Set HIQ context

Set the current effective HIQ context for reading or creating data in organizations. Only HIQ Admin can performance this operation when HIQ is enabled.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqHiqContext** | [**XiqHiqContext**](XiqHiqContext.md)| The new HIQ context | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetReadingOrgIds

> SetReadingOrgIds(ctx, requestBody)

Set organizations for reading data

Set organization for reading data (Empty list means reading data from all organizations in the HIQ). Only HIQ Admin can performance this operation.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**requestBody** | [**[]int64**](int64.md)| The organization IDs used for reading data | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

