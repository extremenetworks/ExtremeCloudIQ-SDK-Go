# XiqSendCliSyncResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeviceCliOutputs** | [**map[string][]XiqCliOutput**](array.md) | device ID -&gt; CLI outputs | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


