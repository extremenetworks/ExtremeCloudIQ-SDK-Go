# XiqAnomaliesTypeEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AnomalyType** | [**XiqAnomalyType**](XiqAnomalyType.md) |  | [optional] 
**AnomaliesCountByType** | **int32** | Anomalies count with low severity | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


