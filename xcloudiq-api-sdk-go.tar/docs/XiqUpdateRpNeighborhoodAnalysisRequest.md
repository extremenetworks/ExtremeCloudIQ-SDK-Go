# XiqUpdateRpNeighborhoodAnalysisRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnableBackgroundScan** | **bool** | Whether background scan of neighboring devices is enabled | [optional] 
**BackgroundScanInterval** | **int32** | The background scan interval in the range of 1 to 1440 minutes | [optional] 
**EnableSkipScanWhenClientsConnected** | **bool** | Whether to skip background scan when devices have client connections | [optional] 
**EnableSkipScanWhenClientsInPowerSaveMode** | **bool** | Whether to skip background scan when connected devices are in power save mode | [optional] 
**EnableSkipScanWhenProcessVoiceTraffic** | **bool** | Whether to skip background scan when devices have network traffic with voice priority | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


