# XiqOnboardKeyBasedPcgRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SsidName** | **string** |  | 
**Enabled** | **bool** | Enable the key based PCG | 
**UserIds** | **[]int64** | The request user IDs | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


