# \UserApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateUser**](UserApi.md#CreateUser) | **Post** /users | Create new user
[**DeleteUser**](UserApi.md#DeleteUser) | **Delete** /users/{id} | Delete user by ID
[**GetCurrentUser**](UserApi.md#GetCurrentUser) | **Get** /users/me | Get current user info
[**GetExternalUser**](UserApi.md#GetExternalUser) | **Get** /users/external/{id} | Get external access info
[**GetUser**](UserApi.md#GetUser) | **Get** /users/{id} | Get user info by ID
[**GrantExternalUser**](UserApi.md#GrantExternalUser) | **Post** /users/external | Grant external access
[**ListExternalUsers**](UserApi.md#ListExternalUsers) | **Get** /users/external | List external access users
[**ListUsers**](UserApi.md#ListUsers) | **Get** /users | List all users
[**RevokeExternalUser**](UserApi.md#RevokeExternalUser) | **Delete** /users/external/{id} | Revoke external access
[**UpdateExternalUser**](UserApi.md#UpdateExternalUser) | **Patch** /users/external/{id} | Update external access info
[**UpdateUser**](UserApi.md#UpdateUser) | **Patch** /users/{id} | Update user info



## CreateUser

> XiqUser CreateUser(ctx, xiqCreateUserRequest)

Create new user

Create a new user to access.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateUserRequest** | [**XiqCreateUserRequest**](XiqCreateUserRequest.md)| Create new user request body | 

### Return type

[**XiqUser**](XiqUser.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteUser

> DeleteUser(ctx, id)

Delete user by ID

Delete a specific user.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The user ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCurrentUser

> XiqUser GetCurrentUser(ctx, )

Get current user info

Get currently login user info.

### Required Parameters

This endpoint does not need any parameter.

### Return type

[**XiqUser**](XiqUser.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetExternalUser

> XiqExternalUser GetExternalUser(ctx, id)

Get external access info

Get external access info for a specific external user.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The external user ID | 

### Return type

[**XiqExternalUser**](XiqExternalUser.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUser

> XiqUser GetUser(ctx, id)

Get user info by ID

Get user info for a specific user.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The user ID | 

### Return type

[**XiqUser**](XiqUser.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GrantExternalUser

> XiqExternalUser GrantExternalUser(ctx, xiqGrantExternalUserRequest)

Grant external access

Grant external access to a specific user.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqGrantExternalUserRequest** | [**XiqGrantExternalUserRequest**](XiqGrantExternalUserRequest.md)| Grant external user request | 

### Return type

[**XiqExternalUser**](XiqExternalUser.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListExternalUsers

> PagedXiqExternalUser ListExternalUsers(ctx, optional)

List external access users

List a page of external access users.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListExternalUsersOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListExternalUsersOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqExternalUser**](PagedXiqExternalUser.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListUsers

> PagedXiqUser ListUsers(ctx, optional)

List all users

List users with pagination.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListUsersOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListUsersOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqUser**](PagedXiqUser.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RevokeExternalUser

> RevokeExternalUser(ctx, id)

Revoke external access

Revoke external acccess for a specific user.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The external user ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateExternalUser

> UpdateExternalUser(ctx, id, xiqUpdateExternalUserRequest)

Update external access info

Updates external access info for a specific user.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The external user ID | 
**xiqUpdateExternalUserRequest** | [**XiqUpdateExternalUserRequest**](XiqUpdateExternalUserRequest.md)| Update external user request | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateUser

> XiqUser UpdateUser(ctx, id, xiqUpdateUserRequest)

Update user info

Updates user info for a specific user.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The user ID | 
**xiqUpdateUserRequest** | [**XiqUpdateUserRequest**](XiqUpdateUserRequest.md)| Update user request body | 

### Return type

[**XiqUser**](XiqUser.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

