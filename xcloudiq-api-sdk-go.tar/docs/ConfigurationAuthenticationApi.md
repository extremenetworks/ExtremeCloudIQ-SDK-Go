# \ConfigurationAuthenticationApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateExternalRadiusServer**](ConfigurationAuthenticationApi.md#CreateExternalRadiusServer) | **Post** /radius-servers/external | Create external RADIUS server configuration
[**CreateInternalRadiusServer**](ConfigurationAuthenticationApi.md#CreateInternalRadiusServer) | **Post** /radius-servers/internal | Create internal RADIUS server configuration
[**CreateLdapServer**](ConfigurationAuthenticationApi.md#CreateLdapServer) | **Post** /ldap-servers | Create LDAP server
[**CreateRadiusClientObject**](ConfigurationAuthenticationApi.md#CreateRadiusClientObject) | **Post** /radius-client-objects | Create RADIUS client object configuration
[**CreateRadiusProxy**](ConfigurationAuthenticationApi.md#CreateRadiusProxy) | **Post** /radius-proxies | Create RADIUS proxy configuration
[**DeleteExternalRadiusServer**](ConfigurationAuthenticationApi.md#DeleteExternalRadiusServer) | **Delete** /radius-servers/external/{id} | Delete external RADIUS server configuration
[**DeleteInternalRadiusServer**](ConfigurationAuthenticationApi.md#DeleteInternalRadiusServer) | **Delete** /radius-servers/internal/{id} | Delete internal RADIUS server configuration
[**DeleteLdapServer**](ConfigurationAuthenticationApi.md#DeleteLdapServer) | **Delete** /ldap-servers/{id} | Delete a LDAP server
[**DeleteRadiusClientObject**](ConfigurationAuthenticationApi.md#DeleteRadiusClientObject) | **Delete** /radius-client-objects/{id} | Delete a RADIUS client object configuration
[**DeleteRadiusProxy**](ConfigurationAuthenticationApi.md#DeleteRadiusProxy) | **Delete** /radius-proxies/{id} | Delete the RADIUS proxy configuration
[**GetExternalRadiusServer**](ConfigurationAuthenticationApi.md#GetExternalRadiusServer) | **Get** /radius-servers/external/{id} | Get external RADIUS server by ID
[**GetInternalRadiusServer**](ConfigurationAuthenticationApi.md#GetInternalRadiusServer) | **Get** /radius-servers/internal/{id} | Get internal RADIUS server by ID
[**GetLdapServer**](ConfigurationAuthenticationApi.md#GetLdapServer) | **Get** /ldap-servers/{id} | Get LDAP server by ID
[**GetRadiusClientObject**](ConfigurationAuthenticationApi.md#GetRadiusClientObject) | **Get** /radius-client-objects/{id} | Get RADIUS client object by ID
[**GetRadiusProxy**](ConfigurationAuthenticationApi.md#GetRadiusProxy) | **Get** /radius-proxies/{id} | Get the RADIUS proxy configuration
[**ListActiveDirectoryServers**](ConfigurationAuthenticationApi.md#ListActiveDirectoryServers) | **Get** /ad-servers | List active directory servers
[**ListCaptiveWebPortals**](ConfigurationAuthenticationApi.md#ListCaptiveWebPortals) | **Get** /cwps | List captive web portals
[**ListExternalRadiusServers**](ConfigurationAuthenticationApi.md#ListExternalRadiusServers) | **Get** /radius-servers/external | List external RADIUS servers
[**ListInternalRadiusDevices**](ConfigurationAuthenticationApi.md#ListInternalRadiusDevices) | **Get** /radius-servers/internal/devices | List all internal RADIUS devices
[**ListInternalRadiusServers**](ConfigurationAuthenticationApi.md#ListInternalRadiusServers) | **Get** /radius-servers/internal | List all internal RADIUS servers
[**ListLdapServers**](ConfigurationAuthenticationApi.md#ListLdapServers) | **Get** /ldap-servers | List LDAP servers
[**ListRadiusClientObjects**](ConfigurationAuthenticationApi.md#ListRadiusClientObjects) | **Get** /radius-client-objects | List RADIUS client objects
[**ListRadiusProxies**](ConfigurationAuthenticationApi.md#ListRadiusProxies) | **Get** /radius-proxies | List RADIUS proxies
[**ListRadiusProxyDevices**](ConfigurationAuthenticationApi.md#ListRadiusProxyDevices) | **Get** /radius-proxies/devices | 
[**UpdateExternalRadiusServer**](ConfigurationAuthenticationApi.md#UpdateExternalRadiusServer) | **Put** /radius-servers/external/{id} | Update external RADIUS server configuration
[**UpdateInternalRadiusServer**](ConfigurationAuthenticationApi.md#UpdateInternalRadiusServer) | **Put** /radius-servers/internal/{id} | Update internal RADIUS server configuration
[**UpdateLdapServer**](ConfigurationAuthenticationApi.md#UpdateLdapServer) | **Put** /ldap-servers/{id} | Update LDAP server configuration
[**UpdateRadiusClientObject**](ConfigurationAuthenticationApi.md#UpdateRadiusClientObject) | **Put** /radius-client-objects/{id} | Update RADIUS client object configuration
[**UpdateRadiusProxy**](ConfigurationAuthenticationApi.md#UpdateRadiusProxy) | **Put** /radius-proxies/{id} | Update RADIUS proxy configuration



## CreateExternalRadiusServer

> XiqExternalRadiusServer CreateExternalRadiusServer(ctx, xiqCreateExternalRadiusServerRequest)

Create external RADIUS server configuration

Create a new external RADIUS server configuration.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateExternalRadiusServerRequest** | [**XiqCreateExternalRadiusServerRequest**](XiqCreateExternalRadiusServerRequest.md)| Use the payload configuration to create a new external RADIUS server | 

### Return type

[**XiqExternalRadiusServer**](XiqExternalRadiusServer.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateInternalRadiusServer

> XiqInternalRadiusServer CreateInternalRadiusServer(ctx, xiqCreateInternalRadiusServerRequest)

Create internal RADIUS server configuration

Create a new internal RADIUS server configuration.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateInternalRadiusServerRequest** | [**XiqCreateInternalRadiusServerRequest**](XiqCreateInternalRadiusServerRequest.md)| Use the payload configuration to create a new internal RADIUS server | 

### Return type

[**XiqInternalRadiusServer**](XiqInternalRadiusServer.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateLdapServer

> XiqLdapServer CreateLdapServer(ctx, xiqCreateLdapServerRequest)

Create LDAP server

Create a new LDAP server.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateLdapServerRequest** | [**XiqCreateLdapServerRequest**](XiqCreateLdapServerRequest.md)| The body of create LDAP server API | 

### Return type

[**XiqLdapServer**](XiqLdapServer.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateRadiusClientObject

> XiqRadiusClientObject CreateRadiusClientObject(ctx, xiqCreateRadiusClientObjectRequest)

Create RADIUS client object configuration

Create a new RADIUS client object configuration.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateRadiusClientObjectRequest** | [**XiqCreateRadiusClientObjectRequest**](XiqCreateRadiusClientObjectRequest.md)| Use the payload configuration to create a new RADIUS client object | 

### Return type

[**XiqRadiusClientObject**](XiqRadiusClientObject.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateRadiusProxy

> XiqRadiusProxy CreateRadiusProxy(ctx, xiqCreateRadiusProxyRequest)

Create RADIUS proxy configuration

Create a new RADIUS proxy configuration.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateRadiusProxyRequest** | [**XiqCreateRadiusProxyRequest**](XiqCreateRadiusProxyRequest.md)| The body of create RADIUS proxy API | 

### Return type

[**XiqRadiusProxy**](XiqRadiusProxy.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteExternalRadiusServer

> DeleteExternalRadiusServer(ctx, id)

Delete external RADIUS server configuration

Delete an existing external RADIUS server configuration by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The external RADIUS server ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteInternalRadiusServer

> DeleteInternalRadiusServer(ctx, id)

Delete internal RADIUS server configuration

Delete an existing internal RADIUS server configuration by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The internal RADIUS server ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteLdapServer

> DeleteLdapServer(ctx, id)

Delete a LDAP server

Delete a specific LDAP server by ID

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The LDAP server ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteRadiusClientObject

> DeleteRadiusClientObject(ctx, id)

Delete a RADIUS client object configuration

Delete an existing RADIUS client object configuration by ID

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The RADIUS client object ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteRadiusProxy

> DeleteRadiusProxy(ctx, id)

Delete the RADIUS proxy configuration

Delete an existing RADIUS proxy configuration by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The RADIUS proxy ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetExternalRadiusServer

> XiqExternalRadiusServer GetExternalRadiusServer(ctx, id)

Get external RADIUS server by ID

Get detailed configuration for a specific external RADIUS server

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The ID for external RADIUS server | 

### Return type

[**XiqExternalRadiusServer**](XiqExternalRadiusServer.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetInternalRadiusServer

> XiqInternalRadiusServer GetInternalRadiusServer(ctx, id)

Get internal RADIUS server by ID

Get detailed configuration for internal RADIUS server by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The ID for internal RADIUS server | 

### Return type

[**XiqInternalRadiusServer**](XiqInternalRadiusServer.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetLdapServer

> XiqLdapServer GetLdapServer(ctx, id)

Get LDAP server by ID

Get a specific LDAP server by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The LDAP server  | 

### Return type

[**XiqLdapServer**](XiqLdapServer.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRadiusClientObject

> XiqRadiusClientObject GetRadiusClientObject(ctx, id)

Get RADIUS client object by ID

Get detailed configuration for a specific RADIUS client object.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The ID of RADIUS client object | 

### Return type

[**XiqRadiusClientObject**](XiqRadiusClientObject.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetRadiusProxy

> XiqRadiusProxy GetRadiusProxy(ctx, id)

Get the RADIUS proxy configuration

Get an existing RADIUS proxy configuration by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The RADIUS proxy ID | 

### Return type

[**XiqRadiusProxy**](XiqRadiusProxy.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListActiveDirectoryServers

> PagedXiqActiveDirectoryServer ListActiveDirectoryServers(ctx, optional)

List active directory servers

List a page of active directory servers.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListActiveDirectoryServersOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListActiveDirectoryServersOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqActiveDirectoryServer**](PagedXiqActiveDirectoryServer.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCaptiveWebPortals

> PagedXiqCwp ListCaptiveWebPortals(ctx, optional)

List captive web portals

List a page of Captive Web Portals.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListCaptiveWebPortalsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListCaptiveWebPortalsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqCwp**](PagedXiqCwp.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListExternalRadiusServers

> PagedXiqExternalRadiusServer ListExternalRadiusServers(ctx, optional)

List external RADIUS servers

List a page of external RADIUS server configurations.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListExternalRadiusServersOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListExternalRadiusServersOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqExternalRadiusServer**](PagedXiqExternalRadiusServer.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListInternalRadiusDevices

> PagedXiqInternalRadiusDevice ListInternalRadiusDevices(ctx, optional)

List all internal RADIUS devices

List all internal RADIUS devices fields.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListInternalRadiusDevicesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListInternalRadiusDevicesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqInternalRadiusDevice**](PagedXiqInternalRadiusDevice.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListInternalRadiusServers

> PagedXiqInternalRadiusServer ListInternalRadiusServers(ctx, optional)

List all internal RADIUS servers

List all internal RADIUS servers configurations.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListInternalRadiusServersOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListInternalRadiusServersOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqInternalRadiusServer**](PagedXiqInternalRadiusServer.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListLdapServers

> PagedXiqLdapServer ListLdapServers(ctx, optional)

List LDAP servers

List a page of LDAP servers.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListLdapServersOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListLdapServersOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqLdapServer**](PagedXiqLdapServer.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListRadiusClientObjects

> PagedXiqRadiusClientObject ListRadiusClientObjects(ctx, optional)

List RADIUS client objects

List a page of RADIUS client object configurations.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListRadiusClientObjectsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListRadiusClientObjectsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqRadiusClientObject**](PagedXiqRadiusClientObject.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListRadiusProxies

> PagedXiqRadiusProxy ListRadiusProxies(ctx, optional)

List RADIUS proxies

List a page of RADIUS proxy configurations.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListRadiusProxiesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListRadiusProxiesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqRadiusProxy**](PagedXiqRadiusProxy.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListRadiusProxyDevices

> PagedXiqInternalRadiusDevice ListRadiusProxyDevices(ctx, optional)



### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListRadiusProxyDevicesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListRadiusProxyDevicesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqInternalRadiusDevice**](PagedXiqInternalRadiusDevice.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateExternalRadiusServer

> UpdateExternalRadiusServer(ctx, id, xiqUpdateExternalRadiusServerRequest)

Update external RADIUS server configuration

Update external RADIUS server configuration by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The external RADIUS server ID. | 
**xiqUpdateExternalRadiusServerRequest** | [**XiqUpdateExternalRadiusServerRequest**](XiqUpdateExternalRadiusServerRequest.md)| The payload to update the external RADIUS server | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateInternalRadiusServer

> XiqInternalRadiusServer UpdateInternalRadiusServer(ctx, id, xiqUpdateInternalRadiusServerRequest)

Update internal RADIUS server configuration

Update internal RADIUS server configuration by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The internal RADIUS server ID | 
**xiqUpdateInternalRadiusServerRequest** | [**XiqUpdateInternalRadiusServerRequest**](XiqUpdateInternalRadiusServerRequest.md)| The payload to update the internal RADIUS server | 

### Return type

[**XiqInternalRadiusServer**](XiqInternalRadiusServer.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateLdapServer

> XiqLdapServer UpdateLdapServer(ctx, id, xiqUpdateLdapServerRequest)

Update LDAP server configuration

Update configuration for a specific LDAP server.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The LDAP server ID. | 
**xiqUpdateLdapServerRequest** | [**XiqUpdateLdapServerRequest**](XiqUpdateLdapServerRequest.md)| The body of update LDAP server API | 

### Return type

[**XiqLdapServer**](XiqLdapServer.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateRadiusClientObject

> UpdateRadiusClientObject(ctx, id, xiqUpdateRadiusClientObjectRequest)

Update RADIUS client object configuration

Update RADIUS client object configuration by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The RADIUS client object ID. | 
**xiqUpdateRadiusClientObjectRequest** | [**XiqUpdateRadiusClientObjectRequest**](XiqUpdateRadiusClientObjectRequest.md)| The payload to update the RADIUS client object | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateRadiusProxy

> XiqRadiusProxy UpdateRadiusProxy(ctx, id, xiqUpdateRadiusProxyRequest)

Update RADIUS proxy configuration

Update RADIUS proxy configuration by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The RADIUS proxy ID | 
**xiqUpdateRadiusProxyRequest** | [**XiqUpdateRadiusProxyRequest**](XiqUpdateRadiusProxyRequest.md)| The body of update RADIUS proxy API | 

### Return type

[**XiqRadiusProxy**](XiqRadiusProxy.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

