# XiqUpdateUserRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LoginName** | **string** | Login name, i.e. username or login Email | [optional] 
**DisplayName** | **string** | The user name to display | [optional] 
**IdleTimeout** | **int32** | The idle timeout in minutes. | [optional] 
**UserRole** | [**XiqUserRole**](XiqUserRole.md) |  | [optional] 
**LocationIds** | **[]int64** | The location IDs to reassign. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


