# XiqDeviceStatsEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **int64** | The timestamp | 
**AvgInterferenceUtilization** | **int32** | The average interference utilization  | [optional] 
**AvgTxUtilization** | **int32** | The Average Tx Utilization | [optional] 
**AvgRxUtilization** | **int32** | The Average Rx Utilization | [optional] 
**AvgTotalChannelUtilization** | **int32** | The Average Total Channel Utilization  | [optional] 
**AvgNumClients** | **int32** | The Average Number of Clients | [optional] 
**NormalInterference** | **int32** | The normal interference  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


