# XiqDeviceLevelSsidStatus

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Wifi0Enabled** | **bool** | The SSID is enabled or not on wifi0 interface | 
**Wifi1Enabled** | **bool** | The SSID is enabled or not on wifi1 interface | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


