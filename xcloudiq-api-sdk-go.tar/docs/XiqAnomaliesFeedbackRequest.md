# XiqAnomaliesFeedbackRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AnomalyType** | [**XiqAnomalyType**](XiqAnomalyType.md) |  | [optional] 
**AnomalyId** | **string** | The anomaly Id | [optional] 
**FeedbackType** | [**XiqFeedbackType**](XiqFeedbackType.md) |  | [optional] 
**Feedback** | **string** | The feedback description | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


