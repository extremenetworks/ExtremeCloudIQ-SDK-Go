# XiqBounceDevicePortData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Status** | **int32** | The status value | [optional] 
**RequestId** | **int64** | The requestId of the response | [optional] 
**Results** | [**[]XiqBounceDevicePortOperationResult**](XiqBounceDevicePortOperationResult.md) | The list of results | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


