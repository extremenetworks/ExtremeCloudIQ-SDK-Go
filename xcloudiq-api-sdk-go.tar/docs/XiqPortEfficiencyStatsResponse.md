# XiqPortEfficiencyStatsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DuplexDataRateEntities** | [**[]XiqDuplexDataRateEntity**](XiqDuplexDataRateEntity.md) | the duplex data rate data | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


