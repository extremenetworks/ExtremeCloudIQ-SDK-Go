# \DeviceApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AdvancedOnboardDevices**](DeviceApi.md#AdvancedOnboardDevices) | **Post** /devices/:advanced-onboard | [LRO] Advanced Onboard Devices
[**AssignDeviceLocation**](DeviceApi.md#AssignDeviceLocation) | **Put** /devices/{id}/location | Assign location to a device
[**AssignDeviceNetworkPolicy**](DeviceApi.md#AssignDeviceNetworkPolicy) | **Put** /devices/{id}/network-policy | Assign network policy to a device
[**AssignDevicesCountryCode**](DeviceApi.md#AssignDevicesCountryCode) | **Post** /devices/country-code/:assign | Assign a country code to devices
[**AssignDevicesLocation**](DeviceApi.md#AssignDevicesLocation) | **Post** /devices/location/:assign | Assign location to multiple devices
[**AssignDevicesNetworkPolicy**](DeviceApi.md#AssignDevicesNetworkPolicy) | **Post** /devices/network-policy/:assign | Assign network policy to multiple devices
[**AssignDevicesRadiusProxy**](DeviceApi.md#AssignDevicesRadiusProxy) | **Put** /devices/radius-proxy/:assign | Assign RADIUS proxy to devices
[**BounceDevicePort**](DeviceApi.md#BounceDevicePort) | **Post** /devices/{id}/bounce-port | Bounce port of a device (EXOS, VOSS and SR Switches
[**ChangeDeviceDescription**](DeviceApi.md#ChangeDeviceDescription) | **Put** /devices/{id}/description | Change description for a device
[**ChangeDeviceLevelSsidStatus**](DeviceApi.md#ChangeDeviceLevelSsidStatus) | **Post** /devices/{id}/ssid/status/:change | Enable or disable SSID for a device
[**ChangeDeviceStatusToManage**](DeviceApi.md#ChangeDeviceStatusToManage) | **Post** /devices/{id}/:manage | Change admin state to &#39;Managed&#39; for a device
[**ChangeDeviceStatusToUnmanage**](DeviceApi.md#ChangeDeviceStatusToUnmanage) | **Post** /devices/{id}/:unmanage | Change admin state to &#39;Unmanaged&#39; for a device
[**ChangeDevicesIbeacon**](DeviceApi.md#ChangeDevicesIbeacon) | **Put** /devices/ibeacon | Change iBeacon settings for devices
[**ChangeDevicesOsMode**](DeviceApi.md#ChangeDevicesOsMode) | **Post** /devices/os/:change | Change device OS mode
[**ChangeHostname**](DeviceApi.md#ChangeHostname) | **Put** /devices/{id}/hostname | Change hostname for a device
[**ChangeStatusToManage**](DeviceApi.md#ChangeStatusToManage) | **Post** /devices/:manage | Change status to Managed
[**ChangeStatusToUnmanage**](DeviceApi.md#ChangeStatusToUnmanage) | **Post** /devices/:unmanage | Change status to Unmanaged
[**DeleteDevice**](DeviceApi.md#DeleteDevice) | **Delete** /devices/{id} | Delete a device
[**DeleteDevices**](DeviceApi.md#DeleteDevices) | **Post** /devices/:delete | Delete devices
[**GetDevice**](DeviceApi.md#GetDevice) | **Get** /devices/{id} | Get device info for a specific device
[**GetDeviceCpuMemoryHistory**](DeviceApi.md#GetDeviceCpuMemoryHistory) | **Get** /devices/{id}/history/cpu-mem | Get device CPU/memory usage history
[**GetDeviceIbeacon**](DeviceApi.md#GetDeviceIbeacon) | **Get** /devices/{id}/ibeacon | Get the device iBeacon setting
[**GetDeviceLevelSsidStatus**](DeviceApi.md#GetDeviceLevelSsidStatus) | **Get** /devices/{id}/ssid/status | Get SSID status for a device
[**GetDeviceLocation**](DeviceApi.md#GetDeviceLocation) | **Get** /devices/{id}/location | Get location for a device
[**GetDeviceNetworkPolicy**](DeviceApi.md#GetDeviceNetworkPolicy) | **Get** /devices/{id}/network-policy | Get network policy for a device
[**GetDeviceStats**](DeviceApi.md#GetDeviceStats) | **Get** /devices/stats | Get device stats
[**GetDeviceWifiInterface**](DeviceApi.md#GetDeviceWifiInterface) | **Get** /devices/{id}/interfaces/wifi | Get the device WiFi interfaces stats
[**GetXiqDeviceInstallationReport**](DeviceApi.md#GetXiqDeviceInstallationReport) | **Get** /devices/{id}/installation-report | Get device installation report
[**ListDeviceAlarm**](DeviceApi.md#ListDeviceAlarm) | **Get** /devices/{id}/alarms | List alarms for a device
[**ListDevices**](DeviceApi.md#ListDevices) | **Get** /devices | [LRO] List devices
[**ListDevicesByNetworkPolicy**](DeviceApi.md#ListDevicesByNetworkPolicy) | **Get** /devices/network-policy/{policyId} | List assigned devices for network policy
[**ListDigitalTwinProducts**](DeviceApi.md#ListDigitalTwinProducts) | **Get** /devices/digital-twin | List Digital Twin product information.
[**OnboardDevices**](DeviceApi.md#OnboardDevices) | **Post** /devices/:onboard | Onboard Devices
[**OverrideDeviceLevelSsid**](DeviceApi.md#OverrideDeviceLevelSsid) | **Post** /devices/{id}/ssid/:override | Override SSID for a device
[**QueryDevicesLocation**](DeviceApi.md#QueryDevicesLocation) | **Post** /devices/location/:query | Query location for multiple devices
[**QueryDevicesNetworkPolicy**](DeviceApi.md#QueryDevicesNetworkPolicy) | **Post** /devices/network-policy/:query | Query network policy for multiple devices
[**RebootDevice**](DeviceApi.md#RebootDevice) | **Post** /devices/{id}/:reboot | Reboot a device
[**RebootDevices**](DeviceApi.md#RebootDevices) | **Post** /devices/:reboot | Reboot devices
[**ResetDevice**](DeviceApi.md#ResetDevice) | **Post** /devices/{id}/:reset | [LRO] Reset a device to factory default
[**RevokeDeviceLocation**](DeviceApi.md#RevokeDeviceLocation) | **Delete** /devices/{id}/location | Revoke location for a device
[**RevokeDeviceNetworkPolicy**](DeviceApi.md#RevokeDeviceNetworkPolicy) | **Delete** /devices/{id}/network-policy | Revoke network policy for a device
[**RevokeDevicesLocation**](DeviceApi.md#RevokeDevicesLocation) | **Post** /devices/location/:revoke | Revoke location for multiple devices
[**RevokeDevicesNetworkPolicy**](DeviceApi.md#RevokeDevicesNetworkPolicy) | **Post** /devices/network-policy/:revoke | Revoke network policy for multiple devices
[**RevokeDevicesRadiusProxy**](DeviceApi.md#RevokeDevicesRadiusProxy) | **Delete** /devices/radius-proxy/:revoke | Revoke RADIUS proxy from multiple devices
[**SendCliToDevice**](DeviceApi.md#SendCliToDevice) | **Post** /devices/{id}/:cli | Send CLI to a device
[**SendCliToDevices**](DeviceApi.md#SendCliToDevices) | **Post** /devices/:cli | [LRO] Send CLI to devices



## AdvancedOnboardDevices

> XiqAdvancedOnboardDeviceResponse AdvancedOnboardDevices(ctx, xiqAdvancedOnboardDeviceRequest, optional)

[LRO] Advanced Onboard Devices

Advanced onboard devices for all devices, such as Extreme/Aerohive, EXOS, VOSS, WiNG, Dell, and Digital Twin. Advanced onboard devices will allow the user to set the device hostname, attach the device location, associate network policy, etc. in a single API request. To avoid API timeout when onboarding a large number of devices, please make sure to enable async mode (set async=true in query parameter) and use long-running operation API to query the result.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqAdvancedOnboardDeviceRequest** | [**XiqAdvancedOnboardDeviceRequest**](XiqAdvancedOnboardDeviceRequest.md)|  | 
 **optional** | ***AdvancedOnboardDevicesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a AdvancedOnboardDevicesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **async** | **optional.Bool**| Whether to enable async mode | [default to false]

### Return type

[**XiqAdvancedOnboardDeviceResponse**](XiqAdvancedOnboardDeviceResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AssignDeviceLocation

> AssignDeviceLocation(ctx, id, xiqDeviceLocationAssignment)

Assign location to a device

Assign a location to a specific device with extra map and geographical properties.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 
**xiqDeviceLocationAssignment** | [**XiqDeviceLocationAssignment**](XiqDeviceLocationAssignment.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AssignDeviceNetworkPolicy

> AssignDeviceNetworkPolicy(ctx, id, networkPolicyId)

Assign network policy to a device

Assign a network policy to a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 
**networkPolicyId** | **int64**| The network policy ID to assign | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AssignDevicesCountryCode

> AssignDevicesCountryCode(ctx, xiqAssignDevicesCountryCodeRequest)

Assign a country code to devices

Assign the country code to one or more devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqAssignDevicesCountryCodeRequest** | [**XiqAssignDevicesCountryCodeRequest**](XiqAssignDevicesCountryCodeRequest.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AssignDevicesLocation

> AssignDevicesLocation(ctx, xiqAssignDevicesLocationRequest)

Assign location to multiple devices

Assign the location to the target devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqAssignDevicesLocationRequest** | [**XiqAssignDevicesLocationRequest**](XiqAssignDevicesLocationRequest.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AssignDevicesNetworkPolicy

> AssignDevicesNetworkPolicy(ctx, xiqAssignDevicesNetworkPolicyRequest)

Assign network policy to multiple devices

Assign the network policy to the target devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqAssignDevicesNetworkPolicyRequest** | [**XiqAssignDevicesNetworkPolicyRequest**](XiqAssignDevicesNetworkPolicyRequest.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## AssignDevicesRadiusProxy

> AssignDevicesRadiusProxy(ctx, ids, radiusProxyId)

Assign RADIUS proxy to devices

Assign a RADIUS proxy to multiple devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**ids** | [**[]int64**](int64.md)| The device IDs | 
**radiusProxyId** | **int64**| The RADIUS proxy ID to assign | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## BounceDevicePort

> XiqBounceDevicePortResponse BounceDevicePort(ctx, id, xiqBounceDevicePortRequest)

Bounce port of a device (EXOS, VOSS and SR Switches

Bounce port for the given device id.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device id | 
**xiqBounceDevicePortRequest** | [**XiqBounceDevicePortRequest**](XiqBounceDevicePortRequest.md)|  | 

### Return type

[**XiqBounceDevicePortResponse**](XiqBounceDevicePortResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ChangeDeviceDescription

> ChangeDeviceDescription(ctx, id, body)

Change description for a device

Change description for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 
**body** | **string**| The device description | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: text/plain
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ChangeDeviceLevelSsidStatus

> ChangeDeviceLevelSsidStatus(ctx, id, xiqUpdateDeviceLevelSsidStatus)

Enable or disable SSID for a device

Enable or disable SSIDs on the given wifi interfaces for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 
**xiqUpdateDeviceLevelSsidStatus** | [**XiqUpdateDeviceLevelSsidStatus**](XiqUpdateDeviceLevelSsidStatus.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ChangeDeviceStatusToManage

> ChangeDeviceStatusToManage(ctx, id)

Change admin state to 'Managed' for a device

Change device management status to Managed for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ChangeDeviceStatusToUnmanage

> ChangeDeviceStatusToUnmanage(ctx, id)

Change admin state to 'Unmanaged' for a device

Change device admin state to 'Unmanaged' for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ChangeDevicesIbeacon

> ChangeDevicesIbeacon(ctx, xiqChangeDevicesIbeaconRequest)

Change iBeacon settings for devices

Update the existing or create new iBeacon settings for multiple devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqChangeDevicesIbeaconRequest** | [**XiqChangeDevicesIbeaconRequest**](XiqChangeDevicesIbeaconRequest.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ChangeDevicesOsMode

> ChangeDevicesOsMode(ctx, xiqChangeDevicesOsModeRequest)

Change device OS mode

Change OS mode for AP or Switch.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqChangeDevicesOsModeRequest** | [**XiqChangeDevicesOsModeRequest**](XiqChangeDevicesOsModeRequest.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ChangeHostname

> ChangeHostname(ctx, id, hostname)

Change hostname for a device

Change hostname for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 
**hostname** | **string**| The new hostname | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ChangeStatusToManage

> ChangeStatusToManage(ctx, xiqDeviceFilter)

Change status to Managed

Change device management status to Managed for the target devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqDeviceFilter** | [**XiqDeviceFilter**](XiqDeviceFilter.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ChangeStatusToUnmanage

> ChangeStatusToUnmanage(ctx, xiqDeviceFilter)

Change status to Unmanaged

Change device management status to Unmanaged for the target devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqDeviceFilter** | [**XiqDeviceFilter**](XiqDeviceFilter.md)| The device filter | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDevice

> DeleteDevice(ctx, id)

Delete a device

Delete a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDevices

> DeleteDevices(ctx, xiqDeviceFilter)

Delete devices

Bulk delete the devices matching the filter criteria.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqDeviceFilter** | [**XiqDeviceFilter**](XiqDeviceFilter.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDevice

> XiqDevice GetDevice(ctx, id, optional)

Get device info for a specific device

Get device info for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 
 **optional** | ***GetDeviceOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetDeviceOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **views** | [**optional.Interface of []XiqDeviceView**](XiqDeviceView.md)| The views to return device fields (Check details at XiqDeviceView schema) | 
 **fields** | [**optional.Interface of []XiqDeviceField**](XiqDeviceField.md)| The device fields to return | 

### Return type

[**XiqDevice**](XiqDevice.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDeviceCpuMemoryHistory

> []XiqDeviceCpuMemoryUsage GetDeviceCpuMemoryHistory(ctx, id, startTime, endTime, interval)

Get device CPU/memory usage history

Get average device CPU and memory usage history.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| Device ID | 
**startTime** | **int64**| The start time to query, epoch time in milliseconds since 1/1/1970 | 
**endTime** | **int64**| The end time to query, epoch time in milliseconds since 1/1/1970 | 
**interval** | **int64**| The aggregate interval in milliseconds | 

### Return type

[**[]XiqDeviceCpuMemoryUsage**](XiqDeviceCpuMemoryUsage.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDeviceIbeacon

> XiqDeviceIbeacon GetDeviceIbeacon(ctx, id)

Get the device iBeacon setting

Get the device iBeacon setting by device ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 

### Return type

[**XiqDeviceIbeacon**](XiqDeviceIbeacon.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDeviceLevelSsidStatus

> map[string]XiqDeviceLevelSsidStatus GetDeviceLevelSsidStatus(ctx, id)

Get SSID status for a device

Get the SSIDs status on each wifi interface for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 

### Return type

[**map[string]XiqDeviceLevelSsidStatus**](XiqDeviceLevelSsidStatus.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDeviceLocation

> XiqDeviceLocation GetDeviceLocation(ctx, id)

Get location for a device

Get the location info for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 

### Return type

[**XiqDeviceLocation**](XiqDeviceLocation.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDeviceNetworkPolicy

> XiqNetworkPolicy GetDeviceNetworkPolicy(ctx, id)

Get network policy for a device

Get the network policy for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 

### Return type

[**XiqNetworkPolicy**](XiqNetworkPolicy.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDeviceStats

> XiqDeviceStats GetDeviceStats(ctx, optional)

Get device stats

Get device stats, such as total device count, managed device count, connected device count, etc.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***GetDeviceStatsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a GetDeviceStatsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **locationId** | **optional.Int64**| The location ID | 

### Return type

[**XiqDeviceStats**](XiqDeviceStats.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDeviceWifiInterface

> []XiqDeviceWifiInterface GetDeviceWifiInterface(ctx, id, startTime, endTime)

Get the device WiFi interfaces stats

Get the device WiFi interfaces stats by device ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 
**startTime** | **int64**| The start time for collecting the wifi interfaces stat | 
**endTime** | **int64**| The end time for collecting the wifi interfaces stat | 

### Return type

[**[]XiqDeviceWifiInterface**](XiqDeviceWifiInterface.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetXiqDeviceInstallationReport

> XiqDeviceInstallationReport GetXiqDeviceInstallationReport(ctx, id)

Get device installation report

Get device installation report of a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 

### Return type

[**XiqDeviceInstallationReport**](XiqDeviceInstallationReport.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListDeviceAlarm

> PagedXiqDeviceAlarm ListDeviceAlarm(ctx, id, startTime, endTime, optional)

List alarms for a device

List alarms for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| Device ID | 
**startTime** | **int64**| The start time for query alarm | 
**endTime** | **int64**| The end time for query alarm | 
 **optional** | ***ListDeviceAlarmOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListDeviceAlarmOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqDeviceAlarm**](PagedXiqDeviceAlarm.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListDevices

> PagedXiqDevice ListDevices(ctx, optional)

[LRO] List devices

List devices with filters and pagination.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListDevicesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListDevicesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **locationId** | **optional.Int64**| Location Id | 
 **connected** | **optional.Bool**| The device connect status | 
 **adminStates** | [**optional.Interface of []XiqDeviceAdminState**](XiqDeviceAdminState.md)| The device admin states | 
 **macAddresses** | [**optional.Interface of []string**](string.md)| The device mac addresses | 
 **sns** | [**optional.Interface of []string**](string.md)| The device serial numbers | 
 **hostnames** | [**optional.Interface of []string**](string.md)| The device host names | 
 **sortField** | [**optional.Interface of XiqDeviceSortField**](.md)| The sort field | 
 **order** | [**optional.Interface of XiqSortOrder**](.md)| The sort order (ascending by default) | 
 **views** | [**optional.Interface of []XiqDeviceView**](XiqDeviceView.md)| The views to return device fields (Check fields for each view at XiqDeviceView schema) | 
 **fields** | [**optional.Interface of []XiqDeviceField**](XiqDeviceField.md)| The device fields to return | 
 **deviceTypes** | [**optional.Interface of []XiqDeviceType**](XiqDeviceType.md)| The device types to return | [default to [&quot;REAL&quot;]]
 **nullField** | [**optional.Interface of XiqDeviceNullField**](.md)| The device empty field, only returns the selected field that is null | 
 **locationIds** | [**optional.Interface of []int64**](int64.md)| The location IDs | 
 **async** | **optional.Bool**| Whether to enable async mode | [default to false]
 **configMismatch** | **optional.Bool**| Config audit status(MATCHED(false) or UNMATCHED(true)) | 

### Return type

[**PagedXiqDevice**](PagedXiqDevice.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListDevicesByNetworkPolicy

> PagedXiqDevice ListDevicesByNetworkPolicy(ctx, policyId, optional)

List assigned devices for network policy

List assigned devices for the network policy with pagination.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policyId** | **int64**| The network policy ID | 
 **optional** | ***ListDevicesByNetworkPolicyOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListDevicesByNetworkPolicyOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]

### Return type

[**PagedXiqDevice**](PagedXiqDevice.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListDigitalTwinProducts

> PagedXiqDigitalTwinProducts ListDigitalTwinProducts(ctx, optional)

List Digital Twin product information.

List of Digital Twin product information with pagination.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListDigitalTwinProductsOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListDigitalTwinProductsOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number, min &#x3D; 1 | [default to 1]
 **limit** | **optional.Int32**| Page Size, min &#x3D; 1, max &#x3D; 100 | [default to 10]
 **makes** | [**optional.Interface of []XiqDigitalTwinMake**](XiqDigitalTwinMake.md)| List by makes or any with null/empty makes. | 
 **models** | [**optional.Interface of []XiqDigitalTwinModel**](XiqDigitalTwinModel.md)| List by makes or any with null/empty models. | 

### Return type

[**PagedXiqDigitalTwinProducts**](PagedXiqDigitalTwinProducts.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## OnboardDevices

> OnboardDevices(ctx, xiqOnboardDeviceRequest)

Onboard Devices

Onboard devices for all devices, such as Extreme/Aerohive, EXOS, VOSS, WiNG, Dell, and Digital Twin. This is asynchronized operation to support massive device onboarding.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqOnboardDeviceRequest** | [**XiqOnboardDeviceRequest**](XiqOnboardDeviceRequest.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## OverrideDeviceLevelSsid

> OverrideDeviceLevelSsid(ctx, id, xiqDeviceLevelSsid)

Override SSID for a device

Override SSID broadcast name/passphrase for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 
**xiqDeviceLevelSsid** | [**XiqDeviceLevelSsid**](XiqDeviceLevelSsid.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## QueryDevicesLocation

> map[string]XiqDeviceLocation QueryDevicesLocation(ctx, xiqDeviceFilter)

Query location for multiple devices

Query the location for the target devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqDeviceFilter** | [**XiqDeviceFilter**](XiqDeviceFilter.md)|  | 

### Return type

[**map[string]XiqDeviceLocation**](XiqDeviceLocation.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## QueryDevicesNetworkPolicy

> map[string]XiqNetworkPolicy QueryDevicesNetworkPolicy(ctx, xiqDeviceFilter)

Query network policy for multiple devices

Query the network policy for the target devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqDeviceFilter** | [**XiqDeviceFilter**](XiqDeviceFilter.md)|  | 

### Return type

[**map[string]XiqNetworkPolicy**](XiqNetworkPolicy.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RebootDevice

> RebootDevice(ctx, id)

Reboot a device

Reboot a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RebootDevices

> RebootDevices(ctx, xiqDeviceFilter)

Reboot devices

Reboot the target devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqDeviceFilter** | [**XiqDeviceFilter**](XiqDeviceFilter.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ResetDevice

> ResetDevice(ctx, id, optional)

[LRO] Reset a device to factory default

Reset a device to factory default settings.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 
 **optional** | ***ResetDeviceOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ResetDeviceOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **async** | **optional.Bool**| Whether to enable async mode | [default to false]

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RevokeDeviceLocation

> RevokeDeviceLocation(ctx, id)

Revoke location for a device

Revoke the assigned location for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RevokeDeviceNetworkPolicy

> RevokeDeviceNetworkPolicy(ctx, id)

Revoke network policy for a device

Revoke the assigned network policy for a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RevokeDevicesLocation

> RevokeDevicesLocation(ctx, xiqDeviceFilter)

Revoke location for multiple devices

Revoke the location from the target devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqDeviceFilter** | [**XiqDeviceFilter**](XiqDeviceFilter.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RevokeDevicesNetworkPolicy

> RevokeDevicesNetworkPolicy(ctx, xiqDeviceFilter)

Revoke network policy for multiple devices

Revoke the network policy from the target devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqDeviceFilter** | [**XiqDeviceFilter**](XiqDeviceFilter.md)|  | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## RevokeDevicesRadiusProxy

> RevokeDevicesRadiusProxy(ctx, ids)

Revoke RADIUS proxy from multiple devices

Revoke the RADIUS proxy from the target devices.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**ids** | [**[]int64**](int64.md)| The device IDs | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SendCliToDevice

> XiqSendCliResponse SendCliToDevice(ctx, id, requestBody)

Send CLI to a device

Send CLI commands to a specific device.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The device ID | 
**requestBody** | [**[]string**](string.md)| The one or multiple CLIs to send | 

### Return type

[**XiqSendCliResponse**](XiqSendCliResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SendCliToDevices

> XiqSendCliResponse SendCliToDevices(ctx, xiqSendCliRequest, optional)

[LRO] Send CLI to devices

Send CLI commands to the target devices. This API can be run at async mode, please follow the Long-Running Operation (LRO) guide to track the progress and the result.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqSendCliRequest** | [**XiqSendCliRequest**](XiqSendCliRequest.md)|  | 
 **optional** | ***SendCliToDevicesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a SendCliToDevicesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **async** | **optional.Bool**| Whether to enable async mode | [default to false]

### Return type

[**XiqSendCliResponse**](XiqSendCliResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

