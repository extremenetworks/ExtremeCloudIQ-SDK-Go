# XiqDeviceLldpCdpInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PortId** | **string** | The port ID. | [optional] 
**SystemId** | **string** | The system ID. | [optional] 
**SystemName** | **string** | The system name. | [optional] 
**InterfaceName** | **string** | The interface name. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


