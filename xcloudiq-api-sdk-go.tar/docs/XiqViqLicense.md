# XiqViqLicense

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**Status** | [**XiqLicenseStatus**](XiqLicenseStatus.md) |  | [optional] 
**ActiveDate** | [**time.Time**](time.Time.md) | The active date | [optional] 
**ExpireDate** | [**time.Time**](time.Time.md) | The expire date | [optional] 
**EntitlementKey** | **string** | The entitlement key | [optional] 
**EntitlementType** | [**XiqEntitlementType**](XiqEntitlementType.md) |  | [optional] 
**Mode** | [**XiqLicenseMode**](XiqLicenseMode.md) |  | [optional] 
**Devices** | **int32** | The device number | [optional] 
**Activated** | **int32** | The activated device number | [optional] 
**Available** | **int32** | The available device number | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


