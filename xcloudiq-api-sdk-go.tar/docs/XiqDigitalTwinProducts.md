# XiqDigitalTwinProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Make** | **string** | The Digital Twin device make. | 
**Model** | **string** | The Digital Twin device model. | 
**OsType** | **string** | The Digital Twin device OS type. | [optional] 
**OsVersions** | **[]string** | The Digital Twin device OS versions. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


