# XiqCloudConfigGroup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**Name** | **string** | The CCG name | 
**Description** | **string** | The CCG description | [optional] 
**Predefined** | **bool** | Whether it is predefined | 
**ReadOnly** | **bool** | Whether it is read-only | [optional] 
**ZoneName** | **string** | The zone name. | [optional] 
**ZoneId** | **int64** | The zone ID | [optional] 
**ZoneLocationId** | **int64** | The zone location ID | [optional] 
**DeviceIds** | **[]int64** | The device IDs selected for this Ccg. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


