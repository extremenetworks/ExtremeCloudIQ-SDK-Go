# XiqGetPortAssignmentDetailsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PolicyId** | **int64** | The network policy ID | 
**PolicyName** | **string** | The network policy name | 
**PcgPortAssignmentEntryDetails** | [**[]XiqPcgPortAssignmentEntryDetail**](XiqPcgPortAssignmentEntryDetail.md) | The PCG port assignment entry details | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


