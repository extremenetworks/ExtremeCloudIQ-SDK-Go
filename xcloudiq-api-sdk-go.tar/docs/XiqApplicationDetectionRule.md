# XiqApplicationDetectionRule

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Value** | **string** | The value of detection rule type | [optional] 
**Protocol** | [**XiqApplicationDetectionProtocol**](XiqApplicationDetectionProtocol.md) |  | [optional] 
**Type** | [**XiqApplicationDetectionType**](XiqApplicationDetectionType.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


