# XiqWirelessPerformanceRetriesEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RxRetry** | **float64** | The rx retries | [optional] 
**TxRetry** | **float64** | The tx retries | [optional] 
**AboveRetryThreshold** | **float64** | The above retry threshold | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


