# XiqWirelessPerformanceRetriesEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RxRetry** | **float64** | the rx retries | [optional] 
**TxRetry** | **float64** | the tx retries | [optional] 
**AboveRetryThreshold** | **float64** | the above retry threshold | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


