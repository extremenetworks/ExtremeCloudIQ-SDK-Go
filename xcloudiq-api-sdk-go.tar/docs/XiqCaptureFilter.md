# XiqCaptureFilter

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MacAddr** | **[]string** | List of the client MAC addresses used for packet capturing | [optional] 
**IpAddr** | **[]string** | List of  the client IP addresses used to filter the packets | [optional] 
**Protocol** | [**XiqPolicyRuleProtocolType**](XiqPolicyRuleProtocolType.md) |  | [optional] 
**ProtocolNumber** | **int32** | The protocol number if protocol is \&quot;USER_DEFINED\&quot; | [optional] 
**Port** | **int32** | The port for packet capture | [optional] 
**Vlan** | **string** | Specific vlan ids in a string, e.g. range \&quot;2-100\&quot;; single \&quot;3\&quot;; list \&quot;1,2,5,7,122\&quot;; mixed \&quot;2,4,5-10,19,29\&quot;. If not specified, default is all VLANs. | [optional] 
**Wlan** | **string** | A WLAN SSID. If not specified, default is all WLANs. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


