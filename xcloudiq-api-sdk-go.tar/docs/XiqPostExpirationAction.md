# XiqPostExpirationAction

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnableCredentialsRenewal** | **bool** | The renew user credentials option or null for other option. | [optional] 
**EnableDeleteImmediately** | **bool** | The immediate delete option or null to schedule the delete. | [optional] 
**DeleteAfterValue** | **int32** | The after expiration scheduled time to delete or null to not delete.. | [optional] 
**DeleteAfterUnit** | [**XiqDateTimeUnitType**](XiqDateTimeUnitType.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


