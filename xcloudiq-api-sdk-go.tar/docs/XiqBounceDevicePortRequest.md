# XiqBounceDevicePortRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeviceId** | **int64** | The device id | [optional] 
**PortNumber** | **string** | The port number of the device (eg. 1,2, ..) | [optional] 
**BouncePortReason** | **string** | The reason to bounce the port of the device (eg. reset the inline power on the port so that the connected AP can be restarted) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


