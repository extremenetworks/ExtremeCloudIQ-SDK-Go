# XiqActiveDirectoryServer

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The unique identifier | 
**CreateTime** | [**time.Time**](time.Time.md) | The create time | 
**UpdateTime** | [**time.Time**](time.Time.md) | The last update time | 
**OrgId** | **int64** | The organization identifier, valid when enabling HIQ feature | [optional] 
**Name** | **string** | The active directory server name | [optional] 
**Description** | **string** | The description for active directory server | [optional] 
**BaseDn** | **string** | The base DN of active directory server | [optional] 
**EnableTls** | **bool** | Flag to enable TLS | [optional] 
**BindDn** | **string** | The bind DN of active directory server | [optional] 
**BindDnPassword** | **string** | The bind DN password of active directory server | [optional] 
**Domain** | **string** | The domain of active directory server | [optional] 
**ComputerOu** | **string** | The compute OU of active directory server | [optional] 
**DomainAdmin** | **string** | The domain admin of active directory server | [optional] 
**DomainAdminPassword** | **string** | The domain admin password of active directory server | [optional] 
**EnableSaveDomainAdminCredentials** | **bool** | Flag to enable save domain admin credentials | [optional] 
**ShortDomain** | **string** | The short domain of active directory server | [optional] 
**Realm** | **string** | The realm of active directory server | [optional] 
**BaseDnFetchMode** | [**XiqActiveDirectoryServerBaseDnFetchMode**](XiqActiveDirectoryServerBaseDnFetchMode.md) |  | [optional] 
**ConnectionSetupDeviceId** | **int64** | The connection setup device ID for active directory server | [optional] 
**L3AddressProfileId** | **int64** | The associate L3 address profile ID for active directory server | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


