# XiqOnboardDeviceRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Extreme** | [**XiqExtremeDevices**](XiqExtremeDevices.md) |  | [optional] 
**Exos** | [**XiqExosDevices**](XiqExosDevices.md) |  | [optional] 
**Voss** | [**XiqVossDevices**](XiqVossDevices.md) |  | [optional] 
**Wing** | [**XiqWingDevices**](XiqWingDevices.md) |  | [optional] 
**Dell** | [**XiqDellDevices**](XiqDellDevices.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


