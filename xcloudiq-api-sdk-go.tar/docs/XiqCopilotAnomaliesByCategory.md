# XiqCopilotAnomaliesByCategory

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AnomaliesByLocation** | [**[]XiqAnomaliesSiteEntity**](XiqAnomaliesSiteEntity.md) | The total anomalies by location | [optional] 
**AnomaliesBySeverity** | [**XiqAnomaliesSeverityEntity**](XiqAnomaliesSeverityEntity.md) |  | [optional] 
**AnomaliesByType** | [**[]XiqAnomaliesTypeEntity**](XiqAnomaliesTypeEntity.md) | The total anomalies by type | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


