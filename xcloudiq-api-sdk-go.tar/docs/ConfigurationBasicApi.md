# \ConfigurationBasicApi

All URIs are relative to *http://localhost:8081*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateVlanProfile**](ConfigurationBasicApi.md#CreateVlanProfile) | **Post** /vlan-profiles | Create VLAN profile
[**DeleteVlanProfile**](ConfigurationBasicApi.md#DeleteVlanProfile) | **Delete** /vlan-profiles/{id} | Delete a VLAN profile
[**GetVlanProfile**](ConfigurationBasicApi.md#GetVlanProfile) | **Get** /vlan-profiles/{id} | Get a VLAN profile
[**ListVlanProfiles**](ConfigurationBasicApi.md#ListVlanProfiles) | **Get** /vlan-profiles | List VLAN profiles
[**UpdateVlanProfile**](ConfigurationBasicApi.md#UpdateVlanProfile) | **Patch** /vlan-profiles/{id} | Update a VLAN profile



## CreateVlanProfile

> XiqVlanProfile CreateVlanProfile(ctx, xiqCreateVlanProfileRequest)

Create VLAN profile

Create a new VLAN profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**xiqCreateVlanProfileRequest** | [**XiqCreateVlanProfileRequest**](XiqCreateVlanProfileRequest.md)| The payload to create new VLAN profile | 

### Return type

[**XiqVlanProfile**](XiqVlanProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteVlanProfile

> DeleteVlanProfile(ctx, id)

Delete a VLAN profile

Delete a specific VLAN profile by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The VLAN profile ID | 

### Return type

 (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetVlanProfile

> XiqVlanProfile GetVlanProfile(ctx, id)

Get a VLAN profile

Get a specific VLAN profile by ID.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The VLAN profile ID | 

### Return type

[**XiqVlanProfile**](XiqVlanProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListVlanProfiles

> PagedXiqVlanProfile ListVlanProfiles(ctx, optional)

List VLAN profiles

Get a page of VLAN profiles.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***ListVlanProfilesOpts** | optional parameters | nil if no parameters

### Optional Parameters

Optional parameters are passed through a pointer to a ListVlanProfilesOpts struct


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **optional.Int32**| Page number | [default to 1]
 **limit** | **optional.Int32**| Page Size | [default to 10]

### Return type

[**PagedXiqVlanProfile**](PagedXiqVlanProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateVlanProfile

> XiqVlanProfile UpdateVlanProfile(ctx, id, xiqUpdateVlanProfileRequest)

Update a VLAN profile

Update a specific VLAN profile.

### Required Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **int64**| The VLAN profile ID. | 
**xiqUpdateVlanProfileRequest** | [**XiqUpdateVlanProfileRequest**](XiqUpdateVlanProfileRequest.md)| The payload to update VLAN profile | 

### Return type

[**XiqVlanProfile**](XiqVlanProfile.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

