# XiqAnomalyDeviceEntity

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeviceId** | **int64** | the device id | [optional] 
**DeviceName** | **string** | the device name | [optional] 
**Pinned** | **bool** | is device pinned | [optional] 
**Wired** | **bool** | is device wired | [optional] 
**AnomalyId** | **string** | the anomaly id | [optional] 
**Severity** | [**XiqAnomalySeverity**](XiqAnomalySeverity.md) |  | [optional] 
**Summary** | **string** | the anomaly summary | [optional] 
**LastDetectedTime** | **int64** | the last detected time | [optional] 
**RecommendedAction** | **string** | the recommended action | [optional] 
**AnomalySubtypes** | **string** | the anomaly sub-type | [optional] 
**InterfaceName** | **string** | the interface name | [optional] 
**ChannelMode** | **string** | the channel mode : tx or rx | [optional] 
**Channel** | **int32** | the channel number | [optional] 
**Frequency** | **string** | the frequency | [optional] 
**LocationId** | **int64** | the location id | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


