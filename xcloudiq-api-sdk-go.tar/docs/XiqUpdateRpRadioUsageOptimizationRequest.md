# XiqUpdateRpRadioUsageOptimizationRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Preamble** | **string** | The preamble data length -- \&quot;AUTO\&quot; or \&quot;LONG\&quot; | [optional] 
**BeaconPeriod** | **int32** | The amount of time between beacons in the range from 40 to 3500. | [optional] 
**EnableFrameBurst** | **bool** | Whether to enable Frame Burst | [optional] 
**EnableSmartAntenna** | **bool** | Whether to enable Smart Antenna (Enabling this option will disable (Null) for MU-MIMO) | [optional] 
**EnableBackhaulFailover** | **bool** | Whether to enable backhaul failover. Backhaul failover settings determine the thresholds at which the device switches from a wired to a wireless backhaul link, and the thresholds at which the device switches back | [optional] 
**WirelessBackhaulSwitchTriggerTime** | **int32** | Switch to Wireless Backhaul after the number of seconds (1 to 5) after the wired link fails | [optional] 
**WiredBackhaulRevertHoldTime** | **int32** | Revert Back to Wired Backhaul after the number of seconds (1 to 300) after the wired link is established | [optional] 
**EnableBandSteering** | **bool** | Whether to enable band steering. Enabling steers clients from 2.4 GHz to 5.0 GHz radio band | [optional] 
**BandSteeringMode** | **string** | The band steering mode -- \&quot;BALANCE\&quot;, \&quot;URGE_5G\&quot;, or \&quot;ENFORCE_5G\&quot; | [optional] 
**RatioFor5gClients** | **int32** | The allowed percentage distribution of 2.4 and 5.0 GHz clients for \&quot;BALANCE\&quot; steering mode. | [optional] 
**IgnoreInitialClientConnectionNumber** | **int32** | The number of connection attempts from 2.4 GHz clients to ignore before responding for URGE_5G steering mode. | [optional] 
**EnableClientLoadBalancing** | **bool** | Whether to enable client load balancing.  Enabling load-balances clients across neighboring Extreme Networks within the same hive. Set WiFi0 and WiFi1 radios to the same load balancing mode when it is based on the number of associated stations. | [optional] 
**LoadBalancingMode** | **string** | The client load balancing mode -- \&quot;AIRTIME_BASED\&quot; or \&quot;CLIENT_NUMBER\&quot; | [optional] 
**CrcErrorRatePerDevice** | **int32** | The CRC Error rate threshold value for \&quot;AIRTIME_BASED\&quot; load balancing. Ignore probe and association requests per device when CRC Error rate exceeds the threshold. | [optional] 
**RfInterferencePerDevice** | **int32** | The RF Interference threshold value for \&quot;AIRTIME_BASED\&quot; load balancing. Ignore probe and association requests per device when RF Interference exceeds the threshold. | [optional] 
**AverageAirtimePerClient** | **int32** | The Average Airtime Per Client threshold value for \&quot;AIRTIME_BASED\&quot; load balancing. Ignore probe and association requests per device when Average Airtime Per Client exceeds the threshold. | [optional] 
**AnchorPeriod** | **int32** | The Anchor Period value for both \&quot;AIRTIME_BASED\&quot; and \&quot;CLIENT_NUMBER\&quot; load balancing. Ignore probe and association requests from clients associated with other Extreme Networks devices until Anchor Period Eelapses in the range of 10 to 600 seconds | [optional] 
**NeighborQueryInterval** | **int32** | In both client load balancing modes, query neighbors about client load every in the range of 1 to 600 seconds | [optional] 
**EnableWeakSignalProbeRequestSuppression** | **bool** | Whether to enable Weak Signal Probe Request Suppression. Weak Signal Probe Request Suppression allows the configuration of signal-to-noise threshold beyond which the device does not respond to client probes. | [optional] 
**WeakSnrThreshold** | **int32** | The signal to noise threshold in the range of 1 to 100 for Weak Signal Probe Request Suppression. | [optional] 
**EnableSafetyNet** | **bool** | Whether to enable Safety Net. When a device is overloaded or is probed by clients with a low signal-to-noise ratio,  Safety Net allows the device to respond to association requests  after a certain time period lapses. | [optional] 
**SafetyNetPeriod** | **int32** | The Safety Net Time Period in the range of 5 to 300 seconds. | [optional] 
**EnableHighDensity** | **bool** | Whether to enable High Density Configuration. Enabling optimizes performance in high density environments | [optional] 
**ManagementFrameBasicDataRate** | **string** | The data rates to support in high density environment -- \&quot;HIGH\&quot; or \&quot;LOW\&quot; | [optional] 
**EnableSuppressSuccessiveProbeRequest** | **bool** | Whether to Reduce Response to Probe Requests. Enabling suppresses successive requests within the same beacon interval | [optional] 
**ProbeResponseReductionOption** | **string** | The suppress response to broadcast probes options --  \&quot;ONLY_ONE_SSID_RESPOND_AT_A_TIME\&quot; (allowed for only one SSID to respond at a time), \&quot;REDUCE_CERTAIN_CLIENTS_RESPONSE\&quot; (reducing responses to certain client devices). | [optional] 
**SuppressionLimit** | **int32** | The Number of Connection Attempts in the range of 1 to 10 | [optional] 
**EnableRadioBalance** | **bool** | Whether to enable Radio Load Balancing. Enabling distributes wireless clients that support 5 GHz band evenly across the two radios in Dual-5G mode when an SSID is available on both radios | [optional] 
**MacOuiIds** | **[]int64** | The MacOui Profile IDs for the \&quot;REDUCE_CERTAIN_CLIENTS_RESPONSE\&quot; probe response reduction option | [optional] 
**EnableAmpdu** | **bool** | Enable Aggregate MAC Protocol Data Units to combine data frames into larger frames before transmission. | [optional] 
**EnableMuMimo** | **bool** | Whether to enable Multiple-Input Multiple-Output (802.11ac &amp; 802.11ax) for multiple-user access by using different spatial streams. | [optional] 
**EnableOfdmaDownLink** | **bool** | Whether to enable OFDMA for AP downlink communication. | [optional] 
**EnableOfdmaUpLink** | **bool** | Whether to enable OFDMA for AP uplink communication. | [optional] 
**BssColoring** | **int32** | The numerical identifier of the basic service sets (802.11ax ) to identify overlapping basic service sets (OBSSs). | [optional] 
**EnableTargetWeakTime** | **bool** | Whether to enable Target Weak Time. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


